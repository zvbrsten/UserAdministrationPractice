# Employee Management REST API



---

## Overview

Employee Management system using REST APIS with CRUD made using Springboot. 

---

## Features

### Department Management
-  Create new departments
-  Retrieve all departments
- Fetch department details by ID


### Employee Management
- Create new employees with validation
- Retrieve all employees
- Update employee info
- Delete employee
- Get employee by department


### Other features
- Bean Validation 
- Global exception handling with meaningful error messages
- Comprehensive API documentation via Swagger/OpenAPI 3.0
- Request/Response DTOs for data encapsulation
- Relationship management (One-to-Many: Department ↔ Employee)



## 📁 Project Structure

```

.
├── .gitattributes
├── .gitignore
├── HELP.md
├── .idea
│   ├── compiler.xml
│   ├── encodings.xml
│   ├── .gitignore
│   ├── jarRepositories.xml
│   ├── jpa.xml
│   ├── misc.xml
│   ├── uiDesigner.xml
│   └── workspace.xml
├── img_1.png
├── img_2.png
├── img_3.png
├── img_4.png
├── img_5.png
├── img_6.png
├── img_7.png
├── img.png
├── .mvn
│   └── wrapper
│       └── maven-wrapper.properties
├── mvnw
├── mvnw.cmd
├── pom.xml
├── README.md
├── src
│   ├── main
│   │   ├── java
│   │   │   └── com
│   │   │       └── example
│   │   │           └── employeemanagement
│   │   │               ├── config
│   │   │               │   └── SwaggerConfig.java
│   │   │               ├── controller
│   │   │               │   ├── DepartmentController.java
│   │   │               │   └── EmployeeController.java
│   │   │               ├── dto
│   │   │               │   ├── DepartmentDTO.java
│   │   │               │   ├── DepartmentResponseDTO.java
│   │   │               │   ├── EmployeeDTO.java
│   │   │               │   └── EmployeeResponseDTO.java
│   │   │               ├── EmployeemanagementApplication.java
│   │   │               ├── entity
│   │   │               │   ├── Department.java
│   │   │               │   └── Employee.java
│   │   │               ├── exception
│   │   │               │   ├── DuplicatesResource.java
│   │   │               │   ├── GlobalExceptionHandler.java
│   │   │               │   └── NotFound.java
│   │   │               ├── repository
│   │   │               │   ├── DepartmentRepository.java
│   │   │               │   └── EmployeeRepository.java
│   │   │               ├── response
│   │   │               │   └── ApiResponse.java
│   │   │               └── service
│   │   │                   ├── DepartmentService.java
│   │   │                   └── EmployeeService.java
│   │   └── resources
│   │       ├── application.properties
│   │       ├── static
│   │       └── templates
│   └── test
│       └── java
│           └── com
│               └── example
│                   └── employeemanagement
│                       └── EmployeemanagementApplicationTests.java
└── target
    ├── classes
    │   ├── application.properties
    │   └── com
    │       └── example
    │           └── employeemanagement
    │               ├── config
    │               │   └── SwaggerConfig.class
    │               ├── controller
    │               │   ├── DepartmentController.class
    │               │   └── EmployeeController.class
    │               ├── dto
    │               │   ├── DepartmentDTO$DepartmentDTOBuilder.class
    │               │   ├── DepartmentDTO.class
    │               │   ├── DepartmentResponseDTO$DepartmentResponseDTOBuilder.class
    │               │   ├── DepartmentResponseDTO.class
    │               │   ├── EmployeeDTO$EmployeeDTOBuilder.class
    │               │   ├── EmployeeDTO.class
    │               │   ├── EmployeeResponseDTO$EmployeeResponseDTOBuilder.class
    │               │   └── EmployeeResponseDTO.class
    │               ├── EmployeemanagementApplication.class
    │               ├── entity
    │               │   ├── Department.class
    │               │   └── Employee.class
    │               ├── exception
    │               │   ├── DuplicatesResource.class
    │               │   ├── GlobalExceptionHandler.class
    │               │   └── NotFound.class
    │               ├── repository
    │               │   ├── DepartmentRepository.class
    │               │   └── EmployeeRepository.class
    │               ├── response
    │               │   └── ApiResponse.class
    │               └── service
    │                   ├── DepartmentService.class
    │                   └── EmployeeService.class
    ├── generated-sources
    │   └── annotations
    ├── generated-test-sources
    │   └── test-annotations
    ├── maven-status
    │   └── maven-compiler-plugin
    │       ├── compile
    │       │   └── default-compile
    │       │       ├── createdFiles.lst
    │       │       └── inputFiles.lst
    │       └── testCompile
    │           └── default-testCompile
    │               ├── createdFiles.lst
    │               └── inputFiles.lst
    └── test-classes
        └── com
            └── example
                └── employeemanagement
                    └── EmployeemanagementApplicationTests.class



```



## Installation & Setup


### Step 1: Configure PostgreSQL Database

#### Create Database

```sql
-- Connect to PostgreSQL
psql -U postgres

-- Create database
CREATE DATABASE employee_management;


-- Exit psql

```

#### Alternative: Using pgAdmin

1. Open pgAdmin
2. Create new database: `employee_management`
3. Create new user: `postgres`
4. Grant privileges to the user

### Step 2: Configure Application Properties

Create or modify `application.properties` file in `src/main/resources/`:

```propertiesspring.application.name=employeemanagement
spring.application.name=employeemanagement

spring.session.jdbc.initialize-schema=always



spring.datasource.url=${DB_URL}
spring.datasource.username=${DB_USERNAME}
spring.datasource.password=${DB_PASSWORD}

spring.datasource.driver-class-name=org.postgresql.Driver



spring.jpa.database-platform=org.hibernate.dialect.PostgreSQLDialect




spring.jpa.show-sql=false
spring.jpa.properties.hibernate.format_sql=false
spring.jpa.properties.hibernate.use_sql_comments=false

# Auto-create/update tables
spring.jpa.hibernate.ddl-auto=update

spring.security.user.name=user
spring.security.user.password=pwd

logging.level.org.springframework.security=DEBUG




springdoc.api-docs.path=/v3/api-docs
springdoc.swagger-ui.path=/swagger-ui.html
springdoc.swagger-ui.enabled=true
springdoc.api-docs.enabled=true



logging.level.org.springdoc=DEBUG


logging.level.io.swagger.v3=DEBUG



```

### Step 3: Build the Project

```bash
# Download dependencies and compile
mvn clean install
```

### Step 4: Run the Application

#### Option A: Using Maven

Insert ENV variables
```bash
mvn spring-boot:run
```

#### Option B: Using IDE
- Open the project in your IDE (IntelliJ, Eclipse, VSCode)
- Right-click on `EmployeeManagementApplication.java`
- Select "Run"

### Step 6: Verify Application Startup

Once the application starts, you should see output similar to:

```
...
2024-XX-XX 10:30:45.123  INFO 12345 --- [main] c.y.e.EmployeeManagementApplication : Started EmployeeManagementApplication in 5.234 seconds (JVM running for 5.789)
2024-XX-XX 10:30:45.234  INFO 12345 --- [main] o.s.b.a.e.web.EndpointLinksResolver   : Exposing 15 endpoint(s) beneath base path '/actuator'
```

Access the application:
- **Base URL:** `http://localhost:8080/api/v1/`
- **Swagger UI:** `http://localhost:8080/swagger-ui.html`
- **OpenAPI JSON:** `http://localhost:8080/v3/api-docs`

---
### Entity Relationships

```
┌──────────────────┐         ┌──────────────────┐
│   Department     │         │    Employee      │
├──────────────────┤         ├──────────────────┤
│ id (PK)          │ 1─── *  │ id (PK)          │
│ name             │         │ first_name       │
│ description      │         │ last_name        │
│ created_at       │         │ email            │
│ updated_at       │         │ phone            │
└──────────────────┘         │ designation      │
                             │ salary           │
                             │ joining_date     │
                             │ department_id(FK)│
                             │ created_at       │
                             │ updated_at       │
                             └──────────────────┘
```

---

## 📚 API Documentation

### Base URL
```
http://localhost:8080/api/v1
```

---

## 🔌 API Endpoints

### Department APIs

#### 1. Create Department

![img.png](img.png)



#### 2. Get All Departments
![img_1.png](img_1.png)


#### 3. Get Department By ID
![img_2.png](img_2.png)

---

### Employee APIs

#### 1. Get all Employee
![img_3.png](img_3.png)

Response Body
````{
"data": [
{
"departmentId": 5,
"designation": "Mobile App Developer",
"email": "ishita.agarwal10@techcorp.com",
"firstName": "Ishita",
"lastName": "Agarwal",
"phone": "9140742411",
"salary": 135
},
{
"departmentId": 4,
"designation": "Security Engineer",
"email": "aditya.shukla09@techcorp.com",
"firstName": "Aditya",
"lastName": "Shukla",
"phone": "9140742410",
"salary": 160
},
{
"departmentId": 3,
"designation": "Data Engineer",
"email": "neha.kapoor08@techcorp.com",
"firstName": "Neha",
"lastName": "Kapoor",
"phone": "9140742409",
"salary": 155
},
{
"departmentId": 2,
"designation": "Cloud Engineer",
"email": "vikram.yadav07@techcorp.com",
"firstName": "Vikram",
"lastName": "Yadav",
"phone": "9140742408",
"salary": 145
},
{
"departmentId": 1,
"designation": "Software Engineer",
"email": "ananya.pandey06@techcorp.com",
"firstName": "Ananya",
"lastName": "Pandey",
"phone": "9140742407",
"salary": 125
},
{
"departmentId": 5,
"designation": "Full Stack Developer",
"email": "karan.joshi05@techcorp.com",
"firstName": "Karan",
"lastName": "Joshi",
"phone": "9140742406",
"salary": 150
},
{
"departmentId": 4,
"designation": "QA Engineer",
"email": "sneha.mishra04@techcorp.com",
"firstName": "Sneha",
"lastName": "Mishra",
"phone": "9140742405",
"salary": 110
},
{
"departmentId": 3,
"designation": "DevOps Engineer",
"email": "rohan.gupta03@techcorp.com",
"firstName": "Rohan",
"lastName": "Gupta",
"phone": "9140742403",
"salary": 140
},
{
"departmentId": 2,
"designation": "Backend Developer",
"email": "priya.singh02@techcorp.com",
"firstName": "Priya",
"lastName": "Singh",
"phone": "9140742402",
"salary": 130
}
],
"message": "Employees retrieved successfully",
"success": true,
"timestamp": "2026-06-08T16:33:44.881326677"
}
````

#### 2. Create Employee
![img_4.png](img_4.png)




#### 4. Update Employee email
![img_5.png](img_5.png)

#### 5. Delete Employee
![img_6.png](img_6.png)


---

## Validation Rules

The application enforces the following validation rules:

### Employee Validation

| Field | Rules                                                | Example |
|-------|------------------------------------------------------|---------|
| **First Name** | • Not blank<br/>• Max 50 characters                  | "John" |
| **Last Name** | • Not blank<br/>• Max 50 characters                  | "Doe" |
| **Email** | • Valid email format<br/>• Unique<br/>               | "john.doe@company.com" |
| **Phone** | • Exactly 10 digits<br/>• Numeric only<br/> • Unique | "9876543210" |
| **Designation** | -                                                    | "Senior Developer" |
| **Salary** | • Greater than 0<br/>• Numeric                       | "75000.00" |
| **Joining Date** | • Not future date<br/>• Valid date format            | "2024-01-01" |
| **Department ID** | • Must exist in database<br/>• Not null              | 1 |

### Department Validation

| Field | Rules | Example |
|-------|-------|---------|
| **Name** | • Not blank<br/>• Unique<br/>| "Engineering" |
| **Description** | • Optional<br/>| "Engineering Department" |

### Validation Error Response
![img_7.png](img_7.png)

### has wrong email,phone, joining date is in future,salary is 0


```http
{
  "message": "{phone=size must be between 10 and 10, joiningDate=Cant allow future joining Date, salary=Salary should be greater than 0, email=Enter valid emailID}",
  "success": false,
  "timestamp": "2026-06-09T18:47:15.401838209"
}
```

---





---

## 📝 Logging

The application uses SLF4J with Logback for logging:

### Log Levels Configuration

```properties
# Root level
logging.level.root=INFO

# Application-specific
logging.level.com.example.employeemanagement=DEBUG

# Spring Framework
logging.level.org.springframework.web=INFO
logging.level.org.hibernate.SQL=DEBUG
```



