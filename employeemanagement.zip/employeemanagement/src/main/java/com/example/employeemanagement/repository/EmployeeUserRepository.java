package com.example.employeemanagement.repository;

import com.example.employeemanagement.entity.EmployeeUser;
import org.jspecify.annotations.Nullable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface EmployeeUserRepository extends JpaRepository<EmployeeUser,Long> {
    Optional<EmployeeUser> findByEmail(String email);
}
