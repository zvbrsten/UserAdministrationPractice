package com.example.employeemanagement.service;

import com.example.employeemanagement.dto.EmployeeDTO;
import com.example.employeemanagement.dto.EmployeeResponseDTO;
import com.example.employeemanagement.entity.Department;
import com.example.employeemanagement.entity.OTP;
import com.example.employeemanagement.exception.DuplicatesResource;
import com.example.employeemanagement.exception.NotFound;
import com.example.employeemanagement.repository.OTPRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.example.employeemanagement.repository.DepartmentRepository;
import com.example.employeemanagement.repository.EmployeeRepository;
import com.example.employeemanagement.entity.Employee;
import org.springframework.web.bind.annotation.RequestBody;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;


@Service
@Transactional(readOnly = true)
public class EmployeeService {

    private static final Logger logger = LoggerFactory.getLogger(EmployeeService.class);

    private final EmployeeRepository employeeRepository;
    private final DepartmentRepository departmentRepository;
    private final OTPRepository otpRepository;

    public EmployeeService(EmployeeRepository employeeRepository,
                           DepartmentRepository departmentRepository, OTPRepository otpRepository) {
        this.employeeRepository = employeeRepository;
        this.departmentRepository = departmentRepository;
        this.otpRepository = otpRepository;
    }


    public List<EmployeeResponseDTO> getAllEmployees() {
        logger.info("Fetching all employees");
        return employeeRepository.findAll().stream().map(x -> new EmployeeResponseDTO(x)).toList();

    }
//    public Page<EmployeeResponseDTO> getAllEmployees() {
//        logger.info("Fetching all employees");
//
//        Pageable pageable = PageRequest.of(
//                0,
//                3,
//                Sort.by("department.id")
//        );
//
//        return employeeRepository.findAll(pageable)
//                .map(EmployeeResponseDTO::new);
//    }

    @Transactional
    public EmployeeResponseDTO fetchAfterDate(@RequestBody LocalDate joiningDate){
        logger.info("Fetchign employees after the Joining Date [{}]",joiningDate);
        Employee employee= employeeRepository.findByJoiningDateAfter(joiningDate).orElseThrow(()->new NotFound("No employees found with the given condition"));
        return new EmployeeResponseDTO(employee);
    }

    @Transactional
    public EmployeeResponseDTO createEmployee(EmployeeDTO employeeDTO) {
        logger.info("Creating Employee [{}]", employeeDTO.getFirstName() + " " + employeeDTO.getLastName());
        if (employeeRepository.existsByEmail(employeeDTO.getEmail())) {
            throw new DuplicatesResource("Employee already exists.");
        }
        if (employeeDTO.getDepartmentId() == null) {
            throw new NotFound("Department ID not found");
        }
        Department dep = departmentRepository.findById(employeeDTO.getDepartmentId())
                .orElseThrow(() -> new NotFound("Department not found"));
        Employee employee = new Employee(employeeDTO.getFirstName(), employeeDTO.getLastName(), employeeDTO.getEmail(), employeeDTO.getPhone(), employeeDTO.getDesignation(), employeeDTO.getSalary(), employeeDTO.getJoiningDate(), dep);

        sendOTP(employeeDTO);
        if (verifyOTP(employeeDTO, otpRepository.findByEmail(employeeDTO.getEmail()).get().getCode())) {
            employeeRepository.save(employee);
            logger.info("Employee [{}] created with id [{}]", employee.getEmail(), employee.getId());
            return EmployeeResponseDTO.builder()
                    .departmentId(employee.getDepartment().getId())
                    .lastName(employee.getLastName())
                    .email(employee.getEmail())
                    .id(employee.getId())
                    .firstName(employee.getFirstName())
                    .build();
        }
        else{
            return EmployeeResponseDTO.builder().build();
        }
    }



    public void sendOTP(EmployeeDTO employeeDTO){
        logger.info("Sending OTP to [{}]",employeeDTO.getEmail());

        OTP otp =new OTP();
        otp.setEmail(employeeDTO.getEmail());
        otp.setCode();
        otpRepository.save(otp);

    }
    public boolean verifyOTP(EmployeeDTO employeeDTO,String receivedOTP){

        String email=employeeDTO.getEmail();
        OTP otp= otpRepository.findByEmail(email).orElseThrow(()->new NotFound("Email not found for otp"));

        return otp.getCode().equals(receivedOTP);

    }
    @Transactional
    public EmployeeResponseDTO updateEmployee(String email, EmployeeDTO employeeDTO) {

        logger.info("Updating employee [{}] to [{}]", email, employeeDTO.getEmail());

        Employee employee =employeeRepository.findByEmail(email)
                .orElseThrow(() -> new NotFound("Employee not found"));

        if (employeeDTO.getFirstName() != null) {
            employee.setFirstName(employeeDTO.getFirstName());
        }

        if (employeeDTO.getLastName() != null) {
            employee.setLastName(employeeDTO.getLastName());
        }

        if (employeeDTO.getEmail() != null) {
            employee.setEmail(employeeDTO.getEmail());
        }

        if (employeeDTO.getPhone() != null) {
            employee.setPhone(employeeDTO.getPhone());
        }

        if (employeeDTO.getDesignation() != null) {
            employee.setDesignation(employeeDTO.getDesignation());
        }

        if (employeeDTO.getSalary() != null) {
            employee.setSalary(employeeDTO.getSalary());
        }
        if(employeeDTO.getDepartmentId()!=null) {
            Department dep=departmentRepository.findById(employeeDTO.getDepartmentId())
                    .orElseThrow(() -> new NotFound("Employee with this Department ID  not found"));
            employee.setDepartment(dep);
        }

        employeeRepository.save(employee);

        logger.info("Employee [{}] updated successfully", employeeDTO.getEmail());
        return EmployeeResponseDTO.builder()
                .departmentId(employee.getDepartment().getId())
                .lastName(employee.getLastName())
                .email(employee.getEmail())
                .id(employee.getId())
                .firstName(employee.getFirstName())
                .build() ;

    }




    @Transactional
    public void deleteEmployee(Long id) {
        logger.info("Deleting employee [{}]", id);
        Employee employee = employeeRepository.findById(id).orElseThrow(()->new NotFound("Employee id not found"));
        employeeRepository.delete(employee);
        logger.info("Employee [{}] deleted successfully", id);
    }

    @Transactional
    public EmployeeDTO getEmployeeById(Long id) {
        logger.info("Fetching employee with [{}]", id);
        Employee employee  = employeeRepository.findById(id).orElseThrow(() -> new NotFound("Employee with ID:" + id + " Not found"));

        EmployeeDTO employeeDTO = new EmployeeDTO(employee);
        logger.info("Fetched employee with [{}]", id);

        return employeeDTO;

    }

    @Transactional
    public List<Employee> getEmployeeByDepartment(String depName) {
        logger.info("Fetching Employees by Department Name [{}]",depName);
        if(departmentRepository.findByName(depName).isEmpty()){
            throw new NotFound("Department Not found");

        }
        logger.info("Fetched Employees by Department Name [{}]",depName);
        return departmentRepository.findByName(depName).get().getEmployees();


    }
}