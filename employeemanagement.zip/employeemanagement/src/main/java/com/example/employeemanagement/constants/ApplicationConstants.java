package com.example.employeemanagement.constants;

public class ApplicationConstants {

    private ApplicationConstants(){
        throw new AssertionError("Cant be instatnitated");
    }

    public static final String JWT_SECRET_KEY="JWT_SECRET";
    public static final String JWT_SECRET_DEFAULT_VALUE="2nSxyO8KPsPJ5IVN6DkC75DNoH3GJIxzTV3WWJw9UQB";
    public static final String JWT_HEADER = "Authorization";
    public static final String ROLE_USER="USER";
    public static final String ROLE_MANAGER="MANAGER";
    public static final String ROLE_ADMIN="ADMIN";

}
