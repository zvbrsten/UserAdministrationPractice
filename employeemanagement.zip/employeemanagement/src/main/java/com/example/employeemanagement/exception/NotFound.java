package com.example.employeemanagement.exception;

public class NotFound extends RuntimeException{

    public NotFound(String msgs){super(msgs);}

}
