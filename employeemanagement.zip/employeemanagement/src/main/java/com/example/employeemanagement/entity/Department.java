package com.example.employeemanagement.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.util.ArrayList;
import java.util.List;


@Entity
@Table(name="departments")
@Getter
@Setter
@NoArgsConstructor
public class Department {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name="name",unique = true,nullable = false)
    private String name;

    @Column(name="description")
    private String description;

    @OneToMany(mappedBy="department",fetch = FetchType.LAZY)//department is the field of employee table which was mapped
    //Lazy mean everytime Departments are loaded this list wont be loaded to save time. It will only be loaded when the specific call is maid
    //OrphanRemoval->by JPA
    //OnDelete by db
    @OnDelete(action= OnDeleteAction.SET_NULL)
    private List<Employee> employees=new ArrayList<>();

    public Department(String name, String description) {
        this.name = name;
        this.description = description;
    }


}
