package com.example.employeemanagement.controller;

import com.example.employeemanagement.service.RestClientService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequiredArgsConstructor

public class RestControllers {

    private final RestClientService restClientService;

    @GetMapping("/facts")
    public ResponseEntity<List<Map<String, Object>>> findAll() {
        return ResponseEntity.ok(restClientService.findAll());
    }
}