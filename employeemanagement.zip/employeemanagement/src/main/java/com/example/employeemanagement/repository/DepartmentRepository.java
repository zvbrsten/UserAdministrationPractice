package com.example.employeemanagement.repository;

import com.example.employeemanagement.entity.Department;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface DepartmentRepository extends JpaRepository<Department,Long> {
    boolean existsByName(String name);

    //Department findById(long departmentId); using JPA findById

    Optional<Department> findByName(String depName);

}

