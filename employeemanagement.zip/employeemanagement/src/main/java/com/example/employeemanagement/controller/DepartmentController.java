package com.example.employeemanagement.controller;

import com.example.employeemanagement.dto.DepartmentDTO;
import com.example.employeemanagement.dto.DepartmentResponseDTO;
import com.example.employeemanagement.dto.EmployeeResponseDTO;
import com.example.employeemanagement.entity.Employee;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.employeemanagement.response.ApiResponse;
import com.example.employeemanagement.service.DepartmentService;
import java.util.List;
import java.util.Map;


@RestController
@RequestMapping("/api/v1/departments")
@Tag(
        name = "Department",
        description = "Provides APIs for managing organizational departments. These endpoints allow users to create departments, retrieve department details, and view all departments along with their associated information."
)
public class DepartmentController {

    @Autowired
    private final DepartmentService departmentService;



    public DepartmentController(DepartmentService departmentService) {
        this.departmentService = departmentService;
    }

    // -------------------------------------------------------------------------
    // GET Endpoints
    // -------------------------------------------------------------------------

    @GetMapping
    @Operation(
            summary = "Retrieve all departments",
            description = "Fetches the complete list of departments available in the organization. Returns department details such as department identifier, name."
    )
    public ResponseEntity<ApiResponse<List<DepartmentResponseDTO>>> getAllDepartments() {
        List<DepartmentResponseDTO> departments = departmentService.getAllDepartments();
        return ResponseEntity.ok(ApiResponse.success("Departments retrieved successfully", departments));
    }

    @GetMapping("/by-departmentid/{departmentId}")
    @Operation(
            summary = "Retrieve department by ID",
            description = "Fetches a specific department using its unique department identifier. Returns information about the department if it exists; otherwise an appropriate not-found response is returned."
    )
    public ResponseEntity<ApiResponse<DepartmentResponseDTO>> getDepartmentByDepartmentEmail(@PathVariable Long departmentId) {
        DepartmentResponseDTO department = departmentService.getDepartmentById(departmentId);
        return ResponseEntity.ok(ApiResponse.success("Department retrieved successfully", department));
    }

    @GetMapping("/by-departments/")
    @Operation()
    public ResponseEntity<ApiResponse<Map<String,List<EmployeeResponseDTO>>>> getAllDepartmentsAndEmployees(){
        return ResponseEntity.ok(ApiResponse.success("Department details retrieved successfuly",departmentService.getDepartmentsAndEmployees()));
    }

    // -------------------------------------------------------------------------
    // POST Endpoints
    // -------------------------------------------------------------------------

    @PostMapping
    @Operation(
            summary = "Create a new department",
            description = "Creates a new department within the organization. The request body must contain valid department information. Validation rules are applied before the department is persisted. A conflict response may be returned if a department with the same name already exists."
    )
    public ResponseEntity<ApiResponse<Void>> createDepartment(@RequestBody @Valid DepartmentDTO departmentDTODTO) {
        departmentService.createDepartment(departmentDTODTO);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Department created successfully"));
    }

    @DeleteMapping("/{depName}")
    @Operation(
            summary="Delete a department",
            description = "Deletes a department by the provided name.Throws error if no department is found with the givne name"
    )
    public ResponseEntity<ApiResponse<Void>> deleteDepartment(@PathVariable String depName){
        departmentService.deleteDepartment(depName);
        return ResponseEntity.status(HttpStatus.OK)
                .body(ApiResponse.success("Department deleted successfully"));
    }


}
