package com.example.employeemanagement.exception;

public class DuplicatesResource extends RuntimeException{

    public DuplicatesResource(String msgs){super(msgs);}

}
