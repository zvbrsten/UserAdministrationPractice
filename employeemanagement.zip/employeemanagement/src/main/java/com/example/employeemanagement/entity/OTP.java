package com.example.employeemanagement.entity;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.redis.core.RedisHash;

import java.util.Random;

@Data
@AllArgsConstructor
@NoArgsConstructor
@RedisHash(value="OTP")
public class OTP {

    private String email;
    private String code;


    public void setCode(){

        Random random =new Random();
        String otp = String.format("%06d", random.nextInt(1_000_000));
        this.code=otp;
    }
    public String getCode(){

        return this.code;
    }
}
