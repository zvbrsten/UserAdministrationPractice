package com.example.employeemanagement.service;

import com.example.employeemanagement.dto.DepartmentDTO;
import com.example.employeemanagement.dto.DepartmentResponseDTO;

import com.example.employeemanagement.dto.EmployeeResponseDTO;
import com.example.employeemanagement.entity.Employee;
import com.example.employeemanagement.exception.DuplicatesResource;
import com.example.employeemanagement.exception.NotFound;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.example.employeemanagement.repository.DepartmentRepository;

import com.example.employeemanagement.entity.Department;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;


@Service
@Transactional
public class DepartmentService {

    private static final Logger logger = LoggerFactory.getLogger(DepartmentService.class);



    private final DepartmentRepository departmentRepository;

    public DepartmentService(DepartmentRepository departmentRepository) {
        this.departmentRepository=departmentRepository;
    }


    public List<DepartmentResponseDTO> getAllDepartments() {
        logger.info("Fetching all departments");
        return departmentRepository.findAll().stream().map(x->new DepartmentResponseDTO(x)).toList();

    }


    @Transactional
    public DepartmentResponseDTO createDepartment(DepartmentDTO departmentDTO) {
        logger.info("Creating Department [{}]", departmentDTO.getName());
        if (departmentRepository.existsByName(departmentDTO.getName())) {
            throw new DuplicatesResource("Department already exists");

        }
        Department department = new Department(departmentDTO.getName(),departmentDTO.getDescription());
        Department savedDepartment = departmentRepository.save(department);
        logger.info("Department [{}] created with id [{}]", savedDepartment.getName(),savedDepartment.getId());
        return DepartmentResponseDTO.builder().name(department.getName()).id(department.getId()).build();
    }



    @Transactional
    public DepartmentResponseDTO getDepartmentById(Long id){
        logger.info("Fetching Department by [{}]", id);
        Department department= departmentRepository.findById(id).orElseThrow(()->new RuntimeException("Department with" + id+" not found"));
        DepartmentDTO departmentDTO = new DepartmentDTO(department);
        logger.info("Fetched Department by [{}]", id);
        return DepartmentResponseDTO.builder().name(department.getName()).id(department.getId()).build();
    }

    @Transactional
    public Map<String,List<EmployeeResponseDTO>> getDepartmentsAndEmployees(){

        List<Department> departments= departmentRepository.findAll();
        Map<String,List<EmployeeResponseDTO>> map=new HashMap<>();


        departments.forEach(x->map.put(new DepartmentResponseDTO(x).getName(),
                x.getEmployees().stream().map(EmployeeResponseDTO::new).toList()));

        return map;
    }

    @Transactional
    public void deleteDepartment(String depName){
        departmentRepository.delete(departmentRepository.findByName(depName).orElseThrow(()->new NotFound("Department doesnt exist with this name")));
    }
    
}

