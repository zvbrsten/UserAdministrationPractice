package com.example.employeemanagement.controller;


import com.example.employeemanagement.auth.AuthController;
import com.example.employeemanagement.dto.EmployeeDTO;
import com.example.employeemanagement.dto.EmployeeResponseDTO;
import com.example.employeemanagement.entity.Employee;
import com.example.employeemanagement.exception.GlobalExceptionHandler;
import com.example.employeemanagement.exception.NotFound;
import com.example.employeemanagement.repository.DepartmentRepository;
import com.example.employeemanagement.repository.EmployeeRepository;
import com.example.employeemanagement.repository.RoleRepository;
import com.example.employeemanagement.security.util.JwtUtil;
import io.jsonwebtoken.io.IOException;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import com.example.employeemanagement.response.ApiResponse;
import com.example.employeemanagement.service.EmployeeService;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;


@RestController
@RequestMapping("/api/v1/employees")
@Tag(
        name = "Employees",
        description = "Provides APIs for managing employee records including employee creation, retrieval, update, deletion, and department-based employee searches. These endpoints support complete employee lifecycle management within the organization."
)
public class EmployeeController {

    @Autowired
    private final EmployeeService employeeService;

    private GlobalExceptionHandler globalExceptionHandler;
    private final DepartmentRepository departmentRepository;
    private final EmployeeRepository employeeRepository;


    public EmployeeController(EmployeeService employeeService,
                              DepartmentRepository departmentRepository,
                              EmployeeRepository employeeRepository) {
        this.employeeService = employeeService;
        this.departmentRepository = departmentRepository;
        this.employeeRepository = employeeRepository;
    }

    // -------------------------------------------------------------------------
    // GET Endpoints
    // -------------------------------------------------------------------------

    @GetMapping
    @Operation(
            summary = "Retrieve all employees",
            description = "Fetches the complete list of employees available in the system. Returns employee details including DepartmentId,email,firstName,LastName."
    )
    public ResponseEntity<ApiResponse<List<EmployeeResponseDTO>>> getAllEmployees() {
        List<EmployeeResponseDTO> employees = employeeService.getAllEmployees();

        return ResponseEntity.ok(ApiResponse.success("Employees retrieved successfully", employees));
    }

    @GetMapping("/email/{email}")
    public ResponseEntity<ApiResponse<List<EmployeeResponseDTO>>> getEmployeebyEmail(@PathVariable @Valid String email) {
        List<EmployeeResponseDTO> employee = employeeRepository.findByEmail(email).stream().map(e->new EmployeeResponseDTO(e)).toList();

        return ResponseEntity.ok(ApiResponse.success("Employees retrieved successfully", employee));
    }

    @GetMapping("/{id}")
    @Operation(
            summary = "Retrieve employee by ID",
            description = "Fetches a specific employee using the unique employee ID. Returns detailed employee information if the employee exists; otherwise an appropriate not-found response is returned."
    )
    public ResponseEntity<ApiResponse<EmployeeResponseDTO>> findEmployeeByID(@PathVariable Long id) {
        EmployeeDTO employees = employeeService.getEmployeeById(id);
        return ResponseEntity.ok(ApiResponse.success("Employee retrieved successfully", EmployeeResponseDTO.builder().email(employees.getEmail()).lastName(employees.getLastName()).firstName(employees.getFirstName()).id(employees.getId())
                        .departmentId(employees.getDepartmentId())
                .build()));
    }
    @GetMapping("/by-department/{departmentName}")
    @Operation(
            summary = "Retrieve employees by department",
            description = "Returns all employees belonging to the specified department. The department name is supplied as a path variable. If the department does not exist or contains no employees, an appropriate error response is returned."
    )
    public ResponseEntity<ApiResponse<List<EmployeeResponseDTO>>> findEmployeeByDep(@PathVariable String departmentName) {
        List<Employee> employees = employeeService.getEmployeeByDepartment(departmentName);
        if(employees.isEmpty()){
            throw new NotFound("No employees in the given department");
        }
        return ResponseEntity.ok(ApiResponse.success("Employees retrieved successfully", employees.stream().map(x->new EmployeeResponseDTO(x)).toList()));
    }


    // -------------------------------------------------------------------------
    // POST , PATCH Endpoints
    // -------------------------------------------------------------------------

    @PostMapping("/register")
    @Operation(
            summary = "Create a new employee",
            description = "Creates a new employee record in the system. The request body must contain valid employee information including name, email, phone number, designation, salary, and department details. Validation rules are applied before persisting the employee."
    )
    public ResponseEntity<ApiResponse<EmployeeResponseDTO>> createEmployee(@RequestBody @Valid EmployeeDTO employeeDTO) {
        EmployeeResponseDTO employeeResponseDTO=employeeService.createEmployee(employeeDTO);

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Employee created successfully",employeeResponseDTO));
    }
    @GetMapping(value = "/profilepic/{email}")
    public ResponseEntity<byte[]> getProfilepic(@PathVariable String email) {

        Employee employee=employeeRepository.findByEmail(email).orElseThrow(()->new NotFound("Email not found"));
        try {
            byte[] profilepicture=employee.getProfilepicture();
            HttpHeaders headers=new HttpHeaders();
            headers.setContentType(MediaType.parseMediaType(MediaType.IMAGE_PNG.toString()));
            headers.setContentLength(profilepicture.length);
            return new ResponseEntity<>(profilepicture,headers,HttpStatus.OK);
        }
        catch (Exception ex){
            throw new IOException(ex.getMessage());
        }

    }

    @PatchMapping(value = "/profilepic/{email}",consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<ApiResponse<EmployeeResponseDTO>> uploadProfilepic(@PathVariable String email, @RequestPart(value="profilepicture")MultipartFile profilepicture) {

        Employee employee=employeeRepository.findByEmail(email).orElseThrow(()->new NotFound("Email not found"));
        try {
            employee.setProfilepicture(profilepicture.getBytes());
            employeeRepository.save(employee);
            EmployeeResponseDTO emp=new EmployeeResponseDTO(employee);
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(ApiResponse.success("Uploaded Profile pic successfully",emp));
        }
        catch (Exception ex){
            throw new IOException(ex.getMessage());
        }

    }


    @PatchMapping("/update/email/{employeeEmail}")
    @Operation(
            summary = "Partially update an employee",
            description = "Updates an existing employee identified by email address. Only the fields provided in the request body are updated, while omitted fields retain their existing values. Validation is performed on all supplied fields."
    )
    public ResponseEntity<ApiResponse<EmployeeResponseDTO>> updateEmployeeName(
            @PathVariable String employeeEmail,
            @Valid @RequestBody  EmployeeDTO employeeDTO) {
        EmployeeResponseDTO employeeResponseDTO =employeeService.updateEmployee(employeeEmail, employeeDTO);
        return ResponseEntity.status(HttpStatus.OK)
                .body(ApiResponse.success("Employee created successfully",employeeResponseDTO));
    }





    // -------------------------------------------------------------------------
    // DELETE Endpoints
    // -------------------------------------------------------------------------

    @DeleteMapping("/{employeeId}")
    @Operation(
            summary = "Delete employee by ID",
            description = "Removes an employee record from the system using the employee's unique identifier. If the employee does not exist, a not-found response is returned."
    )
    public ResponseEntity<ApiResponse<Void>> deleteEmployee(@PathVariable Long employeeId) {
        employeeService.deleteEmployee(employeeId);
        return ResponseEntity.status(HttpStatus.OK)
                .body(ApiResponse.success("Employee created successfully"));
    }
}
