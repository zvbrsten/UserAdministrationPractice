package com.example.employeemanagement.exception;

import com.example.employeemanagement.response.ApiResponse;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;


import java.util.HashMap;
import java.util.Map;

@RestControllerAdvice
public class GlobalExceptionHandler{
    @ExceptionHandler(NotFound.class)
    public ResponseEntity<ApiResponse<String>> handleNotFoundException(NotFound ex,HttpServletRequest request){



        String errorMessage = ex.getMessage();
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body(ApiResponse.failure(errorMessage));
    }
    @ExceptionHandler(DuplicatesResource.class)
    public ResponseEntity<ApiResponse<String>> handleDuplicateResource(
            DuplicatesResource ex,HttpServletRequest request) {




        return ResponseEntity.status(HttpStatus.CONFLICT)
                .body(ApiResponse.failure(ex.getMessage()));
    }
    @ExceptionHandler(NoSuchMethodError.class)
    public ResponseEntity<ApiResponse<String>> handleNoSuchMethodException(NoSuchMethodError ex,HttpServletRequest request){

        String errorMessage = ex.getMessage();
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(ApiResponse.failure(errorMessage));
    }


    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ApiResponse<Map<String, String>>> handleValidation(
            MethodArgumentNotValidException ex) {

        Map<String, String> errors = new HashMap<>();

        ex.getBindingResult()
                .getFieldErrors()
                .forEach(error ->
                        errors.put(error.getField(), error.getDefaultMessage()));

        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(ApiResponse.failure(errors.toString()));
    }



    @ExceptionHandler(Exception.class)
    public  ResponseEntity<ApiResponse<String>> handleException(Exception ex,HttpServletRequest request)throws  Exception{

        String errorMessage = ex.getMessage();
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(ApiResponse.failure(errorMessage));
    }

}
