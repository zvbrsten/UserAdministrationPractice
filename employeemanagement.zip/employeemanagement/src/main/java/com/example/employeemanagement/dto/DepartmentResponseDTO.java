package com.example.employeemanagement.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.example.employeemanagement.entity.Department;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DepartmentResponseDTO{

    private Long id;
    @NotBlank
    private String name;


    public DepartmentResponseDTO(Department department) {
        this.id= department.getId();
        this.name=department.getName();

    }
}
