package com.example.employeemanagement.dto;

public record LoginResponseDTO(String msg, UserDTO userDTO, String jwtToken) {
}
