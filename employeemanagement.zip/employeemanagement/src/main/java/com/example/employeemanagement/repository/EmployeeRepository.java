package com.example.employeemanagement.repository;


import com.example.employeemanagement.entity.Employee;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;


public interface EmployeeRepository extends JpaRepository<Employee,Long> {
    boolean existsByEmail(String email);

    @Cacheable("employees")
    Optional<Employee> findByEmail(String email);

    Optional<Employee> findByJoiningDateAfter(LocalDate joiningDate);

//    Sort sort= Sort.by("departmentId");
//
//
//    Page<Employee> findAll(PageRequest pageRequest);



}
