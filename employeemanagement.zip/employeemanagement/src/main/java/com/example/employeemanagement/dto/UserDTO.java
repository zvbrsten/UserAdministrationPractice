package com.example.employeemanagement.dto;



import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.time.Instant;

@Getter
@Setter
@ToString
public class UserDTO {

    private Long userId;
    private String firstname;
    private String email;
    private String mobileNumber;
    private String role;


}
