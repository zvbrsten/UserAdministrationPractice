package com.example.employeemanagement.dto;



import com.fasterxml.jackson.annotation.JsonInclude;
import com.example.employeemanagement.entity.Employee;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDate;
import java.time.LocalDateTime;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EmployeeResponseDTO{

    private Long id;
    @NotBlank(message="firstname cant be blank")
    private String firstName;
    @NotBlank(message="lastname cant be blank")
    private String lastName;
    @Email(message = "Enter valid emailID")
    private String email;

////////////////////////////////////////////////////////////////////////////Commented as unsure if to be included in Response


//    @NotBlank
//    @Size(min = 10, max = 10)
//    @Pattern(regexp = "^[0-9]+$",message = "Enter valid Phone Number")
//    private String phone;
//
//    private LocalDateTime createdAt;
//    private LocalDateTime updatedAt;
//    private  String designation;
//    @Min(value = 1,message = "Salary should be greater than 0")
//    private Long salary;
//    @PastOrPresent(message = "Cant allow future joining Date")
//    private LocalDate joiningDate;
    private Long departmentId;


    public EmployeeResponseDTO(Employee employee){
        this.firstName=employee.getFirstName();
        this.lastName=employee.getLastName();
        this.email=employee.getEmail();
//        this.phone=employee.getPhone();
//        this.designation=employee.getDesignation();
//        this.salary=employee.getSalary();
        this.departmentId=employee.getDepartment().getId();

    }
}
