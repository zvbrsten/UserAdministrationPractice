package com.example.employeemanagement.entity;


import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name="employees")
@Getter
@Setter
@NoArgsConstructor
public class Employee extends BaseAuditing{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "firstname", nullable = false, length = 50)
    @NotBlank(message="firstname cant be blank")
    private String firstName;

    @Column(name = "lastname", nullable = false, length = 50)
    @NotBlank(message="lastname cant be blank")
    private String lastName;

    @Column(name = "email", unique = true, nullable = false, length = 150)
    @Email(message = "Enter valid emailID")
    private String email;

    @Column(name="profilepicture")
    private byte[] profilepicture;

    @Column(name = "phone", unique = true, nullable = false, length = 10)
    @NotBlank
    @Size(min = 10, max = 10)
    @Pattern(regexp = "^[0-9]+$")
    private String phone;


//    @CreationTimestamp
//    @Column(name = "created_at", nullable = false, updatable = false)
//    private LocalDateTime createdAt;
//
//    @UpdateTimestamp
//    @Column(name = "updated_at", nullable = false)
//    private LocalDateTime updatedAt;

    @Column(name="designation")
    private String designation;

    @Column(name="salary")
    @Min(1)
    private Long salary;

    @Size(max = 500)
    @NotNull
    @Column(name = "password_hash", nullable = false, length = 500)
    private String passwordHash;

    @Column(name="joiningDate",updatable=false)
    @PastOrPresent
    private LocalDate joiningDate;

    @ManyToOne
    @JoinColumn(name="department_id",nullable=true)
    private Department department;

    @NotNull
    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "role_id", nullable = false)
    private Role role;


    public Employee(String firstName, String lastName, String email, String phone, String designation, long salary, LocalDate joiningDate, Department department) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.phone = phone;
        this.designation = designation;
        this.salary = salary;
        this.joiningDate = joiningDate;
        this.department = department;
    }


    public Employee(EmployeeUser employee) {
        this.email=employee.getEmail();
        this.phone=employee.getPhone();
        this.firstName=employee.getFirstName();
        this.lastName=employee.getLastName();
    }
}
