package com.example.employeemanagement.auth;

import com.example.employeemanagement.constants.ApplicationConstants;
import com.example.employeemanagement.dto.*;
import com.example.employeemanagement.entity.Department;
import com.example.employeemanagement.entity.Employee;
import com.example.employeemanagement.entity.EmployeeUser;
import com.example.employeemanagement.repository.DepartmentRepository;
import com.example.employeemanagement.repository.EmployeeRepository;
import com.example.employeemanagement.repository.EmployeeUserRepository;
import com.example.employeemanagement.repository.RoleRepository;
import com.example.employeemanagement.response.ApiResponse;
import com.example.employeemanagement.security.util.JwtUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.authentication.password.CompromisedPasswordChecker;
import org.springframework.security.authentication.password.CompromisedPasswordDecision;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.employeemanagement.entity.Role;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/auth")
@RequiredArgsConstructor
public class AuthController {
    private final AuthenticationManager authenticationManager;
    private final JwtUtil jwtUtil;
    //private final CompromisedPasswordChecker compromisedPasswordChecker;
    private final PasswordEncoder passwordEncoder;
    private final EmployeeRepository employeeRepository;
    private final DepartmentRepository departmentRepository;
    private final EmployeeUserRepository employeeUserRepository;
    private final RoleRepository roleRepository;


//    private final ApplicationConstants applicationConstants;



    @PostMapping(value = "/login/public")
    public ResponseEntity<LoginResponseDTO> apiLogin(@RequestBody LoginRequestDTO loginRequestDto) {

        try {

            var resultAuthentication = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(loginRequestDto.Email(),
                    loginRequestDto.password()));
            // Generate JWT token
            String jwtToken = jwtUtil.generateJwtToken(resultAuthentication);
            var userDto = new UserDTO();
            return ResponseEntity.status(HttpStatus.OK)
                    .body(new LoginResponseDTO(HttpStatus.OK.getReasonPhrase(),
                            userDto, jwtToken));
        } catch (BadCredentialsException ex) {

            return buildErrorResponse(HttpStatus.UNAUTHORIZED,
                    ex.getMessage());
        } catch (AuthenticationException ex) {
            return buildErrorResponse(HttpStatus.UNAUTHORIZED,
                    "Authentication failed");
        } catch (Exception ex) {
            return buildErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR,
                    ex.getMessage());
        }

    }
//    @PostMapping(value = "/register/public")
//    public ResponseEntity<ApiResponse<String>> registerUser(@RequestBody RegisterRequestDTO registerRequestDto) {
////        CompromisedPasswordDecision decision = compromisedPasswordChecker
////                .check(registerRequestDto.password());
////        if (decision.isCompromised()) {
////            return ResponseEntity.badRequest().body(ApiResponse.failure("Choose Strong Password"));
////
////        }
//        Optional<Employee> existingEmployee = employeeRepository.findByEmail(
//                (registerRequestDto.email()));
//
//        if (existingEmployee.isPresent()) {
//            Map<String, String> errors = new HashMap<>();
//            Employee employee = existingEmployee.get();
//            if (employee.getEmail().equalsIgnoreCase(registerRequestDto.email())) {
//                errors.put("email", "Email is already registered");
//            }
//            if (employee.getPhone().equals(registerRequestDto.phone())) {
//                errors.put("mobileNumber", "Mobile number is already registered");
//            }
//            return ResponseEntity.badRequest().body( ApiResponse.failure("Employee already exists with the given details"));
//        }
//        Employee employee = new Employee();
//        BeanUtils.copyProperties(registerRequestDto, employee);
//
//        employee.setPasswordHash(passwordEncoder.encode(registerRequestDto.password()));
//
//        Role role = roleRepository.findByName(ApplicationConstants.ROLE_USER)
//                .orElseThrow(() -> new IllegalArgumentException("Role not found: " +
//                        ApplicationConstants.ROLE_USER));
//        employee.setRole(role);
//        employeeRepository.save(employee);
//        return ResponseEntity.ok(ApiResponse.success("Employee Registered Successfully. Update remaining details using /update/email/{employeeEmail}")) ;
//    }



    private ResponseEntity<LoginResponseDTO> buildErrorResponse(HttpStatus status,
                                                                String message) {
        return ResponseEntity
                .status(status)
                .body(new LoginResponseDTO(message, null, null));
    }
}
