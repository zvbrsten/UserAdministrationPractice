package com.example.employeemanagement.security;


import com.example.employeemanagement.exception.NotFound;
import com.example.employeemanagement.repository.EmployeeRepository;
import com.example.employeemanagement.repository.EmployeeUserRepository;
import com.example.employeemanagement.security.filter.JwtTokenValidatorFilter;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Qualifier;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;

import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
import org.springframework.security.web.csrf.CookieCsrfTokenRepository;
import org.springframework.security.web.csrf.CsrfTokenRequestAttributeHandler;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.security.authentication.AuthenticationProvider;


import java.util.*;
import java.util.stream.Collectors;


@Configuration
@EnableWebSecurity
@RequiredArgsConstructor
public class SecurityConfig {

    @Qualifier("publicPaths")
    private final List<String> publicPaths;

    @Qualifier("securedPaths")
    private final List<String> securedPaths;

    private final EmployeeRepository employeeRepository;

    @Bean
    //@Order(SecurityFilterProperties.BASIC_AUTH_ORDER) use if multiple beans
    SecurityFilterChain defaultSecurityFilterChain(HttpSecurity http){

       return http.authorizeHttpRequests((requests)->{
           publicPaths.forEach(path->requests.requestMatchers(path).permitAll());
           securedPaths.forEach(path->requests.requestMatchers(path).permitAll());//designation should have " Admin" in the end
           requests.anyRequest().denyAll();

       })
               .csrf(csrf->csrf.disable())
//               .csrf(csrfConfig->csrfConfig.csrfTokenRepository(CookieCsrfTokenRepository.withHttpOnlyFalse())
//                       .csrfTokenRequestHandler(new CsrfTokenRequestAttributeHandler()))
               .cors(corsConfig->corsConfig.configurationSource(corsConfigurationSource()))
               .addFilterBefore(new JwtTokenValidatorFilter(publicPaths), BasicAuthenticationFilter.class)
                .formLogin(flc -> flc.disable())//disables the ui page of login while calling api from browser
                .httpBasic(h->h.disable())
                .build();

       //formlogin for ui based login,httpbasic for popup based or postman basic auth login



    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource(){
        CorsConfiguration config=new CorsConfiguration();
        config.setAllowedOrigins(Arrays.asList("http://localhost:5173"));
        config.setAllowedMethods(Collections.singletonList("*"));
        config.setAllowedHeaders(Collections.singletonList("*"));
        config.setAllowCredentials(true);
        config.setMaxAge(3600L);

        UrlBasedCorsConfigurationSource source=new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**",config);
        return source;

    }


    @Bean
    public UserDetailsService userDetailsService(EmployeeRepository repository) {
        return username -> repository.findByEmail(username)
                .map(user -> User.builder()
                        .username(user.getEmail())
                        .password(user.getPasswordHash())
                        .roles(user.getRole().getName())
                        .build())
                .orElseThrow(() ->
                        new UsernameNotFoundException(
                                "User not found: " + username));
    }

    @Bean
    public AuthenticationManager authenticationManager(EmployeeRepository employeeRepository) {
        var autheticationProvider = new DaoAuthenticationProvider(userDetailsService(employeeRepository));
        autheticationProvider.setPasswordEncoder(passwordEncoder());
        return new ProviderManager(autheticationProvider);
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

}
