package com.example.employeemanagement.controller;


import com.example.employeemanagement.dto.RoleDTO;
import com.example.employeemanagement.entity.Role;
import com.example.employeemanagement.repository.RoleRepository;
import com.example.employeemanagement.response.ApiResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/v1/roles")
public class RoleController {

    private final RoleRepository roleRepository;

    public RoleController(RoleRepository roleRepository) {
        this.roleRepository = roleRepository;
    }


    @GetMapping
    public ResponseEntity<ApiResponse<List<RoleDTO>>> getAllRoles(){

        List<RoleDTO> roles=roleRepository.findAll().stream().map(x->new RoleDTO(x)).toList();
        return ResponseEntity.ok(ApiResponse.success("ALL Roles :",roles));
    }
}
