package com.example.employeemanagement.dto;

public record LoginRequestDTO(String Email,String password)
{
}
