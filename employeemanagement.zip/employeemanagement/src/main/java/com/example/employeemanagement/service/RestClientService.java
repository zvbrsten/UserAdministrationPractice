package com.example.employeemanagement.service;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import java.util.List;
import java.util.Map;

@Service
public class RestClientService {

    private final RestClient restClient;

    public RestClientService(RestClient.Builder builder) {
        this.restClient = builder
                .baseUrl("https://cat-fact.herokuapp.com")
                .defaultHeader("Accept", "application/json")
                .build();
    }


    public List<Map<String, Object>> findAll() {
        return restClient.get()
                .uri("/facts")
                .retrieve()
                .onStatus(HttpStatusCode::isError, (request, response) -> {
                    throw new IllegalStateException("Failed to fetch cat facts");
                })
                .body(new ParameterizedTypeReference<List<Map<String, Object>>>() {});
    }
}