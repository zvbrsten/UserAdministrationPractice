package com.example.employeemanagement.dto;

import com.example.employeemanagement.entity.Role;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.example.employeemanagement.entity.Department;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RoleDTO{


    @NotBlank
    private String name;
    @NotBlank
    List<String> employees;


    public RoleDTO(Role role) {
        this.name= role.getName();
        this.employees=role.getEmployees().stream().map(x->x.getEmail()).toList();
    }
}
