# RBAC User Administration System

A **production-grade Role-Based Access Control (RBAC) system** built with Spring Boot, following **Domain-Driven Design (DDD)** principles.

## Tech Stack

| Layer | Technology |
|---|---|
| Language | Java 17 |
| Framework | Spring Boot 4.x |
| Security | Spring Security (HTTP Basic + JDBC) |
| Persistence | Spring Data JPA + Hibernate |
| Database | PostgreSQL (prod/dev), H2 (test) |
| Caching / OTP | Redis (Jedis) |
| Email | Spring Mail (SMTP) |
| API Docs | SpringDoc OpenAPI 3 (Swagger UI) |
| Build | Maven |
| Monitoring | Spring Boot Actuator |
| Containerization | Docker + Docker Compose |

## Quick Start (Development)

### Prerequisites
- Java 17+
- Maven 3.8+
- Docker + Docker Compose

### 1. Start the database

```bash
docker-compose up database -d
```

### 2. Run the application (dev profile)

```bash
./mvnw spring-boot:run -Dspring-boot.run.profiles=dev
```

### 3. Access the API

- **Swagger UI:** http://localhost:8080/swagger-ui.html
- **OpenAPI JSON:** http://localhost:8080/v3/api-docs
- **Actuator Health:** http://localhost:8080/actuator/health

### Default credentials (from database)

Seed your database using the initial SQL scripts or the `DataSeeder` bootstrap (see `docs/SOP.md`).

## Project Structure

```
src/main/java/com/company/rbac/
├── user/             # User domain
├── role/             # Role domain
├── permission/       # Permission domain
├── module/           # Module domain
├── rbac/             # RBAC mapping domain (Role-Module-Permission)
├── notification/     # Email notifications
└── shared/           # Shared exceptions, configs, response wrappers
```

See [ARCHITECTURE.md](docs/ARCHITECTURE.md) for a full explanation of the DDD structure.

## API Endpoints

See [API.md](docs/API.md) for the complete API reference.

## Configuration

| Profile | Purpose | Activate with |
|---|---|---|
| `dev` | Local development with Docker PostgreSQL | `--spring.profiles.active=dev` |
| `prod` | Production — all secrets via env vars | `--spring.profiles.active=prod` |
| `test` | Integration tests with H2 in-memory | `@ActiveProfiles("test")` |

## Environment Variables (Production)

| Variable | Description |
|---|---|
| `DATABASE_HOST` | PostgreSQL host |
| `DATABASE_PORT` | PostgreSQL port |
| `DATABASE_NAME` | Database name |
| `DATABASE_USER` | Database username |
| `DATABASE_PASSWORD` | Database password |
| `MAIL_HOST` | SMTP host |
| `MAIL_USERNAME` | SMTP username |
| `MAIL_PASSWORD` | SMTP password |
| `REDIS_HOST` | Redis host |
| `REDIS_PORT` | Redis port |
| `JWT_SECRET` | HMAC-SHA256 signing key — minimum 32 characters |
| `JWT_EXPIRATION_MS` | Token validity in milliseconds (default: 86400000 = 24h) |
