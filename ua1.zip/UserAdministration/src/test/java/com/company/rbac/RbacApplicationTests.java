package com.company.rbac;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

/**
 * Smoke test that verifies the application context loads successfully.
 *
 * <p>Uses the {@code test} profile which configures an H2 in-memory database,
 * so no external PostgreSQL or Redis instance is required to run tests.</p>
 */
@SpringBootTest
@ActiveProfiles("test")
class RbacApplicationTests {

    @Test
    void contextLoads() {
        // If this test passes, the entire Spring context initialized without errors.
    }
}
