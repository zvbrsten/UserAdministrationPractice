package com.company.rbac.rbac.presentation.controller;

import com.company.rbac.rbac.application.dto.RoleModulePermissionRequest;
import com.company.rbac.rbac.application.dto.RoleModulePermissionResponse;
import com.company.rbac.rbac.application.service.RbacMappingApplicationService;
import com.company.rbac.shared.response.ApiResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST controller for RBAC mapping (Role–Module–Permission) endpoints.
 * All routes are versioned under {@code /api/v1/rbac}.
 */
@RestController
@RequestMapping("/api/v1/rbac")
@Tag(name = "RBAC Mappings", description = "Role-Module-Permission mapping operations")
public class RbacController {

    private final RbacMappingApplicationService rbacMappingApplicationService;

    public RbacController(RbacMappingApplicationService rbacMappingApplicationService) {
        this.rbacMappingApplicationService = rbacMappingApplicationService;
    }

    @GetMapping
    @Operation(summary = "List all role-module-permission mappings")
    public ResponseEntity<ApiResponse<List<RoleModulePermissionResponse>>> getAllMappings() {
        List<RoleModulePermissionResponse> mappings = rbacMappingApplicationService.getAllMappings();
        return ResponseEntity.ok(ApiResponse.success("RBAC mappings retrieved successfully", mappings));
    }

    @PostMapping
    @Operation(summary = "Create a new role-module-permission mapping")
    public ResponseEntity<ApiResponse<RoleModulePermissionResponse>> createMapping(
            @RequestBody @Valid RoleModulePermissionRequest request) {
        RoleModulePermissionResponse created = rbacMappingApplicationService.createMapping(request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("RBAC mapping created successfully", created));
    }
}
