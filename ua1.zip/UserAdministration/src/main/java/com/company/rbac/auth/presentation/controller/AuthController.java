package com.company.rbac.auth.presentation.controller;

import com.company.rbac.auth.application.dto.AuthResponse;
import com.company.rbac.auth.application.dto.LoginRequest;
import com.company.rbac.auth.application.service.AuthApplicationService;
import com.company.rbac.shared.response.ApiResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * REST controller for authentication endpoints.
 *
 * <p>The {@code /api/v1/auth/**} path is explicitly permitted (no auth required)
 * in {@link com.company.rbac.shared.config.SecurityConfig}.</p>
 *
 * <h3>Usage Flow:</h3>
 * <pre>
 *   POST /api/v1/auth/login  →  { "username": "...", "password": "..." }
 *   Response                 →  { "accessToken": "eyJ...", "tokenType": "Bearer", ... }
 *
 *   Subsequent requests:
 *   Authorization: Bearer eyJ...
 * </pre>
 */
@RestController
@RequestMapping("/api/v1/auth")
@Tag(name = "Authentication", description = "Login and token management")
public class AuthController {

    private final AuthApplicationService authApplicationService;

    public AuthController(AuthApplicationService authApplicationService) {
        this.authApplicationService = authApplicationService;
    }

    /**
     * Authenticates a user and returns a signed JWT access token.
     *
     * @param request login credentials (username + password)
     * @return 200 OK with {@link AuthResponse} containing the JWT token
     */
    @PostMapping("/login")
    @Operation(
        summary = "Login and obtain a JWT token",
        description = "Submit username and password to receive a Bearer token for subsequent API calls."
    )
    public ResponseEntity<ApiResponse<AuthResponse>> login(@RequestBody @Valid LoginRequest request) {
        AuthResponse authResponse = authApplicationService.login(request);
        return ResponseEntity.ok(ApiResponse.success("Login successful", authResponse));
    }
}
