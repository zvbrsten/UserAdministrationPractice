package com.company.rbac.rbac.application.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/**
 * Request DTO for creating a Role–Module–Permission mapping.
 */
@Data
public class RoleModulePermissionRequest {

    @NotBlank(message = "Role name cannot be empty")
    private String roleName;

    @NotBlank(message = "Module name cannot be empty")
    private String moduleName;

    @NotBlank(message = "Permission name cannot be empty")
    private String permissionName;
}
