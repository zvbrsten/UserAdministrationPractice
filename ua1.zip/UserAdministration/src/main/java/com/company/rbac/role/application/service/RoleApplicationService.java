package com.company.rbac.role.application.service;

import com.company.rbac.role.application.dto.RoleRequest;
import com.company.rbac.role.application.dto.RoleResponse;
import com.company.rbac.role.domain.entity.Role;
import com.company.rbac.role.domain.exception.RoleNotFoundException;
import com.company.rbac.role.domain.repository.RoleRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Application service orchestrating all role-related use cases.
 */
@Service
@Transactional(readOnly = true)
public class RoleApplicationService {

    private static final Logger logger = LoggerFactory.getLogger(RoleApplicationService.class);

    private final RoleRepository roleRepository;

    public RoleApplicationService(RoleRepository roleRepository) {
        this.roleRepository = roleRepository;
    }

    /**
     * Retrieves all roles in the system.
     */
    public List<RoleResponse> getAllRoles() {
        logger.info("Fetching all roles");
        return roleRepository.findAll().stream()
                .map(this::toResponse)
                .toList();
    }

    /**
     * Creates a new role.
     *
     * @param request the role creation request
     * @throws IllegalArgumentException if the role name already exists
     */
    @Transactional
    public RoleResponse createRole(RoleRequest request) {
        logger.info("Creating role [{}]", request.getRoleName());
        if (roleRepository.existsByRoleName(request.getRoleName())) {
            throw new IllegalArgumentException("Role [" + request.getRoleName() + "] already exists.");
        }
        Role role = new Role(request.getRoleName());
        Role savedRole = roleRepository.save(role);
        logger.info("Role [{}] created with id [{}]", savedRole.getRoleName(), savedRole.getId());
        return toResponse(savedRole);
    }

    /**
     * Updates the name of an existing role, identified by its current name.
     *
     * @param currentRoleName the current role name (path variable)
     * @param request         the update request
     * @throws RoleNotFoundException if the role is not found
     */
    @Transactional
    public RoleResponse updateRole(String currentRoleName, RoleRequest request) {
        logger.info("Updating role [{}] to [{}]", currentRoleName, request.getRoleName());
        Role role = roleRepository.findByRoleName(currentRoleName)
                .orElseThrow(() -> new RoleNotFoundException(currentRoleName));
        role.setRoleName(request.getRoleName());
        roleRepository.save(role);
        logger.info("Role [{}] updated successfully", request.getRoleName());
        return toResponse(role);
    }

    /**
     * Deletes a role by its name.
     *
     * @param roleName the name of the role to delete
     * @throws RoleNotFoundException if the role is not found
     */
    @Transactional
    public void deleteRole(String roleName) {
        logger.info("Deleting role [{}]", roleName);
        Role role = roleRepository.findByRoleName(roleName)
                .orElseThrow(() -> new RoleNotFoundException(roleName));
        roleRepository.delete(role);
        logger.info("Role [{}] deleted successfully", roleName);
    }

    // -------------------------------------------------------------------------
    // Private mapping helper
    // -------------------------------------------------------------------------

    private RoleResponse toResponse(Role role) {
        return RoleResponse.builder()
                .id(role.getId())
                .roleName(role.getRoleName())
                .build();
    }
}
