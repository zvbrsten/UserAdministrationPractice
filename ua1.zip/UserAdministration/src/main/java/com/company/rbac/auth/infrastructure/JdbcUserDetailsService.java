package com.company.rbac.auth.infrastructure;

import com.company.rbac.user.domain.entity.User;
import com.company.rbac.user.domain.repository.UserRepository;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Custom {@link UserDetailsService} implementation that loads user credentials
 * from the PostgreSQL database via {@link UserRepository}.
 *
 * <p>This service is used by Spring Security's {@code AuthenticationManager}
 * during the login process (JWT issuance) to verify username and password.
 * After login, subsequent requests are authenticated via the JWT filter — this
 * service is NOT called again per request.</p>
 *
 * <p>Grants a single authority per user, prefixed with {@code ROLE_} as required
 * by Spring Security's {@code hasRole()} / {@code hasAnyRole()} conventions.</p>
 */
@Service
public class JdbcUserDetailsService implements UserDetailsService {

    private final UserRepository userRepository;

    public JdbcUserDetailsService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    /**
     * Loads a user by their username for authentication.
     *
     * @param username the username submitted during login
     * @return a populated {@link UserDetails} object
     * @throws UsernameNotFoundException if the user is not found or has been deleted
     */
    @Override
    @Transactional(readOnly = true)
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = userRepository.findByUserNameAndIsDeletedFalse(username)
                .orElseThrow(() -> new UsernameNotFoundException(
                        "User not found or has been deactivated: " + username));

        // Prefix the role name with ROLE_ to match Spring Security convention
        String roleAuthority = "ROLE_" + user.getRole().getRoleName();

        return org.springframework.security.core.userdetails.User.builder()
                .username(user.getUserName())
                .password(user.getPassword())        // BCrypt-hashed password from DB
                .authorities(List.of(new SimpleGrantedAuthority(roleAuthority)))
                .accountExpired(false)
                .accountLocked(!user.getIsActive())  // Inactive users cannot log in
                .credentialsExpired(false)
                .disabled(user.getIsDeleted())
                .build();
    }
}
