package com.company.rbac.role.presentation.controller;

import com.company.rbac.role.application.dto.RoleRequest;
import com.company.rbac.role.application.dto.RoleResponse;
import com.company.rbac.role.application.service.RoleApplicationService;
import com.company.rbac.shared.response.ApiResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST controller for Role management endpoints.
 * All routes are versioned under {@code /api/v1/roles}.
 */
@RestController
@RequestMapping("/api/v1/roles")
@Tag(name = "Roles", description = "Role management operations")
public class RoleController {

    private final RoleApplicationService roleApplicationService;

    public RoleController(RoleApplicationService roleApplicationService) {
        this.roleApplicationService = roleApplicationService;
    }

    @GetMapping
    @Operation(summary = "List all roles")
    public ResponseEntity<ApiResponse<List<RoleResponse>>> getAllRoles() {
        List<RoleResponse> roles = roleApplicationService.getAllRoles();
        return ResponseEntity.ok(ApiResponse.success("Roles retrieved successfully", roles));
    }

    @PostMapping
    @Operation(summary = "Create a new role")
    public ResponseEntity<ApiResponse<RoleResponse>> createRole(@RequestBody @Valid RoleRequest request) {
        RoleResponse created = roleApplicationService.createRole(request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Role created successfully", created));
    }

    @PutMapping("/{roleName}")
    @Operation(summary = "Update a role's name")
    public ResponseEntity<ApiResponse<RoleResponse>> updateRole(
            @PathVariable String roleName,
            @RequestBody @Valid RoleRequest request) {
        RoleResponse updated = roleApplicationService.updateRole(roleName, request);
        return ResponseEntity.ok(ApiResponse.success("Role updated successfully", updated));
    }

    @DeleteMapping("/{roleName}")
    @Operation(summary = "Delete a role by name")
    public ResponseEntity<ApiResponse<Void>> deleteRole(@PathVariable String roleName) {
        roleApplicationService.deleteRole(roleName);
        return ResponseEntity.ok(ApiResponse.success("Role deleted successfully"));
    }
}
