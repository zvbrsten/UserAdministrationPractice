package com.company.rbac.role.domain.repository;

import com.company.rbac.role.domain.entity.Role;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * Repository interface for {@link Role} persistence operations.
 */
@Repository
public interface RoleRepository extends JpaRepository<Role, Long> {

    /**
     * Finds a role by its exact name (case-sensitive).
     *
     * @param roleName the role name to search
     * @return an Optional containing the role if found
     */
    Optional<Role> findByRoleName(String roleName);

    /**
     * Checks whether a role name already exists.
     */
    boolean existsByRoleName(String roleName);
}
