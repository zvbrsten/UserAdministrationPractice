package com.company.rbac.module.domain.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

/**
 * Domain entity representing a functional module of the system
 * (e.g. USER_MANAGEMENT, LEADS, CUSTOMERS, REPORTS, SETTINGS, BILLING).
 * Modules group features that can be permission-controlled per role.
 */
@Entity
@Table(name = "modules")
@Getter
@Setter
@NoArgsConstructor
public class Module {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "modulename", unique = true, nullable = false, length = 100)
    private String moduleName;

    @CreationTimestamp
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;

    public Module(String moduleName) {
        this.moduleName = moduleName;
    }

    public Module(long id, String moduleName) {
        this.id = id;
        this.moduleName = moduleName;
    }
}
