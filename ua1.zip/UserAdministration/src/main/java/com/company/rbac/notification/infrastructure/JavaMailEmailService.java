package com.company.rbac.notification.infrastructure;

import com.company.rbac.notification.application.service.EmailService;
import com.company.rbac.notification.application.service.dto.EmailRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

/**
 * Infrastructure implementation of {@link EmailService} using Spring's JavaMailSender.
 *
 * <p>Connects to the SMTP server configured via {@code application.yml} / environment
 * properties. The sender email is externalized via {@code spring.mail.username}.</p>
 */
@Service
public class JavaMailEmailService implements EmailService {

    private static final Logger logger = LoggerFactory.getLogger(JavaMailEmailService.class);

    private final JavaMailSender javaMailSender;

    @Value("${spring.mail.username}")
    private String senderEmail;

    public JavaMailEmailService(JavaMailSender javaMailSender) {
        this.javaMailSender = javaMailSender;
    }

    /**
     * {@inheritDoc}
     *
     * <p>Sends a plain-text email via the configured SMTP server.</p>
     */
    @Override
    public String sendSimpleEmail(EmailRequest emailRequest) {
        logger.info("Sending email to [{}] with subject [{}]", emailRequest.getRecipient(), emailRequest.getSubject());
        try {
            SimpleMailMessage mailMessage = new SimpleMailMessage();
            mailMessage.setFrom(senderEmail);
            mailMessage.setTo(emailRequest.getRecipient());
            mailMessage.setSubject(emailRequest.getSubject());
            mailMessage.setText(emailRequest.getMsgBody());
            javaMailSender.send(mailMessage);
            logger.info("Email sent successfully to [{}]", emailRequest.getRecipient());
            return "Email sent successfully";
        } catch (Exception ex) {
            logger.error("Failed to send email to [{}]: {}", emailRequest.getRecipient(), ex.getMessage(), ex);
            throw new RuntimeException("Failed to send email: " + ex.getMessage(), ex);
        }
    }
}
