package com.company.rbac.auth.application.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Response DTO returned by the login endpoint on successful authentication.
 *
 * <p>Clients should store the {@code accessToken} and send it as:
 * {@code Authorization: Bearer <accessToken>} on all subsequent requests.</p>
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AuthResponse {

    /** The JWT access token. Send in the Authorization header for all protected requests. */
    private String accessToken;

    /** Always "Bearer" — indicates the token type per RFC 6750. */
    private String tokenType;

    /** Token lifetime in milliseconds (for client-side expiry tracking). */
    private long expiresInMs;

    /** The authenticated user's username. */
    private String username;

    /** The authenticated user's role (e.g. "SUPERADMIN", "ADMIN"). */
    private String role;
}
