package com.company.rbac.permission.domain.exception;

import com.company.rbac.shared.exception.ResourceNotFoundException;

/**
 * Thrown when a {@link com.company.rbac.permission.domain.entity.Permission} cannot be found.
 */
public class PermissionNotFoundException extends ResourceNotFoundException {

    public PermissionNotFoundException(Long permissionId) {
        super("Permission", permissionId);
    }

    public PermissionNotFoundException(String permissionName) {
        super("Permission", permissionName);
    }
}
