package com.company.rbac;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Main entry point for the RBAC User Administration System.
 *
 * <p>This application implements a Role-Based Access Control (RBAC) system
 * with support for Users, Roles, Permissions, and Modules.</p>
 */
@SpringBootApplication
public class RbacApplication {

    public static void main(String[] args) {
        SpringApplication.run(RbacApplication.class, args);
    }
}
