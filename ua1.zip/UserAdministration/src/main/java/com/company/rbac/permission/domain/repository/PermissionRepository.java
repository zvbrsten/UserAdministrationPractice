package com.company.rbac.permission.domain.repository;

import com.company.rbac.permission.domain.entity.Permission;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * Repository interface for {@link Permission} persistence operations.
 */
@Repository
public interface PermissionRepository extends JpaRepository<Permission, Long> {

    /**
     * Finds a permission by its exact name (e.g. "CREATE", "READ").
     */
    Optional<Permission> findByPermissionName(String permissionName);

    /**
     * Checks whether a permission name already exists.
     */
    boolean existsByPermissionName(String permissionName);
}
