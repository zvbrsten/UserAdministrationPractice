package com.company.rbac.notification.presentation;

import com.company.rbac.notification.application.service.EmailService;
import com.company.rbac.notification.application.service.dto.EmailRequest;
import com.company.rbac.shared.response.ApiResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * REST controller for notification/email endpoints.
 */
@RestController
@RequestMapping("/api/v1/notifications")
@Tag(name = "Notifications", description = "Email notification operations")
public class NotificationController {

    private final EmailService emailService;

    public NotificationController(EmailService emailService) {
        this.emailService = emailService;
    }

    @PostMapping("/email")
    @Operation(summary = "Send a plain-text email notification")
    public ResponseEntity<ApiResponse<String>> sendEmail(@RequestBody @Valid EmailRequest request) {
        String result = emailService.sendSimpleEmail(request);
        return ResponseEntity.ok(ApiResponse.success(result));
    }
}
