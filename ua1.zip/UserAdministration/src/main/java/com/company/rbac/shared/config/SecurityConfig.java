package com.company.rbac.shared.config;

import com.company.rbac.auth.infrastructure.JdbcUserDetailsService;
import com.company.rbac.auth.infrastructure.JwtAuthenticationFilter;
import com.company.rbac.shared.exception.JwtAuthenticationEntryPoint;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

/**
 * Spring Security configuration for JWT-based stateless authentication.
 *
 * <h3>Auth Flow:</h3>
 * <ol>
 *   <li>Client sends {@code POST /api/v1/auth/login} with username + password</li>
 *   <li>Server validates credentials via {@link JdbcUserDetailsService} + BCrypt</li>
 *   <li>Server returns a signed JWT token in the response body</li>
 *   <li>Client includes the token as {@code Authorization: Bearer <token>} on all requests</li>
 *   <li>{@link JwtAuthenticationFilter} validates the token on every request</li>
 * </ol>
 *
 * <h3>Session Policy:</h3>
 * <p>STATELESS — no server-side sessions are created. All state is in the JWT.</p>
 *
 * <h3>RBAC Access Rules (per HTTP method):</h3>
 * <ul>
 *   <li>GET  — SUPERADMIN, ADMIN, MANAGER</li>
 *   <li>POST — SUPERADMIN, ADMIN, MANAGER, EMPLOYEE</li>
 *   <li>PUT, PATCH — SUPERADMIN, ADMIN, MANAGER</li>
 *   <li>DELETE — SUPERADMIN, ADMIN</li>
 * </ul>
 */
@Configuration
public class SecurityConfig {

    private final JdbcUserDetailsService userDetailsService;
    private final JwtAuthenticationFilter jwtAuthenticationFilter;
    private final JwtAuthenticationEntryPoint jwtAuthenticationEntryPoint;

    public SecurityConfig(JdbcUserDetailsService userDetailsService,
                          JwtAuthenticationFilter jwtAuthenticationFilter,
                          JwtAuthenticationEntryPoint jwtAuthenticationEntryPoint) {
        this.userDetailsService = userDetailsService;
        this.jwtAuthenticationFilter = jwtAuthenticationFilter;
        this.jwtAuthenticationEntryPoint = jwtAuthenticationEntryPoint;
    }

    /**
     * BCrypt password encoder — industry-standard adaptive hashing.
     */
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    /**
     * DAO authentication provider — wires our {@link JdbcUserDetailsService}
     * and BCrypt encoder into Spring Security's authentication pipeline.
     */
    @Bean
    public DaoAuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
        provider.setUserDetailsService(userDetailsService);
        provider.setPasswordEncoder(passwordEncoder());
        return provider;
    }

    /**
     * Exposes the {@link AuthenticationManager} bean so that
     * {@link com.company.rbac.auth.application.service.AuthApplicationService}
     * can trigger authentication programmatically during login.
     */
    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }

    /**
     * Defines the HTTP security filter chain.
     *
     * <p>Key decisions:</p>
     * <ul>
     *   <li>CSRF disabled (safe for stateless REST APIs)</li>
     *   <li>Sessions set to STATELESS (no HttpSession created or used)</li>
     *   <li>JWT filter inserted before UsernamePasswordAuthenticationFilter</li>
     *   <li>401 responses handled by {@link JwtAuthenticationEntryPoint}</li>
     * </ul>
     */
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            // Disable CSRF — not needed for stateless JWT APIs
            .csrf(AbstractHttpConfigurer::disable)

            // No server-side sessions — all state in JWT
            .sessionManagement(session ->
                session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))

            // Return 401 JSON (not login redirect) when auth fails
            .exceptionHandling(ex ->
                ex.authenticationEntryPoint(jwtAuthenticationEntryPoint))

            // Authorization rules
            .authorizeHttpRequests(auth -> auth
                // Public endpoints — no token required
                .requestMatchers("/api/v1/auth/**").permitAll()
                .requestMatchers("/v3/api-docs/**", "/swagger-ui/**", "/swagger-ui.html", "/webjars/**").permitAll()
                .requestMatchers("/actuator/health", "/actuator/info").permitAll()

                // Role-based access per HTTP method
                .requestMatchers(HttpMethod.GET,    "/**").hasAnyRole("SUPERADMIN", "ADMIN", "MANAGER")
                .requestMatchers(HttpMethod.POST,   "/**").hasAnyRole("SUPERADMIN", "ADMIN", "MANAGER", "EMPLOYEE")
                .requestMatchers(HttpMethod.PUT,    "/**").hasAnyRole("SUPERADMIN", "ADMIN", "MANAGER")
                .requestMatchers(HttpMethod.PATCH,  "/**").hasAnyRole("SUPERADMIN", "ADMIN", "MANAGER")
                .requestMatchers(HttpMethod.DELETE, "/**").hasAnyRole("SUPERADMIN", "ADMIN")
                .anyRequest().authenticated()
            )

            // Wire our DAO auth provider
            .authenticationProvider(authenticationProvider())

            // Insert JWT filter before the default username/password filter
            .addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }
}
