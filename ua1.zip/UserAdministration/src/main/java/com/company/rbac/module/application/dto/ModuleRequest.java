package com.company.rbac.module.application.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

/**
 * Request DTO for creating a new module.
 */
@Data
public class ModuleRequest {

    @NotBlank(message = "Module name cannot be empty")
    @Size(max = 100, message = "Module name must be at most 100 characters")
    private String moduleName;
}
