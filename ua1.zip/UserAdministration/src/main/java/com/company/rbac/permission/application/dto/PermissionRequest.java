package com.company.rbac.permission.application.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

/**
 * Request DTO for creating a new permission.
 */
@Data
public class PermissionRequest {

    @NotBlank(message = "Permission name cannot be empty")
    @Size(max = 50, message = "Permission name must be at most 50 characters")
    private String permissionName;
}
