package com.company.rbac.rbac.domain.entity;

import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

/**
 * Composite primary key for the {@link RoleModulePermission} join table.
 * The key is composed of the role ID (rid), module ID (mid), and permission ID (pid).
 */
@Embeddable
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
public class RoleModulePermissionId implements Serializable {

    private Long rid;
    private Long mid;
    private Long pid;
}
