package com.company.rbac.user.domain.repository;

import com.company.rbac.user.domain.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * Repository interface for {@link User} persistence operations.
 * Spring Data JPA provides the implementation at runtime.
 */
@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    /**
     * Finds an active, non-deleted user by their unique username.
     *
     * @param userName the username to search
     * @return an Optional containing the user if found
     */
    Optional<User> findByUserNameAndIsDeletedFalse(String userName);

    /**
     * Finds an active, non-deleted user by their email address.
     *
     * @param email the email address to search
     * @return an Optional containing the user if found
     */
    Optional<User> findByEmailAndIsDeletedFalse(String email);

    /**
     * Checks whether a username is already taken.
     */
    boolean existsByUserName(String userName);

    /**
     * Checks whether an email address is already registered.
     */
    boolean existsByEmail(String email);
}
