package com.company.rbac.user.application.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

/**
 * Request DTO for updating only the username of an existing user.
 */
@Data
public class UserUpdateRequest {

    @NotBlank(message = "Username cannot be empty")
    @Size(min = 2, max = 30, message = "Username must be between 2 and 30 characters")
    private String userName;
}
