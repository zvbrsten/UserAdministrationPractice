package com.company.rbac.role.application.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

/**
 * Request DTO for creating or updating a role.
 */
@Data
public class RoleRequest {

    @NotBlank(message = "Role name cannot be empty")
    @Size(max = 50, message = "Role name must be at most 50 characters")
    private String roleName;
}
