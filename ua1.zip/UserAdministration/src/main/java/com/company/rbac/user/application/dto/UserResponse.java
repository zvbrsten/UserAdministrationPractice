package com.company.rbac.user.application.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Response DTO representing a user returned from the API.
 * Password and internal fields are never exposed.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserResponse {

    private Long id;
    private String userName;
    private String firstName;
    private String lastName;
    private String email;
    private String phone;
    private String dob;
    private String profilePictureUrl;
    private Boolean isActive;
    private String roleName;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
