package com.company.rbac.auth.application.service;

import com.company.rbac.auth.application.dto.AuthResponse;
import com.company.rbac.auth.application.dto.LoginRequest;
import com.company.rbac.auth.domain.service.JwtTokenProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.LockedException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Service;

import java.util.stream.Collectors;

/**
 * Application service that orchestrates the authentication (login) use case.
 *
 * <p>Flow:</p>
 * <ol>
 *   <li>Receive {@link LoginRequest} with username + password</li>
 *   <li>Delegate to Spring Security's {@link AuthenticationManager} which calls
 *       {@code JdbcUserDetailsService.loadUserByUsername()} and verifies the BCrypt hash</li>
 *   <li>On success, issue a signed JWT via {@link JwtTokenProvider}</li>
 *   <li>Return an {@link AuthResponse} containing the token and metadata</li>
 * </ol>
 */
@Service
public class AuthApplicationService {

    private static final Logger logger = LoggerFactory.getLogger(AuthApplicationService.class);

    private final AuthenticationManager authenticationManager;
    private final JwtTokenProvider jwtTokenProvider;

    public AuthApplicationService(AuthenticationManager authenticationManager,
                                  JwtTokenProvider jwtTokenProvider) {
        this.authenticationManager = authenticationManager;
        this.jwtTokenProvider = jwtTokenProvider;
    }

    /**
     * Authenticates a user and issues a JWT token.
     *
     * @param request the login credentials
     * @return an {@link AuthResponse} with the access token and user metadata
     * @throws BadCredentialsException if the password is wrong
     * @throws LockedException         if the account is locked (isActive = false)
     * @throws DisabledException       if the account is deleted (isDeleted = true)
     */
    public AuthResponse login(LoginRequest request) {
        logger.info("Login attempt for user [{}]", request.getUsername());

        try {
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword())
            );

            String token = jwtTokenProvider.generateToken(authentication);

            // Extract role for the response body (strip ROLE_ prefix for readability)
            String roleAuthority = authentication.getAuthorities().stream()
                    .map(GrantedAuthority::getAuthority)
                    .collect(Collectors.joining(","));

            String roleName = roleAuthority.replace("ROLE_", "");

            logger.info("User [{}] authenticated successfully with role [{}]",
                    request.getUsername(), roleName);

            return AuthResponse.builder()
                    .accessToken(token)
                    .tokenType("Bearer")
                    .expiresInMs(jwtTokenProvider.getExpirationMs())
                    .username(authentication.getName())
                    .role(roleName)
                    .build();

        } catch (AuthenticationException ex) {
            logger.warn("Authentication failed for user [{}]: {}", request.getUsername(), ex.getMessage());
            throw ex;
        }
    }
}
