package com.company.rbac.module.presentation.controller;

import com.company.rbac.module.application.dto.ModuleRequest;
import com.company.rbac.module.application.dto.ModuleResponse;
import com.company.rbac.module.application.service.ModuleApplicationService;
import com.company.rbac.shared.response.ApiResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST controller for Module management endpoints.
 * All routes are versioned under {@code /api/v1/modules}.
 */
@RestController
@RequestMapping("/api/v1/modules")
@Tag(name = "Modules", description = "Module management operations")
public class ModuleController {

    private final ModuleApplicationService moduleApplicationService;

    public ModuleController(ModuleApplicationService moduleApplicationService) {
        this.moduleApplicationService = moduleApplicationService;
    }

    @GetMapping
    @Operation(summary = "List all modules")
    public ResponseEntity<ApiResponse<List<ModuleResponse>>> getAllModules() {
        List<ModuleResponse> modules = moduleApplicationService.getAllModules();
        return ResponseEntity.ok(ApiResponse.success("Modules retrieved successfully", modules));
    }

    @PostMapping
    @Operation(summary = "Create a new module")
    public ResponseEntity<ApiResponse<ModuleResponse>> createModule(@RequestBody @Valid ModuleRequest request) {
        ModuleResponse created = moduleApplicationService.createModule(request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Module created successfully", created));
    }
}
