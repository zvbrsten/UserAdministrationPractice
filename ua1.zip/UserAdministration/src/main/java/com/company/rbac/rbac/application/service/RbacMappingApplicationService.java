package com.company.rbac.rbac.application.service;

import com.company.rbac.module.domain.entity.Module;
import com.company.rbac.module.domain.exception.ModuleNotFoundException;
import com.company.rbac.module.domain.repository.ModuleRepository;
import com.company.rbac.permission.domain.entity.Permission;
import com.company.rbac.permission.domain.exception.PermissionNotFoundException;
import com.company.rbac.permission.domain.repository.PermissionRepository;
import com.company.rbac.rbac.application.dto.RoleModulePermissionRequest;
import com.company.rbac.rbac.application.dto.RoleModulePermissionResponse;
import com.company.rbac.rbac.domain.entity.RoleModulePermission;
import com.company.rbac.rbac.domain.repository.RoleModulePermissionRepository;
import com.company.rbac.role.domain.entity.Role;
import com.company.rbac.role.domain.exception.RoleNotFoundException;
import com.company.rbac.role.domain.repository.RoleRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Application service orchestrating all Role–Module–Permission (RBAC mapping) use cases.
 *
 * <p>This service coordinates across the role, module, and permission domains to
 * create and query the three-way RBAC mapping table.</p>
 */
@Service
@Transactional(readOnly = true)
public class RbacMappingApplicationService {

    private static final Logger logger = LoggerFactory.getLogger(RbacMappingApplicationService.class);

    private final RoleModulePermissionRepository rbacMappingRepository;
    private final RoleRepository roleRepository;
    private final ModuleRepository moduleRepository;
    private final PermissionRepository permissionRepository;

    public RbacMappingApplicationService(RoleModulePermissionRepository rbacMappingRepository,
                                         RoleRepository roleRepository,
                                         ModuleRepository moduleRepository,
                                         PermissionRepository permissionRepository) {
        this.rbacMappingRepository = rbacMappingRepository;
        this.roleRepository = roleRepository;
        this.moduleRepository = moduleRepository;
        this.permissionRepository = permissionRepository;
    }

    /**
     * Retrieves all Role–Module–Permission mappings.
     *
     * @return list of RBAC mapping response DTOs
     */
    public List<RoleModulePermissionResponse> getAllMappings() {
        logger.info("Fetching all role-module-permission mappings");
        return rbacMappingRepository.findAll().stream()
                .map(this::toResponse)
                .toList();
    }

    /**
     * Creates a new Role–Module–Permission mapping using entity names.
     *
     * @param request the mapping creation request (role/module/permission names)
     * @return the created mapping as a response DTO
     * @throws RoleNotFoundException       if the role name does not exist
     * @throws ModuleNotFoundException     if the module name does not exist
     * @throws PermissionNotFoundException if the permission name does not exist
     */
    @Transactional
    public RoleModulePermissionResponse createMapping(RoleModulePermissionRequest request) {
        logger.info("Creating RBAC mapping: role=[{}], module=[{}], permission=[{}]",
                request.getRoleName(), request.getModuleName(), request.getPermissionName());

        Role role = roleRepository.findByRoleName(request.getRoleName())
                .orElseThrow(() -> new RoleNotFoundException(request.getRoleName()));

        Module module = moduleRepository.findByModuleName(request.getModuleName())
                .orElseThrow(() -> new ModuleNotFoundException(request.getModuleName()));

        Permission permission = permissionRepository.findByPermissionName(request.getPermissionName())
                .orElseThrow(() -> new PermissionNotFoundException(request.getPermissionName()));

        RoleModulePermission mapping = new RoleModulePermission(role, module, permission);
        rbacMappingRepository.save(mapping);

        logger.info("RBAC mapping created: role=[{}], module=[{}], permission=[{}]",
                role.getRoleName(), module.getModuleName(), permission.getPermissionName());

        return toResponse(mapping);
    }

    // -------------------------------------------------------------------------
    // Private mapping helper
    // -------------------------------------------------------------------------

    private RoleModulePermissionResponse toResponse(RoleModulePermission mapping) {
        return RoleModulePermissionResponse.builder()
                .roleName(mapping.getRole().getRoleName())
                .moduleName(mapping.getModule().getModuleName())
                .permissionName(mapping.getPermission().getPermissionName())
                .build();
    }
}
