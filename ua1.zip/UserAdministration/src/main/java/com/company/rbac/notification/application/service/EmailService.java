package com.company.rbac.notification.application.service;

import com.company.rbac.notification.application.service.dto.EmailRequest;

/**
 * Port (interface) for email notification services.
 *
 * <p>Concrete implementations are provided in the infrastructure layer.
 * This decouples the application layer from specific mail providers.</p>
 */
public interface EmailService {

    /**
     * Sends a simple plain-text email.
     *
     * @param emailRequest the email details (recipient, subject, body)
     * @return a status message indicating success or failure
     */
    String sendSimpleEmail(EmailRequest emailRequest);
}
