package com.company.rbac.user.application.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;

/**
 * Request DTO for creating a new user.
 * All fields are validated before reaching the service layer.
 */
@Data
public class UserCreateRequest {

    @NotBlank(message = "Username cannot be empty")
    @Size(min = 2, max = 30, message = "Username must be between 2 and 30 characters")
    private String userName;

    @NotBlank(message = "First name cannot be empty")
    @Size(max = 100, message = "First name must be at most 100 characters")
    private String firstName;

    @NotBlank(message = "Last name cannot be empty")
    @Size(max = 100, message = "Last name must be at most 100 characters")
    private String lastName;

    @NotBlank(message = "Email cannot be empty")
    @Email(message = "Invalid email address format")
    private String email;

    @NotBlank(message = "Phone number cannot be empty")
    @Size(min = 10, max = 15, message = "Phone number must be between 10 and 15 characters")
    private String phone;

    @NotBlank(message = "Password cannot be empty")
    @Size(min = 8, message = "Password must be at least 8 characters")
    private String password;

    @NotBlank(message = "Date of birth cannot be empty")
    @Pattern(
        regexp = "^(19|20)\\d\\d[\\-\\/.](?:(?:(0[13578]|1[02])[\\-\\/.](0[1-9]|[12]\\d|3[01]))|(?:(0[469]|11)[\\-\\/.](0[1-9]|[12]\\d|30))|(?:02[\\-\\/.](0[1-9]|[12]\\d)))$",
        message = "Date of birth must be a valid date in YYYY-MM-DD format"
    )
    private String dob;

    @NotNull(message = "Role ID cannot be null")
    private Long roleId;
}
