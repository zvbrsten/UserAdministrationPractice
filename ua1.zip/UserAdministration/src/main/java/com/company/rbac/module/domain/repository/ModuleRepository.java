package com.company.rbac.module.domain.repository;

import com.company.rbac.module.domain.entity.Module;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * Repository interface for {@link Module} persistence operations.
 */
@Repository
public interface ModuleRepository extends JpaRepository<Module, Long> {

    /**
     * Finds a module by its exact name (e.g. "USER_MANAGEMENT", "BILLING").
     */
    Optional<Module> findByModuleName(String moduleName);

    /**
     * Checks whether a module name already exists.
     */
    boolean existsByModuleName(String moduleName);
}
