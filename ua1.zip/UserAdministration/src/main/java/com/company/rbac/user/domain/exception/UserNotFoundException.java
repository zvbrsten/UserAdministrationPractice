package com.company.rbac.user.domain.exception;

import com.company.rbac.shared.exception.ResourceNotFoundException;

/**
 * Thrown when a {@link com.company.rbac.user.domain.entity.User} cannot be found.
 */
public class UserNotFoundException extends ResourceNotFoundException {

    public UserNotFoundException(Long userId) {
        super("User", userId);
    }

    public UserNotFoundException(String identifier) {
        super("User", identifier);
    }
}
