package com.company.rbac.permission.application.service;

import com.company.rbac.permission.application.dto.PermissionRequest;
import com.company.rbac.permission.application.dto.PermissionResponse;
import com.company.rbac.permission.domain.entity.Permission;
import com.company.rbac.permission.domain.repository.PermissionRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Application service orchestrating all permission-related use cases.
 */
@Service
@Transactional(readOnly = true)
public class PermissionApplicationService {

    private static final Logger logger = LoggerFactory.getLogger(PermissionApplicationService.class);

    private final PermissionRepository permissionRepository;

    public PermissionApplicationService(PermissionRepository permissionRepository) {
        this.permissionRepository = permissionRepository;
    }

    /**
     * Retrieves all permissions in the system.
     */
    public List<PermissionResponse> getAllPermissions() {
        logger.info("Fetching all permissions");
        return permissionRepository.findAll().stream()
                .map(this::toResponse)
                .toList();
    }

    /**
     * Creates a new permission.
     *
     * @param request the permission creation request
     * @throws IllegalArgumentException if a permission with the same name already exists
     */
    @Transactional
    public PermissionResponse createPermission(PermissionRequest request) {
        logger.info("Creating permission [{}]", request.getPermissionName());
        if (permissionRepository.existsByPermissionName(request.getPermissionName())) {
            throw new IllegalArgumentException("Permission [" + request.getPermissionName() + "] already exists.");
        }
        Permission permission = new Permission(request.getPermissionName());
        Permission saved = permissionRepository.save(permission);
        logger.info("Permission [{}] created with id [{}]", saved.getPermissionName(), saved.getId());
        return toResponse(saved);
    }

    // -------------------------------------------------------------------------
    // Private mapping helper
    // -------------------------------------------------------------------------

    private PermissionResponse toResponse(Permission permission) {
        return PermissionResponse.builder()
                .id(permission.getId())
                .permissionName(permission.getPermissionName())
                .createdAt(permission.getCreatedAt())
                .build();
    }
}
