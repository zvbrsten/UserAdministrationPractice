package com.company.rbac.permission.domain.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

/**
 * Domain entity representing a granular permission (e.g. CREATE, READ, UPDATE, DELETE).
 * Permissions are linked to modules via the RoleModulePermission RBAC mapping.
 */
@Entity
@Table(name = "permissions")
@Getter
@Setter
@NoArgsConstructor
public class Permission {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "permissionname", unique = true, nullable = false, length = 50)
    private String permissionName;

    @CreationTimestamp
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;

    public Permission(String permissionName) {
        this.permissionName = permissionName;
    }

    public Permission(long id, String permissionName) {
        this.id = id;
        this.permissionName = permissionName;
    }
}
