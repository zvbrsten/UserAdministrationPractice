package com.company.rbac.user.presentation.controller;

import com.company.rbac.shared.response.ApiResponse;
import com.company.rbac.user.application.dto.ResetPasswordRequest;
import com.company.rbac.user.application.dto.UserCreateRequest;
import com.company.rbac.user.application.dto.UserResponse;
import com.company.rbac.user.application.dto.UserUpdateRequest;
import com.company.rbac.user.application.service.UserApplicationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST controller for User management endpoints.
 * All routes are versioned under {@code /api/v1/users}.
 *
 * <p>This controller is intentionally thin — it only delegates to
 * {@link UserApplicationService}. No business logic lives here.</p>
 */
@RestController
@RequestMapping("/api/v1/users")
@Tag(name = "Users", description = "User management operations")
public class UserController {

    private final UserApplicationService userApplicationService;

    public UserController(UserApplicationService userApplicationService) {
        this.userApplicationService = userApplicationService;
    }

    // -------------------------------------------------------------------------
    // GET Endpoints
    // -------------------------------------------------------------------------

    @GetMapping
    @Operation(summary = "List all users")
    public ResponseEntity<ApiResponse<List<UserResponse>>> getAllUsers() {
        List<UserResponse> users = userApplicationService.getAllUsers();
        return ResponseEntity.ok(ApiResponse.success("Users retrieved successfully", users));
    }

    @GetMapping("/by-username/{userName}")
    @Operation(summary = "Get a user by username")
    public ResponseEntity<ApiResponse<UserResponse>> getUserByUserName(@PathVariable String userName) {
        UserResponse user = userApplicationService.getUserByUserName(userName);
        return ResponseEntity.ok(ApiResponse.success("User retrieved successfully", user));
    }

    @GetMapping("/by-firstname/{firstName}")
    @Operation(summary = "Get users by first name")
    public ResponseEntity<ApiResponse<List<UserResponse>>> getUsersByFirstName(@PathVariable String firstName) {
        List<UserResponse> users = userApplicationService.getUsersByFirstName(firstName);
        return ResponseEntity.ok(ApiResponse.success("Users retrieved successfully", users));
    }

    @GetMapping("/by-role/{roleName}")
    @Operation(summary = "Get all users belonging to a specific role")
    public ResponseEntity<ApiResponse<List<UserResponse>>> getUsersByRole(@PathVariable String roleName) {
        List<UserResponse> users = userApplicationService.getUsersByRoleName(roleName);
        return ResponseEntity.ok(ApiResponse.success("Users retrieved successfully", users));
    }

    @GetMapping("/{userName}/role")
    @Operation(summary = "Get the role assigned to a specific user")
    public ResponseEntity<ApiResponse<String>> getRoleForUser(@PathVariable String userName) {
        String roleName = userApplicationService.getRoleForUser(userName);
        return ResponseEntity.ok(ApiResponse.success("Role retrieved successfully", roleName));
    }

    // -------------------------------------------------------------------------
    // POST Endpoints
    // -------------------------------------------------------------------------

    @PostMapping
    @Operation(summary = "Create a new user")
    public ResponseEntity<ApiResponse<Void>> createUser(@RequestBody @Valid UserCreateRequest request) {
        userApplicationService.createUser(request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("User created successfully"));
    }

    // -------------------------------------------------------------------------
    // PUT Endpoints
    // -------------------------------------------------------------------------

    @PutMapping("/{userName}")
    @Operation(summary = "Update a user's username")
    public ResponseEntity<ApiResponse<UserResponse>> updateUserName(
            @PathVariable String userName,
            @RequestBody @Valid UserUpdateRequest request) {
        UserResponse updated = userApplicationService.updateUserName(userName, request);
        return ResponseEntity.ok(ApiResponse.success("User updated successfully", updated));
    }

    // -------------------------------------------------------------------------
    // PATCH Endpoints
    // -------------------------------------------------------------------------

    @PatchMapping("/{userName}/password")
    @Operation(summary = "Reset a user's password")
    public ResponseEntity<ApiResponse<Void>> resetPassword(
            @PathVariable String userName,
            @RequestBody @Valid ResetPasswordRequest request) {
        userApplicationService.resetPassword(userName, request);
        return ResponseEntity.ok(ApiResponse.success("Password reset successfully"));
    }

    // -------------------------------------------------------------------------
    // DELETE Endpoints
    // -------------------------------------------------------------------------

    @DeleteMapping("/{userName}")
    @Operation(summary = "Delete a user by username")
    public ResponseEntity<ApiResponse<Void>> deleteUser(@PathVariable String userName) {
        userApplicationService.deleteUser(userName);
        return ResponseEntity.ok(ApiResponse.success("User deleted successfully"));
    }
}
