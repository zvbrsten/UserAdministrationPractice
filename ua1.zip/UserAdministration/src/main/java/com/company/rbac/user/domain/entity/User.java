package com.company.rbac.user.domain.entity;

import com.company.rbac.role.domain.entity.Role;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

/**
 * Domain entity representing a system user.
 * A user is associated with exactly one {@link Role} which determines their access level.
 */
@Entity
@Table(name = "users")
@Getter
@Setter
@NoArgsConstructor
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "username", unique = true, nullable = false, length = 30)
    @NotBlank(message = "Username cannot be empty")
    @Size(max = 30, message = "Username must be at most 30 characters")
    private String userName;

    @Column(name = "firstname", nullable = false, length = 100)
    private String firstName;

    @Column(name = "lastname", nullable = false, length = 100)
    private String lastName;

    @Column(name = "email", unique = true, nullable = false, length = 150)
    private String email;

    @Column(name = "phone", unique = true, nullable = false, length = 15)
    private String phone;

    /** BCrypt-hashed password. Never store plain text. */
    @Column(name = "pwd_hash", nullable = false)
    private String password;

    @Column(name = "dob", nullable = false, length = 20)
    private String dob;

    @Column(name = "profile_picture_url")
    private String profilePictureUrl;

    @Column(name = "is_active", nullable = false)
    private Boolean isActive = true;

    @Column(name = "is_deleted", nullable = false)
    private Boolean isDeleted = false;

    @CreationTimestamp
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "role_id", nullable = false)
    private Role role;

    /**
     * Full constructor used for seeding initial data.
     *
     * @param userName  unique login username
     * @param firstName user's first name
     * @param lastName  user's last name
     * @param email     user's email address
     * @param phone     user's phone number
     * @param dob       date of birth (format: YYYY-MM-DD)
     * @param password  BCrypt-hashed password
     * @param roleId    the ID of the role to assign
     */
    public User(String userName, String firstName, String lastName, String email,
                String phone, String dob, String password, Long roleId) {
        this.userName = userName;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.phone = phone;
        this.dob = dob;
        this.password = password;
        this.role = new Role();
        this.role.setId(roleId);
        this.isActive = true;
        this.isDeleted = false;
    }

    /**
     * Convenience method to get the role ID directly from the associated role.
     */
    public Long getRoleId() {
        return (role != null) ? role.getId() : null;
    }
}
