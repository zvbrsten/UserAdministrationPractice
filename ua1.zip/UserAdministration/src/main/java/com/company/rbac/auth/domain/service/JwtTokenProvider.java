package com.company.rbac.auth.domain.service;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.stream.Collectors;

/**
 * Core JWT service responsible for generating, parsing, and validating JWT tokens.
 *
 * <p>Uses HMAC-SHA256 (HS256) symmetric signing. The secret key is externalized
 * via {@code app.jwt.secret} and must be at least 256 bits (32 characters) long.</p>
 *
 * <p>Token claims structure:</p>
 * <ul>
 *   <li>{@code sub} — username (subject)</li>
 *   <li>{@code roles} — comma-separated Spring Security authorities (e.g. "ROLE_ADMIN")</li>
 *   <li>{@code iat} — issued-at timestamp</li>
 *   <li>{@code exp} — expiration timestamp</li>
 * </ul>
 */
@Component
public class JwtTokenProvider {

    private static final Logger logger = LoggerFactory.getLogger(JwtTokenProvider.class);

    private static final String CLAIM_ROLES = "roles";

    @Value("${app.jwt.secret}")
    private String jwtSecret;

    @Value("${app.jwt.expiration-ms}")
    private long jwtExpirationMs;

    // -------------------------------------------------------------------------
    // Token generation
    // -------------------------------------------------------------------------

    /**
     * Generates a signed JWT token for the given authenticated principal.
     *
     * @param authentication the Spring Security authentication object (post-login)
     * @return a compact, signed JWT string
     */
    public String generateToken(Authentication authentication) {
        String username = authentication.getName();
        String roles = authentication.getAuthorities().stream()
                .map(GrantedAuthority::getAuthority)
                .collect(Collectors.joining(","));

        Date issuedAt = new Date();
        Date expiration = new Date(issuedAt.getTime() + jwtExpirationMs);

        return Jwts.builder()
                .subject(username)
                .claim(CLAIM_ROLES, roles)
                .issuedAt(issuedAt)
                .expiration(expiration)
                .signWith(getSigningKey())
                .compact();
    }

    /**
     * Generates a JWT for a known username and role string (used internally after refresh).
     *
     * @param username the username to embed as subject
     * @param roles    comma-separated role authorities
     * @return a compact, signed JWT string
     */
    public String generateToken(String username, String roles) {
        Date issuedAt = new Date();
        Date expiration = new Date(issuedAt.getTime() + jwtExpirationMs);

        return Jwts.builder()
                .subject(username)
                .claim(CLAIM_ROLES, roles)
                .issuedAt(issuedAt)
                .expiration(expiration)
                .signWith(getSigningKey())
                .compact();
    }

    // -------------------------------------------------------------------------
    // Token validation & extraction
    // -------------------------------------------------------------------------

    /**
     * Validates the signature, structure, and expiration of the given JWT token.
     *
     * @param token the JWT string to validate
     * @return {@code true} if the token is valid, {@code false} otherwise
     */
    public boolean validateToken(String token) {
        try {
            parseClaims(token);
            return true;
        } catch (JwtException ex) {
            logger.warn("JWT validation failed: {}", ex.getMessage());
        } catch (IllegalArgumentException ex) {
            logger.warn("JWT token is empty or malformed: {}", ex.getMessage());
        }
        return false;
    }

    /**
     * Extracts the username (subject) from a validated JWT token.
     *
     * @param token the JWT string
     * @return the username stored in the token subject
     */
    public String getUsernameFromToken(String token) {
        return parseClaims(token).getSubject();
    }

    /**
     * Extracts the comma-separated roles claim from a validated JWT token.
     *
     * @param token the JWT string
     * @return roles string, e.g. "ROLE_ADMIN,ROLE_MANAGER"
     */
    public String getRolesFromToken(String token) {
        return parseClaims(token).get(CLAIM_ROLES, String.class);
    }

    /**
     * Returns the configured token expiration duration in milliseconds.
     */
    public long getExpirationMs() {
        return jwtExpirationMs;
    }

    // -------------------------------------------------------------------------
    // Private helpers
    // -------------------------------------------------------------------------

    private Claims parseClaims(String token) {
        return Jwts.parser()
                .verifyWith(getSigningKey())
                .build()
                .parseSignedClaims(token)
                .getPayload();
    }

    private SecretKey getSigningKey() {
        // Keys.hmacShaKeyFor requires at least 256 bits (32 bytes) for HS256
        byte[] keyBytes = jwtSecret.getBytes(StandardCharsets.UTF_8);
        return Keys.hmacShaKeyFor(keyBytes);
    }
}
