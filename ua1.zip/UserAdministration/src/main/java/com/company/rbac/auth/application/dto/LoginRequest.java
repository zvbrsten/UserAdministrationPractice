package com.company.rbac.auth.application.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/**
 * Request DTO for the login endpoint ({@code POST /api/v1/auth/login}).
 * Carries the credentials the client submits to obtain a JWT.
 */
@Data
public class LoginRequest {

    @NotBlank(message = "Username cannot be empty")
    private String username;

    @NotBlank(message = "Password cannot be empty")
    private String password;
}
