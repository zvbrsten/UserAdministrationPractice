package com.company.rbac.shared.exception;

/**
 * Base class for all domain-specific runtime exceptions in the RBAC system.
 * All custom domain exceptions should extend this class.
 */
public abstract class RbacException extends RuntimeException {

    private final String errorCode;

    protected RbacException(String errorCode, String message) {
        super(message);
        this.errorCode = errorCode;
    }

    public String getErrorCode() {
        return errorCode;
    }
}
