package com.company.rbac.module.domain.exception;

import com.company.rbac.shared.exception.ResourceNotFoundException;

/**
 * Thrown when a {@link com.company.rbac.module.domain.entity.Module} cannot be found.
 */
public class ModuleNotFoundException extends ResourceNotFoundException {

    public ModuleNotFoundException(Long moduleId) {
        super("Module", moduleId);
    }

    public ModuleNotFoundException(String moduleName) {
        super("Module", moduleName);
    }
}
