package com.company.rbac.role.domain.exception;

import com.company.rbac.shared.exception.ResourceNotFoundException;

/**
 * Thrown when a {@link com.company.rbac.role.domain.entity.Role} cannot be found.
 */
public class RoleNotFoundException extends ResourceNotFoundException {

    public RoleNotFoundException(Long roleId) {
        super("Role", roleId);
    }

    public RoleNotFoundException(String roleName) {
        super("Role", roleName);
    }
}
