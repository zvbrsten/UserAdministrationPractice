package com.company.rbac.user.application.service;

import com.company.rbac.role.domain.entity.Role;
import com.company.rbac.role.domain.exception.RoleNotFoundException;
import com.company.rbac.role.domain.repository.RoleRepository;
import com.company.rbac.user.application.dto.ResetPasswordRequest;
import com.company.rbac.user.application.dto.UserCreateRequest;
import com.company.rbac.user.application.dto.UserResponse;
import com.company.rbac.user.application.dto.UserUpdateRequest;
import com.company.rbac.user.domain.entity.User;
import com.company.rbac.user.domain.exception.UserNotFoundException;
import com.company.rbac.user.domain.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Application service orchestrating all user-related use cases.
 *
 * <p>This service is the single entry point for all user operations and coordinates
 * between the domain model, repository, and cross-domain services (e.g. RoleRepository).</p>
 */
@Service
@Transactional(readOnly = true)
public class UserApplicationService {

    private static final Logger logger = LoggerFactory.getLogger(UserApplicationService.class);

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;

    public UserApplicationService(UserRepository userRepository,
                                  RoleRepository roleRepository,
                                  PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.passwordEncoder = passwordEncoder;
    }

    /**
     * Retrieves all users in the system.
     *
     * @return list of user response DTOs
     */
    public List<UserResponse> getAllUsers() {
        logger.info("Fetching all users");
        return userRepository.findAll().stream()
                .map(this::toResponse)
                .toList();
    }

    /**
     * Retrieves a single user by their username.
     *
     * @param userName the username to search for
     * @return the user response DTO
     * @throws UserNotFoundException if no user with the given username exists
     */
    public UserResponse getUserByUserName(String userName) {
        logger.info("Fetching user with username [{}]", userName);
        User user = userRepository.findByUserNameAndIsDeletedFalse(userName)
                .orElseThrow(() -> new UserNotFoundException(userName));
        return toResponse(user);
    }

    /**
     * Retrieves all users matching a given first name.
     *
     * @param firstName the first name to filter by
     * @return list of matching user response DTOs
     */
    public List<UserResponse> getUsersByFirstName(String firstName) {
        logger.info("Fetching users with firstName [{}]", firstName);
        return userRepository.findAll().stream()
                .filter(u -> u.getFirstName().equals(firstName))
                .map(this::toResponse)
                .toList();
    }

    /**
     * Retrieves all users belonging to a specific role.
     *
     * @param roleName the name of the role to filter by
     * @return list of user response DTOs for the given role
     */
    public List<UserResponse> getUsersByRoleName(String roleName) {
        logger.info("Fetching users under role [{}]", roleName);
        return userRepository.findAll().stream()
                .filter(u -> u.getRole() != null && u.getRole().getRoleName().equals(roleName))
                .map(this::toResponse)
                .toList();
    }

    /**
     * Retrieves the role assigned to a user.
     *
     * @param userName the username to look up
     * @return the role name of the user
     * @throws UserNotFoundException if no user with the given username exists
     */
    public String getRoleForUser(String userName) {
        logger.info("Fetching role for user [{}]", userName);
        User user = userRepository.findByUserNameAndIsDeletedFalse(userName)
                .orElseThrow(() -> new UserNotFoundException(userName));
        return user.getRole() != null ? user.getRole().getRoleName() : null;
    }

    /**
     * Creates a new user.
     *
     * @param request the user creation request
     * @throws IllegalArgumentException if the roleId is invalid
     * @throws UserNotFoundException    if username or email is already taken
     */
    @Transactional
    public void createUser(UserCreateRequest request) {
        logger.info("Creating user with username [{}] and email [{}]", request.getUserName(), request.getEmail());

        if (userRepository.existsByUserName(request.getUserName())) {
            throw new IllegalArgumentException("Username [" + request.getUserName() + "] is already taken.");
        }
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new IllegalArgumentException("Email [" + request.getEmail() + "] is already registered.");
        }

        Role role = roleRepository.findById(request.getRoleId())
                .orElseThrow(() -> new RoleNotFoundException(request.getRoleId()));

        User user = new User();
        user.setUserName(request.getUserName());
        user.setFirstName(request.getFirstName());
        user.setLastName(request.getLastName());
        user.setEmail(request.getEmail());
        user.setPhone(request.getPhone());
        user.setDob(request.getDob());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setRole(role);
        user.setIsActive(true);
        user.setIsDeleted(false);

        userRepository.save(user);
        logger.info("User [{}] created successfully", request.getUserName());
    }

    /**
     * Updates the username of an existing user.
     *
     * @param currentUserName the current username (used to find the user)
     * @param request         the update request containing the new username
     * @throws UserNotFoundException if no user with the given username exists
     */
    @Transactional
    public UserResponse updateUserName(String currentUserName, UserUpdateRequest request) {
        logger.info("Updating username [{}] to [{}]", currentUserName, request.getUserName());
        User user = userRepository.findByUserNameAndIsDeletedFalse(currentUserName)
                .orElseThrow(() -> new UserNotFoundException(currentUserName));
        user.setUserName(request.getUserName());
        userRepository.save(user);
        logger.info("Username updated from [{}] to [{}]", currentUserName, request.getUserName());
        return toResponse(user);
    }

    /**
     * Resets the password for a user.
     *
     * @param userName the username of the user
     * @param request  the password reset request
     * @throws UserNotFoundException    if no user with the given username exists
     * @throws IllegalArgumentException if the new password is blank
     */
    @Transactional
    public void resetPassword(String userName, ResetPasswordRequest request) {
        logger.info("Resetting password for user [{}]", userName);
        User user = userRepository.findByUserNameAndIsDeletedFalse(userName)
                .orElseThrow(() -> new UserNotFoundException(userName));
        user.setPassword(passwordEncoder.encode(request.getNewPassword()));
        userRepository.save(user);
        logger.info("Password reset successfully for user [{}]", userName);
    }

    /**
     * Deletes a user by their username.
     *
     * @param userName the username of the user to delete
     * @throws UserNotFoundException if no user with the given username exists
     */
    @Transactional
    public void deleteUser(String userName) {
        logger.info("Deleting user [{}]", userName);
        User user = userRepository.findByUserNameAndIsDeletedFalse(userName)
                .orElseThrow(() -> new UserNotFoundException(userName));
        userRepository.delete(user);
        logger.info("User [{}] deleted successfully", userName);
    }

    // -------------------------------------------------------------------------
    // Private mapping helper
    // -------------------------------------------------------------------------

    private UserResponse toResponse(User user) {
        return UserResponse.builder()
                .id(user.getId())
                .userName(user.getUserName())
                .firstName(user.getFirstName())
                .lastName(user.getLastName())
                .email(user.getEmail())
                .phone(user.getPhone())
                .dob(user.getDob())
                .profilePictureUrl(user.getProfilePictureUrl())
                .isActive(user.getIsActive())
                .roleName(user.getRole() != null ? user.getRole().getRoleName() : null)
                .createdAt(user.getCreatedAt())
                .updatedAt(user.getUpdatedAt())
                .build();
    }
}
