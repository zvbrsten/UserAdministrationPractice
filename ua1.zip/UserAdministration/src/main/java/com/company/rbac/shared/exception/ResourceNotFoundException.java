package com.company.rbac.shared.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Thrown when a requested resource (User, Role, Permission, Module) cannot be found.
 * Maps to HTTP 404 Not Found.
 */
@ResponseStatus(HttpStatus.NOT_FOUND)
public class ResourceNotFoundException extends RbacException {

    private static final String ERROR_CODE = "RESOURCE_NOT_FOUND";

    public ResourceNotFoundException(String resourceType, Long id) {
        super(ERROR_CODE, resourceType + " with id [" + id + "] was not found.");
    }

    public ResourceNotFoundException(String resourceType, String identifier) {
        super(ERROR_CODE, resourceType + " with identifier [" + identifier + "] was not found.");
    }
}
