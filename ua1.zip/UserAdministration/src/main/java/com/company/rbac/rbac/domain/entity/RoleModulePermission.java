package com.company.rbac.rbac.domain.entity;

import com.company.rbac.module.domain.entity.Module;
import com.company.rbac.permission.domain.entity.Permission;
import com.company.rbac.role.domain.entity.Role;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

/**
 * Domain entity representing the RBAC mapping between a Role, a Module, and a Permission.
 *
 * <p>This three-way join table is the core of the RBAC system. Each row grants a specific
 * permission (e.g. READ) on a specific module (e.g. BILLING) to a specific role (e.g. MANAGER).</p>
 *
 * <p>Primary key: {@link RoleModulePermissionId} (composite of rid, mid, pid).</p>
 */
@Entity
@Table(name = "roles_modules_permissions")
@Getter
@Setter
@NoArgsConstructor
public class RoleModulePermission {

    @EmbeddedId
    private RoleModulePermissionId id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @MapsId("rid")
    @JoinColumn(name = "rid", nullable = false)
    private Role role;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @MapsId("mid")
    @JoinColumn(name = "mid", nullable = false)
    private Module module;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @MapsId("pid")
    @JoinColumn(name = "pid", nullable = false)
    private Permission permission;

    @CreationTimestamp
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    /**
     * Constructor used when all three domain objects are already loaded.
     */
    public RoleModulePermission(Role role, Module module, Permission permission) {
        this.role = role;
        this.module = module;
        this.permission = permission;
        this.id = new RoleModulePermissionId(role.getId(), module.getId(), permission.getId());
    }

    /**
     * Constructor used for seeding with raw IDs (no eagerly loaded objects).
     */
    public RoleModulePermission(Long rid, Long mid, Long pid) {
        this.id = new RoleModulePermissionId(rid, mid, pid);
    }
}
