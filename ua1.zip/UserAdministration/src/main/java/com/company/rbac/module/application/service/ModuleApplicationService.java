package com.company.rbac.module.application.service;

import com.company.rbac.module.application.dto.ModuleRequest;
import com.company.rbac.module.application.dto.ModuleResponse;
import com.company.rbac.module.domain.entity.Module;
import com.company.rbac.module.domain.repository.ModuleRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Application service orchestrating all module-related use cases.
 */
@Service
@Transactional(readOnly = true)
public class ModuleApplicationService {

    private static final Logger logger = LoggerFactory.getLogger(ModuleApplicationService.class);

    private final ModuleRepository moduleRepository;

    public ModuleApplicationService(ModuleRepository moduleRepository) {
        this.moduleRepository = moduleRepository;
    }

    /**
     * Retrieves all modules in the system.
     */
    public List<ModuleResponse> getAllModules() {
        logger.info("Fetching all modules");
        return moduleRepository.findAll().stream()
                .map(this::toResponse)
                .toList();
    }

    /**
     * Creates a new module.
     *
     * @param request the module creation request
     * @throws IllegalArgumentException if a module with the same name already exists
     */
    @Transactional
    public ModuleResponse createModule(ModuleRequest request) {
        logger.info("Creating module [{}]", request.getModuleName());
        if (moduleRepository.existsByModuleName(request.getModuleName())) {
            throw new IllegalArgumentException("Module [" + request.getModuleName() + "] already exists.");
        }
        Module module = new Module(request.getModuleName());
        Module saved = moduleRepository.save(module);
        logger.info("Module [{}] created with id [{}]", saved.getModuleName(), saved.getId());
        return toResponse(saved);
    }

    // -------------------------------------------------------------------------
    // Private mapping helper
    // -------------------------------------------------------------------------

    private ModuleResponse toResponse(Module module) {
        return ModuleResponse.builder()
                .id(module.getId())
                .moduleName(module.getModuleName())
                .createdAt(module.getCreatedAt())
                .build();
    }
}
