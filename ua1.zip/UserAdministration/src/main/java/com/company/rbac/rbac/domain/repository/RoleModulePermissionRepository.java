package com.company.rbac.rbac.domain.repository;

import com.company.rbac.rbac.domain.entity.RoleModulePermission;
import com.company.rbac.rbac.domain.entity.RoleModulePermissionId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Repository interface for {@link RoleModulePermission} persistence operations.
 */
@Repository
public interface RoleModulePermissionRepository extends JpaRepository<RoleModulePermission, RoleModulePermissionId> {

    /**
     * Retrieves all module–permission mappings for a given role ID.
     *
     * @param roleId the ID of the role
     * @return list of RBAC mappings belonging to the role
     */
    @Query("SELECT rmp FROM RoleModulePermission rmp WHERE rmp.id.rid = :roleId")
    List<RoleModulePermission> findAllByRoleId(@Param("roleId") Long roleId);
}
