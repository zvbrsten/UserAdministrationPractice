# Architecture — RBAC User Administration System

## Overview

This project follows **Domain-Driven Design (DDD)** with a layered architecture inside each bounded context (domain).

---

## Package Structure

```
com.company.rbac/
├── RbacApplication.java          ← Spring Boot entry point
│
├── user/                         ← User bounded context
│   ├── domain/
│   │   ├── entity/User.java      ← JPA entity
│   │   ├── repository/           ← Spring Data repository interface
│   │   └── exception/            ← UserNotFoundException, etc.
│   ├── application/
│   │   ├── dto/                  ← UserResponse, UserCreateRequest, etc.
│   │   └── service/              ← UserApplicationService (use cases)
│   └── presentation/
│       └── controller/           ← UserController (/api/v1/users)
│
├── role/                         ← Role bounded context (same structure)
├── permission/                   ← Permission bounded context
├── module/                       ← Module bounded context
│
├── rbac/                         ← RBAC mapping bounded context
│   ├── domain/entity/
│   │   ├── RoleModulePermission.java
│   │   └── RoleModulePermissionId.java (composite key)
│   ├── domain/repository/        ← RoleModulePermissionRepository
│   ├── application/
│   │   ├── dto/
│   │   └── service/RbacMappingApplicationService.java
│   └── presentation/
│       └── controller/RbacController.java (/api/v1/rbac)
│
├── notification/                 ← Email notifications
│   ├── application/service/EmailService.java  ← Interface (port)
│   ├── infrastructure/JavaMailEmailService.java ← Implementation (adapter)
│   └── presentation/NotificationController.java
│
└── shared/                       ← Cross-cutting concerns
    ├── config/
    │   ├── SecurityConfig.java   ← Spring Security
    │   ├── MailConfig.java       ← JavaMailSender bean
    │   └── RedisConfig.java      ← RedisTemplate bean
    ├── exception/
    │   ├── RbacException.java           ← Base exception
    │   ├── ResourceNotFoundException.java
    │   └── GlobalExceptionHandler.java  ← @RestControllerAdvice
    └── response/
        ├── ApiResponse.java      ← Generic success wrapper
        └── ErrorResponse.java    ← Standardized error body
```

---

## Layering Rules

| Layer | Responsibility | May depend on |
|---|---|---|
| `domain` | Entities, repository interfaces, exceptions | Nothing else |
| `application` | Use-case orchestration, DTOs, services | `domain` |
| `infrastructure` | JPA implementations, external adapters | `domain`, `application` |
| `presentation` | HTTP controllers | `application` DTOs and services |
| `shared` | Cross-cutting (configs, wrappers, base exceptions) | Nothing domain-specific |

---

## RBAC Data Model

```
roles ──┐
        │
        ├── roles_modules_permissions ──── modules
        │         (rid, mid, pid)
        └──────────────────────────────── permissions

users ──── roles   (many-to-one: each user has exactly one role)
```

### Permission Matrix

| Role | User Management | Leads | Customers | Reports | Settings | Billing |
|---|---|---|---|---|---|---|
| SUPERADMIN | C R U D | C R U D | C R U D | C R U D | C R U D | C R U D |
| ADMIN | C R U D | C R U D | C R U D | R | — | C R |
| MANAGER | — | C R U | C R U | R | — | R |
| EMPLOYEE | — | C R | R | R | — | — |
| VIEWER | — | R | R | R | — | — |

---

## Error Handling

All errors return a consistent JSON structure:

```json
{
  "timestamp": "2026-06-07T16:00:00",
  "status": 404,
  "error": "RESOURCE_NOT_FOUND",
  "message": "User with identifier [john] was not found.",
  "details": null
}
```

Validation errors include field-level `details`:

```json
{
  "timestamp": "2026-06-07T16:00:00",
  "status": 400,
  "error": "VALIDATION_FAILED",
  "message": "Input validation failed. Check the 'details' field.",
  "details": {
    "email": "Invalid email address format",
    "password": "Password must be at least 8 characters"
  }
}
```

---

## Incomplete Features

### Redis OTP
- **Status:** Infrastructure in place (RedisConfig, RedisTemplate bean)
- **TODO:** Implement `OtpService` interface and Redis-backed implementation
  - Store OTP with TTL using `redisTemplate.opsForValue().set(key, otp, duration)`
  - Validate and delete after use

### JWT Authentication
- **Status:** ✅ Implemented
- **Login:** `POST /api/v1/auth/login` → returns `{ "accessToken": "eyJ...", "tokenType": "Bearer" }`
- **Usage:** Include `Authorization: Bearer <token>` header on all protected requests
- **Components:**
  - `JwtTokenProvider` — generates and validates HS256-signed tokens
  - `JwtAuthenticationFilter` — `OncePerRequestFilter` that reads and validates Bearer tokens
  - `JdbcUserDetailsService` — loads users from PostgreSQL for login flow
  - `JwtAuthenticationEntryPoint` — returns JSON 401 for unauthenticated requests
  - `SecurityConfig` — stateless session, JWT filter wired before `UsernamePasswordAuthenticationFilter`
- **Config:** `app.jwt.secret` and `app.jwt.expiration-ms` in `application.yml`

