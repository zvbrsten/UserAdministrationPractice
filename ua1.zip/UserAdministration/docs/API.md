# API Reference — RBAC User Administration System

> Base URL: `http://localhost:8080/api/v1`
> Authentication: HTTP Basic (username + password)
> Content-Type: `application/json`

---

## Users — `/api/v1/users`

### GET `/api/v1/users`
List all users.

**Required role:** SUPERADMIN, ADMIN, MANAGER

**Response 200:**
```json
{
  "success": true,
  "message": "Users retrieved successfully",
  "data": [
    {
      "id": 1,
      "userName": "superadmin",
      "firstName": "Yash",
      "lastName": "Sharma",
      "email": "superadmin@example.com",
      "phone": "+919140742404",
      "dob": "2004-01-26",
      "isActive": true,
      "roleName": "SUPERADMIN"
    }
  ],
  "timestamp": "2026-06-07T16:00:00"
}
```

---

### POST `/api/v1/users`
Create a new user.

**Required role:** SUPERADMIN, ADMIN, MANAGER, EMPLOYEE

**Request Body:**
```json
{
  "userName": "john.doe",
  "firstName": "John",
  "lastName": "Doe",
  "email": "john.doe@example.com",
  "phone": "+919876543210",
  "password": "securepassword123",
  "dob": "1995-03-15",
  "roleId": 2
}
```

**Response 201:**
```json
{
  "success": true,
  "message": "User created successfully",
  "timestamp": "2026-06-07T16:00:00"
}
```

---

### GET `/api/v1/users/by-username/{userName}`
Get a user by username.

**Required role:** SUPERADMIN, ADMIN, MANAGER

---

### GET `/api/v1/users/by-firstname/{firstName}`
Get all users with a specific first name.

---

### GET `/api/v1/users/by-role/{roleName}`
Get all users belonging to a role.

---

### GET `/api/v1/users/{userName}/role`
Get the role assigned to a specific user.

---

### PUT `/api/v1/users/{userName}`
Update a user's username.

**Required role:** SUPERADMIN, ADMIN, MANAGER

**Request Body:**
```json
{ "userName": "new.username" }
```

---

### PATCH `/api/v1/users/{userName}/password`
Reset a user's password.

**Request Body:**
```json
{ "newPassword": "newSecurePass123" }
```

---

### DELETE `/api/v1/users/{userName}`
Delete a user by username.

**Required role:** SUPERADMIN, ADMIN

---

## Roles — `/api/v1/roles`

| Method | Path | Description | Min Role |
|---|---|---|---|
| GET | `/api/v1/roles` | List all roles | MANAGER |
| POST | `/api/v1/roles` | Create a new role | EMPLOYEE |
| PUT | `/api/v1/roles/{roleName}` | Update a role name | MANAGER |
| DELETE | `/api/v1/roles/{roleName}` | Delete a role | ADMIN |

**Example request body (POST/PUT):**
```json
{ "roleName": "ANALYST" }
```

---

## Permissions — `/api/v1/permissions`

| Method | Path | Description |
|---|---|---|
| GET | `/api/v1/permissions` | List all permissions |
| POST | `/api/v1/permissions` | Create a new permission |

**Example request body:**
```json
{ "permissionName": "EXPORT" }
```

---

## Modules — `/api/v1/modules`

| Method | Path | Description |
|---|---|---|
| GET | `/api/v1/modules` | List all modules |
| POST | `/api/v1/modules` | Create a new module |

**Example request body:**
```json
{ "moduleName": "ANALYTICS" }
```

---

## RBAC Mappings — `/api/v1/rbac`

| Method | Path | Description |
|---|---|---|
| GET | `/api/v1/rbac` | List all role-module-permission mappings |
| POST | `/api/v1/rbac` | Create a new mapping |

**Example request body:**
```json
{
  "roleName": "MANAGER",
  "moduleName": "REPORTS",
  "permissionName": "READ"
}
```

---

## Notifications — `/api/v1/notifications`

### POST `/api/v1/notifications/email`
Send a plain-text email.

**Request Body:**
```json
{
  "recipient": "user@example.com",
  "subject": "Welcome to RBAC System",
  "msgBody": "Your account has been created."
}
```

---

## Error Responses

All errors follow this format:

```json
{
  "timestamp": "2026-06-07T16:00:00",
  "status": 404,
  "error": "RESOURCE_NOT_FOUND",
  "message": "User with identifier [john] was not found.",
  "details": null
}
```

| HTTP Status | Error Code | When |
|---|---|---|
| 400 | `VALIDATION_FAILED` | Request body fails `@Valid` |
| 400 | `INVALID_INPUT` | Illegal argument (e.g. duplicate name) |
| 404 | `RESOURCE_NOT_FOUND` | Entity not found by ID or name |
| 500 | `INTERNAL_SERVER_ERROR` | Unexpected server error |
