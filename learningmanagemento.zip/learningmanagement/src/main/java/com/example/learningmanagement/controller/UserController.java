package com.example.learningmanagement.controller;

import com.example.learningmanagement.dto.TaskDTO;
import com.example.learningmanagement.dto.UserRequestDTO;
import com.example.learningmanagement.dto.UserResponseDTO;
import com.example.learningmanagement.response.ApiResponse;
import com.example.learningmanagement.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import tools.jackson.databind.JsonNode;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/users")
@RequiredArgsConstructor
@Tag(
        name = "Users",
        description = "APIs for managing user lifecycle: creation, retrieval, update, deletion, " +
                "topic assignment, task assignment, and progress tracking."
)
public class UserController {


    private final UserService userService;



    @PostMapping
    @Operation(
            summary = "Create a new user",
            description = "Registers a new user (TRAINEE by default). Admins may pass a role field to create TRAINER or ADMIN accounts."
    )
    public ResponseEntity<ApiResponse<UserResponseDTO>> createUser(
            @Valid @RequestBody UserRequestDTO dto) {

        UserResponseDTO created = userService.createUser(dto);
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(ApiResponse.success("User created successfully", created));
    }

    @GetMapping
    @Operation(
            summary = "Retrieve all users (paginated)",
            description = "Returns a paginated list of all users. Use ?page=0&size=20&sort=lastName,asc for control."
    )
    public ResponseEntity<ApiResponse<Page<UserResponseDTO>>> getAllUsers(
            @PageableDefault(size = 20, sort = "id") Pageable pageable) {

        Page<UserResponseDTO> page = userService.getAllUsers(pageable);
        return ResponseEntity.ok(ApiResponse.success("Users retrieved successfully", page));
    }


    @GetMapping("/tasks/{email}")
    public ResponseEntity<ApiResponse<List<TaskDTO>>> getTasks(@PathVariable String email){
        return ResponseEntity.ok(ApiResponse.success("fetched all tasks",userService.getPersonalTasks(email)));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get user by ID")
    public ResponseEntity<ApiResponse<UserResponseDTO>> getUserById(
            @Parameter(description = "User ID") @PathVariable Long id) {

        return ResponseEntity.ok(
                ApiResponse.success("User retrieved successfully", userService.getUserById(id)));
    }

    @GetMapping("/email/{email}")
    @Operation(summary = "Get user by email address")
    public ResponseEntity<ApiResponse<UserResponseDTO>> getUserByEmail(
            @PathVariable String email) {

        return ResponseEntity.ok(
                ApiResponse.success("User retrieved successfully", userService.getUserByEmail(email)));
    }

    @GetMapping("/by-/pendingTasks")
    public ResponseEntity<ApiResponse<Map<String, List<TaskDTO>>>> getUserByPendingTasks(){
        return ResponseEntity.ok(ApiResponse.success("Users retrieved successfully",userService.filterByPendingTask()));
    }
    @GetMapping("/by-/{topicId}")
    public ResponseEntity<ApiResponse<List<UserResponseDTO>>> getUserByTopicId(@PathVariable Long topicId){
        return ResponseEntity.ok(ApiResponse.success("Users retrieved successfully",userService.filterByTopic(topicId)));
    }
    @PatchMapping("CompleteTask/{userId}/{TaskID}")
    public ResponseEntity<ApiResponse<Void>> markascompleted(@PathVariable Long userId,@PathVariable Long TaskID){
        userService.updateTaskAsCompleted(userId,TaskID);
        return ResponseEntity.ok(ApiResponse.success("Marked as Comepleted"));
    }
    @PutMapping("/{id}")
    @Operation(
            summary = "Update user details",
            description = "Updates first name, last name, phone, and optionally password. Email cannot be changed."
    )
    public ResponseEntity<ApiResponse<UserResponseDTO>> updateUser(
            @PathVariable Long id,
            @Valid @RequestBody UserRequestDTO dto) {

        return ResponseEntity.ok(
                ApiResponse.success("User updated successfully", userService.updateUser(id, dto)));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete a user by ID")
    public ResponseEntity<ApiResponse<Void>> deleteUser(@PathVariable Long id) {
        userService.deleteUser(id);
        return ResponseEntity.ok(ApiResponse.success("User deleted successfully", null));
    }

    // ------------------------------------------------------------------ //
    //  TOPIC ASSIGNMENT
    // ------------------------------------------------------------------ //

    @PostMapping("/{userId}/topics/{topicId}")
    @Operation(
            summary = "Assign a learning topic to a user",
            description = "Creates a UserTopic mapping. Returns 400 if the topic is already assigned."
    )
    public ResponseEntity<ApiResponse<Void>> assignTopic(
            @PathVariable Long userId,
            @PathVariable Long topicId) {

        userService.assignTopic(userId, topicId);
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(ApiResponse.success("Topic assigned successfully", null));
    }

    @DeleteMapping("/{userId}/topics/{topicId}")
    @Operation(summary = "Remove a learning topic from a user")
    public ResponseEntity<ApiResponse<Void>> removeTopic(
            @PathVariable Long userId,
            @PathVariable Long topicId) {

        userService.removeTopic(userId, topicId);
        return ResponseEntity.ok(ApiResponse.success("Topic removed successfully", null));
    }

    @GetMapping("/{userId}/topics")
    @Operation(summary = "List all topic titles assigned to a user")
    public ResponseEntity<ApiResponse<List<String>>> getUserTopics(
            @PathVariable Long userId) {

        return ResponseEntity.ok(
                ApiResponse.success("Topics retrieved successfully", userService.getUserTopics(userId)));
    }

    // ------------------------------------------------------------------ //
    //  TASK ASSIGNMENT
    // ------------------------------------------------------------------ //

    @PostMapping("/{userId}/tasks/{taskId}")
    @Operation(
            summary = "Assign an existing task to a user",
            description = "Links an already-created Task to a User. Returns 400 if already assigned."
    )
    public ResponseEntity<ApiResponse<Void>> assignTask(
            @PathVariable Long userId,
            @PathVariable Long taskId) {

        userService.assignTask(userId, taskId);
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(ApiResponse.success("Task assigned successfully", null));
    }

    // ------------------------------------------------------------------ //
    //  PROGRESS TRACKING
    // ------------------------------------------------------------------ //

    @PatchMapping("/{userId}/tasks/{taskId}/progress")
    @Operation(
            summary = "Update task progress percentage",
            description = "Trainees use this to report progress (0–100). " +
                    "Reaching 100 automatically marks the task as COMPLETED."
    )
    public ResponseEntity<ApiResponse<Void>> updateTaskProgress(
            @PathVariable Long userId,
            @PathVariable Long taskId,
            @Parameter(description = "Progress value 0–100")
            @RequestParam Long progress) {

        userService.updateTaskProgress(userId, taskId, progress);
        return ResponseEntity.ok(ApiResponse.success("Progress updated successfully", null));
    }



    //testing my knowledge not related to project (delete if found)


}