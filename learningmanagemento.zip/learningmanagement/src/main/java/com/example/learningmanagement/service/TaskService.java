package com.example.learningmanagement.service;

import com.example.learningmanagement.dto.TaskDTO;
//import com.example.learningmanagement.dto.TaskRequestDTO;
//import com.example.learningmanagement.dto.TaskResponseDTO;
import com.example.learningmanagement.dto.UserResponseDTO;
import com.example.learningmanagement.entity.*;
import com.example.learningmanagement.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.security.crypto.password.PasswordEncoder;
//import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class TaskService {
    private final UserTopicRepository userTopicRepository;
    private final TopicTaskRepository topicTaskRepository;
    private final TopicRepository topicRepository;
    private final UserRepository userRepository;
    private final TaskRepository taskRepository;

    public TaskDTO createTask(TaskDTO dto) {
        log.info("Creating task with email");

        if (taskRepository.existsByTitle(dto.getTitle())) {
            throw new RuntimeException("Task already exists");
        }
        

        Task task = new Task();
        task.setTitle(dto.getTitle());
        task.setDescription(dto.getDescription());
        task.setProgress(0L);
        task.setPriority(dto.getPriority());
        task.setStatus("PENDING");
        task.setDueDate(dto.getDueDate());
        task.setUser(userRepository.findByEmail(dto.getEmail()).orElseThrow(()->new RuntimeException("not found")));
        TopicTask tt=new TopicTask(task,topicRepository.findByTitle(dto.getTopicName()).orElseThrow(()->new RuntimeException("Not found")));
        task.getTopicTasks().add(tt);
        taskRepository.save(task);
        topicTaskRepository.save(tt);
        UserTopic userTopic=new UserTopic(userRepository.findByEmail(dto.getEmail()).orElseThrow(()->new RuntimeException("Not found")),topicRepository.findByTitle(dto.getTopicName()).orElseThrow(()->new RuntimeException("Not found")));
        userTopicRepository.save(new UserTopic(userRepository.findByEmail(dto.getEmail()).orElseThrow(()->new RuntimeException("Not found")),topicRepository.findByTitle(dto.getTopicName()).orElseThrow(()->new RuntimeException("Not found"))));
        return dto;
    }
    private TaskDTO mapToResponse(Task task) {
        return new TaskDTO(task);
    }
    
}