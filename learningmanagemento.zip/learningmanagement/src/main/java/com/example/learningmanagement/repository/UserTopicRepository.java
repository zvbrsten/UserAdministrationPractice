package com.example.learningmanagement.repository;

import com.example.learningmanagement.entity.UserTopic;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface UserTopicRepository extends JpaRepository<UserTopic,Long> {
    boolean existsByUserIdAndTopicId(Long userId, Long topicId);

    Optional<UserTopic> findByUserIdAndTopicId(Long userId, Long topicId);

    Optional<UserTopic> findAllByUserId(Long userId);

    List<UserTopic> findAllByTopicId(Long topicId);
}
