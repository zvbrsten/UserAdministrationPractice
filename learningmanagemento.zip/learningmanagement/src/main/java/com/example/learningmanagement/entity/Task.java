package com.example.learningmanagement.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

import java.time.LocalDate;
import java.util.LinkedHashSet;
import java.util.Set;

@Entity
@Table(name = "tasks")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Task {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Task title cant be blank")
    @Column(name = "title", nullable = false, unique = true, length = 50)
    private String title;

    @Column(name = "description")
    private String description;

    @NotBlank
    @Column(name = "priority", nullable = false)
    private String priority;

    @Future
    @Column(name = "due_date")
    private LocalDate dueDate;

    @Column(name="status")
    private String status;

    @Column(name="progress")
    @Max(value = 100)
    private Long progress;

    // Many Tasks belong to One User
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    // Task <-> Topic through TopicTask
    @OneToMany(mappedBy = "task", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<TopicTask> topicTasks = new LinkedHashSet<>();
}