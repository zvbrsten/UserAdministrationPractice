package com.example.learningmanagement.dto;


import com.example.learningmanagement.entity.User;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter

public class UserDTO {

    private Long userId;
    @NotBlank(message = "firstname cant be blank")
    private String firstName;
    @NotBlank(message = "lastname cant be blank")
    private String lastName;
    @Email(message="Enter valid email id")
    private String email;
    @NotBlank
    @Size(min = 10, max = 10)
    @Pattern(regexp = "^[0-9]+$")
    private String phone;

    private String role;

    private String status;
    public UserDTO(User userDTO){
        this.firstName= userDTO.getFirstName();
        this.lastName=userDTO.getLastName();
        this.email= userDTO.getEmail();
        this.phone= userDTO.getPhone();
        this.role=userDTO.getRole().toString();
        this.status=userDTO.getStatus();
    }


}