package com.example.learningmanagement.service;

import com.example.learningmanagement.dto.TaskDTO;
import com.example.learningmanagement.dto.UserRequestDTO;
import com.example.learningmanagement.dto.UserResponseDTO;
import com.example.learningmanagement.entity.*;
import com.example.learningmanagement.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.security.crypto.password.PasswordEncoder;
//import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.*;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class UserService {
    private final RoleRepository roleRepository;

    private final TaskRepository       taskRepository;
    private final UserRepository       userRepository;
    private final TopicRepository      topicRepository;
    private final UserTopicRepository  userTopicRepository;
//    private final PasswordEncoder passwordEncoder=new BCryptPasswordEncoder();



    public UserResponseDTO createUser(UserRequestDTO dto) {
        log.info("Creating user with email {}", dto.getEmail());

        if (userRepository.existsByEmail(dto.getEmail())) {
            throw new RuntimeException("User already exists with email: " + dto.getEmail());
        }
        if (userRepository.existsByPhone(dto.getPhone())) {
            throw new RuntimeException("Phone number already in use");
        }

        User user = new User();
        user.setFirstName(dto.getFirstName());
        user.setLastName(dto.getLastName());
        user.setEmail(dto.getEmail());
        user.setPhone(dto.getPhone());
        user.setPasswordHash(dto.getPassword());
        user.setJoiningDate(LocalDate.now());
        // Default role is TRAINEE; callers with ADMIN authority can pass a role override
        user.setRole(roleRepository.findByName(dto.getRole()));
        user.setStatus("ACTIVE");

        return mapToResponse(userRepository.save(user));
    }


    @Transactional(readOnly = true)
    public UserResponseDTO getUserById(Long id) {
        return mapToResponse(findUserOrThrow(id));
    }

    @Transactional(readOnly = true)
    public UserResponseDTO getUserByEmail(String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found with email: " + email));
        return mapToResponse(user);
    }

    @Transactional(readOnly = true)
    public Page<UserResponseDTO> getAllUsers(Pageable pageable) {
        return userRepository.findAll(pageable).map(this::mapToResponse);
    }



    public UserResponseDTO updateUser(Long id, UserRequestDTO dto) {
        User user = findUserOrThrow(id);

        user.setFirstName(dto.getFirstName());
        user.setLastName(dto.getLastName());
        user.setPhone(dto.getPhone());


        if (dto.getPassword() != null && !dto.getPassword().isBlank()) {
            user.setPasswordHash(dto.getPassword());
        }

        log.info("Updated user id={}", id);
        return mapToResponse(userRepository.save(user));
    }



    public void deleteUser(Long id) {
        User user = findUserOrThrow(id);
        userRepository.delete(user);
        log.info("Deleted user id={}", id);
    }

    // ------------------------------------------------------------------ //
    //  TOPIC ASSIGNMENT
    // ------------------------------------------------------------------ //

    public void assignTopic(Long userId, Long topicId) {
        User  user  = findUserOrThrow(userId);
        Topic topic = topicRepository.findById(topicId)
                .orElseThrow(() -> new RuntimeException("Topic not found with id: " + topicId));

        if (userTopicRepository.existsByUserIdAndTopicId(userId, topicId)) {
            throw new RuntimeException("Topic is already assigned to this user");
        }

        UserTopic userTopic = new UserTopic();
        userTopic.setUser(user);
        userTopic.setTopic(topic);
        userTopicRepository.save(userTopic);

        log.info("Assigned topic id={} to user id={}", topicId, userId);
    }

    public void removeTopic(Long userId, Long topicId) {
        UserTopic userTopic = userTopicRepository.findByUserIdAndTopicId(userId, topicId)
                .orElseThrow(() -> new RuntimeException("Topic assignment not found"));
        userTopicRepository.delete(userTopic);
        log.info("Removed topic id={} from user id={}", topicId, userId);
    }

    @Transactional(readOnly = true)
    public List<String> getUserTopics(Long userId) {
        if (!userRepository.existsById(userId)) {
            throw new RuntimeException("User not found with id: " + userId);
        }
        return userTopicRepository.findAllByUserId(userId)
                .stream()
                .map(ut -> ut.getTopic().getTitle())
                .toList();
    }

    // ------------------------------------------------------------------ //
    //  TASK ASSIGNMENT
    // ------------------------------------------------------------------ //


    public void assignTask(Long userId, Long taskId) {
        User user = findUserOrThrow(userId);
        Task task = taskRepository.findById(taskId)
                .orElseThrow(() -> new RuntimeException("Task not found with id: " + taskId));


        if (task.getUser() != null && task.getUser().getId().equals(userId)) {
            throw new RuntimeException("Task is already assigned to this user");
        }

        task.setUser(user);
        taskRepository.save(task);

        log.info("Assigned task id={} to user id={}", taskId, userId);
    }


    public void updateTaskProgress(Long userId, Long taskId, Long progress) {
        if (progress < 0 || progress > 100) {
            throw new RuntimeException("Progress must be between 0 and 100");
        }


        findUserOrThrow(userId);

        Task task = taskRepository.findById(taskId)
                .orElseThrow(() -> new RuntimeException("Task not found with id: " + taskId));

        // Ensure the task actually belongs to the requesting user
        if (task.getUser() == null || !task.getUser().getId().equals(userId)) {
            throw new RuntimeException("Task is not assigned to user id: " + userId);
        }

        task.setProgress(progress);

        // Auto-update status based on progress
        if (progress == 100) {

        } else if (progress > 0) {
            task.setStatus("IN_PROGRESS");
        }

        taskRepository.save(task);          // FIX: was missing in original
        log.info("Updated progress of task id={} to {}% for user id={}", taskId, progress, userId);
    }

    public void updateTaskAsCompleted(Long userId, Long taskId) {
        Long progress=100L;



        findUserOrThrow(userId);

        Task task = taskRepository.findById(taskId)
                .orElseThrow(() -> new RuntimeException("Task not found with id: " + taskId));

        // Ensure the task actually belongs to the requesting user
        if (task.getUser() == null || !task.getUser().getId().equals(userId)) {
            throw new RuntimeException("Task is not assigned to user id: " + userId);
        }


        task.setProgress(progress);

        task.setStatus("COMPLETED");


        taskRepository.save(task);
        log.info("Updated progress of task id={} to completed for user id={}", taskId, userId);
    }


    public List<TaskDTO> getPersonalTasks(String email){
        return userRepository.findByEmail(email).orElseThrow(()->new RuntimeException("Not Found")).getTasks().stream().map(t->new TaskDTO(t)).toList();
    }

    private User findUserOrThrow(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found with id: " + id));
    }

    public List<UserResponseDTO> filterByTopic(Long topicId){
        return userTopicRepository.findAllByTopicId(topicId).stream().map(u->new UserResponseDTO(u.getUser())).toList();
    }
    public Map<String, List<TaskDTO>> filterByPendingTask() {

        Map<String, List<TaskDTO>> map = new HashMap<>();

        List<Task> tasks = taskRepository.findByStatus("PENDING");

        tasks.forEach(task -> {
            UserResponseDTO user = new UserResponseDTO(task.getUser());

            map.computeIfAbsent(user.getEmail(), k -> new ArrayList<>())
                    .add(new TaskDTO(task));
        });

        return map;
    }

    private UserResponseDTO mapToResponse(User user) {
        return new UserResponseDTO(user);
    }
}