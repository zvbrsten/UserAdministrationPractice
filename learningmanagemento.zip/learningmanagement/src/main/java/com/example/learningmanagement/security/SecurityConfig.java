package com.example.learningmanagement.security;


import com.example.learningmanagement.exception.NotFound;
import com.example.learningmanagement.repository.UserRepository;
import com.example.learningmanagement.repository.UserRepository;
import com.example.learningmanagement.security.filter.JwtTokenValidatorFilter;
import com.example.learningmanagement.entity.User;
import com.example.learningmanagement.repository.RoleRepository;
import com.example.learningmanagement.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Qualifier;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;

import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
import org.springframework.security.web.csrf.CookieCsrfTokenRepository;
import org.springframework.security.web.csrf.CsrfTokenRequestAttributeHandler;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.security.authentication.AuthenticationProvider;


import java.util.*;
import java.util.stream.Collectors;


@Configuration
@EnableWebSecurity
@RequiredArgsConstructor
public class SecurityConfig {


    private final List<String> trainerPaths=List.of(
            "/api/v1/tasks/**",
            "/api/v1/topic/**",
            "/api/v1/learnings/{learningId}/topics/{topicId}",
            "/api/v1/learnings/{learningId}/topics/{topicId}",
            "/api/v1/learnings/{learningId}/tasks/{taskId}"
    );

    @Qualifier("securedPaths")
    private final List<String> adminPaths;

    private final UserRepository learningRepository;
    private final RoleRepository roleRepository;
    @Bean
        //@Order(SecurityFilterProperties.BASIC_AUTH_ORDER) use if multiple beans
    SecurityFilterChain defaultSecurityFilterChain(HttpSecurity http){

        return http.authorizeHttpRequests((requests)->{
                    trainerPaths.forEach(path->requests.requestMatchers(path).hasAnyRole("ADMIN","TRAINER"));
                    //securedPaths.forEach(path->requests.requestMatchers(path).permitAll());//designation should have " Admin" in the end
                    requests.anyRequest().permitAll();

                })
                .csrf(csrf->csrf.disable())
               .csrf(csrfConfig->csrfConfig.csrfTokenRepository(CookieCsrfTokenRepository.withHttpOnlyFalse())
                       .csrfTokenRequestHandler(new CsrfTokenRequestAttributeHandler()))
                .cors(corsConfig->corsConfig.configurationSource(corsConfigurationSource()))
                .addFilterBefore(new JwtTokenValidatorFilter(publicPaths), BasicAuthenticationFilter.class)
                .formLogin(flc -> flc.disable())//disables the ui page of login while calling api from browser
                .httpBasic(h->h.disable())
                .build();

        //formlogin for ui based login,httpbasic for popup based or postman basic auth login



    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource(){
        CorsConfiguration config=new CorsConfiguration();
        config.setAllowedOrigins(Arrays.asList("http://localhost:5173"));
        config.setAllowedMethods(Collections.singletonList("*"));
        config.setAllowedHeaders(Collections.singletonList("*"));
        config.setAllowCredentials(true);
        config.setMaxAge(3600L);

        UrlBasedCorsConfigurationSource source=new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**",config);
        return source;

    }


    @Bean
    public UserDetailsService UserDetailsService(UserRepository repository) {
        return username -> repository.findByEmail(username)
                .map(User -> User.builder()
                        .username(User.getEmail())
                        .password(User.getPasswordHash())
                        .roles(User.getRole().getName())
                        .build())
                .orElseThrow(() ->
                        new UsernameNotFoundException(
                                "User not found: " + username));
    }

    @Bean
    public AuthenticationManager authenticationManager(UserRepository learningRepository) {
        var autheticationProvider = new DaoAuthenticationProvider(UserDetailsService(learningRepository));
        autheticationProvider.setPasswordEncoder(passwordEncoder());
        return new ProviderManager(autheticationProvider);
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

}
