package com.example.learningmanagement.dto;


import com.example.learningmanagement.entity.Topic;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter
@ToString
@NoArgsConstructor
public class TopicDTO {

    private Long topicId;


    @NotBlank(message = "title cant be blank")
    private String title;


    public TopicDTO(Topic topic){

        this.title=topic.getTitle();
    }
}