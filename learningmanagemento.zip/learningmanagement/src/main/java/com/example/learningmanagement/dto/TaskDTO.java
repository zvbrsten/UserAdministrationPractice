package com.example.learningmanagement.dto;


import com.example.learningmanagement.entity.Task;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.time.LocalDate;


@Getter
@Setter
@ToString
@NoArgsConstructor
public class TaskDTO {

    private Long taskId;


    @NotBlank(message = "title cant be blank")
    private String title;

    private String description;

    private Long progress;

    private String priority;

    private LocalDate dueDate;

    private String email;

    private String topicName;


    public TaskDTO(Task task) {
        this.taskId = task.getId();
        this.title = task.getTitle();
        this.description = task.getDescription();
        this.progress = task.getProgress();
        this.dueDate = task.getDueDate();
        this.priority = task.getPriority();
    }


}