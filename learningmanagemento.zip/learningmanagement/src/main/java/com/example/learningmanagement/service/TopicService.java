package com.example.learningmanagement.service;

import com.example.learningmanagement.dto.TopicDTO;
//import com.example.learningmanagement.dto.TopicRequestDTO;
//import com.example.learningmanagement.dto.TopicResponseDTO;
import com.example.learningmanagement.dto.UserResponseDTO;
import com.example.learningmanagement.entity.*;
import com.example.learningmanagement.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.security.crypto.password.PasswordEncoder;
//import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class TopicService {
    private final UserRepository userRepository;
    private final TopicRepository topicRepository;

    public TopicDTO createTopic(TopicDTO dto) {
        log.info("Creating topic");

        if (topicRepository.existsByTitle(dto.getTitle())) {
            throw new RuntimeException("Topic already exists");
        }


        Topic topic = new Topic();
        topic.setTitle(dto.getTitle());


        return mapToResponse(topicRepository.save(topic));
    }
    private TopicDTO mapToResponse(Topic topic) {
        return new TopicDTO(topic);
    }
}