package com.example.learningmanagement.dto;

import com.example.learningmanagement.entity.User;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
public class UserResponseDTO {

    private Long id;
    private String firstName;
    private String lastName;
    private String email;
    private String phone;
    private String role;
    private String status;
    private LocalDate joiningDate;

    /** Convenience constructor — maps directly from a User entity. */
    public UserResponseDTO(User user) {
        this.id          = user.getId();
        this.firstName   = user.getFirstName();
        this.lastName    = user.getLastName();
        this.email       = user.getEmail();
        this.phone       = user.getPhone();
        this.role        = user.getRole()==null?"TRAINEE":user.getRole().toString();
        this.status      = user.getStatus();
        this.joiningDate = user.getJoiningDate();
    }
}