package com.example.learningmanagement.repository;


import com.example.learningmanagement.dto.UserResponseDTO;
import com.example.learningmanagement.entity.Task;


import jakarta.validation.constraints.NotBlank;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;


public interface TaskRepository extends JpaRepository<Task,Long> {


    boolean existsByTitle(@NotBlank(message = "title cant be blank") String title);

    List<Task> findByStatus(String pending);
}
