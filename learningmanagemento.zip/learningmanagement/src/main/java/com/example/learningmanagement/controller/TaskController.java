package com.example.learningmanagement.controller;

import com.example.learningmanagement.dto.TaskDTO;
import com.example.learningmanagement.dto.UserRequestDTO;
import com.example.learningmanagement.dto.UserResponseDTO;
import com.example.learningmanagement.entity.Task;
import com.example.learningmanagement.repository.TaskRepository;
import com.example.learningmanagement.response.ApiResponse;
import com.example.learningmanagement.service.TaskService;
import com.example.learningmanagement.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/tasks")
@RequiredArgsConstructor
@Tag(
        name = "Users",
        description = "APIs for managing user lifecycle: creation, retrieval, update, deletion, " +
                "topic assignment, task assignment, and progress tracking."
)
public class TaskController {

    private final TaskService taskservice;
    private final TaskRepository taskRepository;


    @PostMapping
    public ResponseEntity<ApiResponse<TaskDTO>> createTask(@RequestBody TaskDTO taskDTO){
        TaskDTO taskdto=taskservice.createTask(taskDTO);
        return ResponseEntity.ok(ApiResponse.success("task created successsfully",taskdto));
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<TaskDTO>>> getTasks(){
        List<Task> tasks=taskRepository.findAll();

        return ResponseEntity.ok(ApiResponse.success("Fetching all tasks",tasks.stream().map(t->new TaskDTO(t)).toList()));
    }
}