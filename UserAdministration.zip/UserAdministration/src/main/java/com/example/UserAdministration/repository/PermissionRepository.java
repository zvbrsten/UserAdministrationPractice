package com.example.UserAdministration.repository;

import com.example.UserAdministration.entity.Permission;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PermissionRepository extends JpaRepository<Permission, Long> {
}
