package com.example.UserAdministration.repository;

import com.example.UserAdministration.entity.Module;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ModuleRepository extends JpaRepository<Module, Long> {
}