package com.example.UserAdministration.entity;

import java.time.LocalDateTime;

import jakarta.persistence.*;
import org.hibernate.annotations.Cascade;

@Entity
@Table(name = "users")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name="username", unique = true, nullable = false)
    private String userName;

    @Column(name="firstname", nullable = false)
    private String firstName;

    @Column(name="lastname", nullable = false)
    private String lastName;

    @Column(name="email", unique = true, nullable = false)
    private String email;

    @Column(name="phone", unique = true, nullable = false)
    private String phone;

    @Column(name="pwd_hash", nullable = false)
    private String password;

    @Column(name="dob", nullable = false)
    private String dob;
    @Column(name="profile_picture_url", nullable = true)
    private String profilePictureUrl;

    @Column(name="is_active", nullable = false)

    private Boolean isActive;

    @Column(name="is_deleted", nullable = false)
    private Boolean isDeleted;

    @Column(name="created_at", nullable = false)
    private LocalDateTime createdAt;
    @Column(name="updated_at", nullable = false)
    private LocalDateTime updatedAt;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "role_id", nullable = false)
    private Role role;

    @PrePersist
    protected void onCreate() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }
        if (updatedAt == null) {
            updatedAt = LocalDateTime.now();
        }
        if (isActive == null) {
            isActive = true;
        }
        if (isDeleted == null) {
            isDeleted = false;
        }
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

    // Constructors
    public User() {
    }

    public User(String userName, String firstName, String lastName, String email, String phone,String dob, String password, Long roleId) {
        this.userName = userName;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.phone = phone;
        this.dob = dob;
        this.password = password;
        this.role = new Role();
        this.setRoleId(roleId);
        this.isActive = true;
        this.isDeleted = false;
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }
    // public User(String userName, String firstName, String lastName, String email, String phone,String dob, String password, String roleName) {
    //     this.userName = userName;
    //     this.firstName = firstName;
    //     this.lastName = lastName;
    //     this.email = email;
    //     this.phone = phone;
    //     this.dob = dob;
    //     this.password = password;
    //     this.role = new Role();
    //     this.isActive = true;
    //     this.isDeleted = false;
    //     this.createdAt = LocalDateTime.now();
    //     this.updatedAt = LocalDateTime.now();
    // }
    



    // Getters and setters

    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }


    //////////////////////////////////////////////////////Username
    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }

    ///////////////////////////////////////////////////////FirstName
    public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    ///////////////////////////////////////////////////////LastName
    public String getLastName() {
        return lastName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    ///////////////////////////////////////////////////////Email
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }


    ///////////////////////////////////////////////////////Phone
    public String getPhone() {
        return phone;
    }
    public void setPhone(String phone) {
        this.phone = phone;
    }
    //////////////////////////////////////////////////////Password
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }

    //////////////////////////////////////////////////////DOB
    public String getDob() {
        return dob;
    }
    public void setDob(String dob) {
        this.dob = dob;
    }

    //////////////////////////////////////////////////////ProfilePictureUrl
    public String getProfilePictureUrl() {
        return profilePictureUrl;
    }
    public void setProfilePictureUrl(String profilePictureUrl) {
        this.profilePictureUrl = profilePictureUrl;
    }

    //////////////////////////////////////////////////////IsActive
    public Boolean getIsActive() {
        return isActive;
    }
    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    /////////////////////////////////////////////////////IsDeleted
    public Boolean getIsDeleted() {
        return isDeleted;
    }
    public void setIsDeleted(Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }

    /////////////////////////////////////////////////////CreatedAt
    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
    /////////////////////////////////////////////////////UpdatedAt
    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }
    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public void setRole(String roleName) {
        this.role = new Role(roleName);
    }

    /////////////////////////////////////////////////////RoleId
    public Long getRoleId() {
        return role != null ? role.getId() : null;
    }
    public void setRoleId(Long roleId) {
        if (roleId == null) {
            return;
        }
        if (this.role == null) {
            this.role = new Role();
        }
        this.role.setId(roleId);
    }


}
