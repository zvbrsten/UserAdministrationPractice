package com.example.UserAdministration.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.provisioning.JdbcUserDetailsManager;
import org.springframework.security.provisioning.UserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

import javax.sql.DataSource;

@Configuration
public class SecurityConfig {
//    @Bean
//    public InMemoryUserDetailsManager userDetailsManager(){
//
//        UserDetails superadmin= User.builder()
//                .username("superadmin")
//                .password("{noop}pwd")
//                .roles("SUPERADMIN","ADMIN","MANAGER","EMPLOYEE","VIEWER")
//                .build();
//        UserDetails admin= User.builder()
//                .username("admin")
//                .password("{noop}pwd")
//                .roles("ADMIN","MANAGER","EMPLOYEE","VIEWER")
//                .build();
//        UserDetails manager= User.builder()
//                .username("manager")
//                .password("{noop}pwd")
//                .roles("MANAGER","EMPLOYEE","VIEWER")
//                .build();
//        UserDetails employee= User.builder()
//                .username("employee")
//                .password("{noop}pwd")
//                .roles("EMPLOYEE","VIEWER")
//                .build();
//        UserDetails viewer= User.builder()
//                .username("viewer")
//                .password("{noop}pwd")
//                .roles("VIEWER")
//                .build();
//
//
//        return new InMemoryUserDetailsManager(superadmin,admin,manager,employee,viewer);
//    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public UserDetailsManager userDetailsManager(DataSource dataSource){

        JdbcUserDetailsManager jdbcUserDetailsManager = new JdbcUserDetailsManager(dataSource);

        jdbcUserDetailsManager.setUsersByUsernameQuery(
                "select username, pwd_hash as password, is_active as enabled " +
                "from users where username = ? and is_deleted = false"
        );
        jdbcUserDetailsManager.setAuthoritiesByUsernameQuery(
                "select u.username, concat('ROLE_', r.rolename) as authority " +
                "from users u join roles r on u.role_id = r.id where u.username = ?"
        );

        return jdbcUserDetailsManager;
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception{

        http.authorizeHttpRequests(configurer->
                configurer.requestMatchers(HttpMethod.GET,"/**").hasAnyRole("SUPERADMIN","ADMIN","MANAGER")
                        .requestMatchers(HttpMethod.POST,"/**").hasAnyRole("SUPERADMIN","ADMIN","MANAGER","EMPLOYEE")
                        .requestMatchers(HttpMethod.PUT,"/**").hasAnyRole("SUPERADMIN","ADMIN","MANAGER")
                        .requestMatchers(HttpMethod.DELETE,"/**").hasAnyRole("SUPERADMIN","ADMIN")
                        .requestMatchers(HttpMethod.GET,"/SpecificUserName/**").hasAnyRole("EMPLOYEE","VIEWER")
                        .requestMatchers(HttpMethod.PATCH,"/**").hasAnyRole("SUPERADMIN","ADMIN","MANAGER")

        );
        http.httpBasic(Customizer.withDefaults());
        http.csrf(csrf->csrf.disable());
        return http.build();


    }

}
