package com.example.UserAdministration.repository;

import com.example.UserAdministration.entity.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<Role, Long> {
}
