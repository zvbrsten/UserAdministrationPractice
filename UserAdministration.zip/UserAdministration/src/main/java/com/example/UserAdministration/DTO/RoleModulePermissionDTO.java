//package com.example.UserAdministration.DTO;
//
//
//import com.example.UserAdministration.entity.RoleModulePermission;
//import com.example.UserAdministration.entity.User;
//import com.fasterxml.jackson.annotation.JsonInclude;
//import lombok.Data;
//import lombok.Getter;
//import lombok.Setter;
//
//@Data
//@Setter
//@Getter
//@JsonInclude(JsonInclude.Include.NON_NULL)
//public class RoleModulePermissionDTO {
//
//    private String rolemodulepermissionName;
//
//    public RoleModulePermissionDTO(RoleModulePermission roleModulePermission) {
//
//        this.roleName = roleModulePermission.getRole();
//    }
//}
