package com.example.UserAdministration.repository;

import com.example.UserAdministration.entity.Role;
import com.example.UserAdministration.entity.RoleModulePermission;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleModulePermissionRepository extends JpaRepository<RoleModulePermission, Long> {
}
