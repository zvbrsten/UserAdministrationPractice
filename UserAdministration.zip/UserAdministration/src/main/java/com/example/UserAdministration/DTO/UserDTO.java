package com.example.UserAdministration.DTO;


import com.example.UserAdministration.entity.User;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserDTO {

    private String userName;

    private String firstName;

   private String lastName;

    private String email;

    private String phone;

    private String password;

    private String dob;
    private Long roleId;
    private String roleName;

    public UserDTO(String userName, String firstName, String lastName, String email, String phone, String password, String dob, Long roleId) {
        this.userName = userName;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.phone = phone;
        this.password = password;
        this.dob = dob;
        this.roleId = roleId;
    }

    public UserDTO(){}

    public UserDTO(User user) {
        this.userName = user.getUserName();
        this.firstName = user.getFirstName();
        this.lastName = user.getLastName();
        this.email = user.getEmail();
        this.phone = user.getPhone();
        this.dob = user.getDob();
        this.roleName = user.getRole().getRoleName();
    }


}
