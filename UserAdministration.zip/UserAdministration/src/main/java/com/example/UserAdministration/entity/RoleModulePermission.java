package com.example.UserAdministration.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "roles_modules_permissions")
public class RoleModulePermission {
    
    @EmbeddedId
    private RoleModulePermissionId id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "rid", nullable = false, insertable = false, updatable = false)
    private Role role;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "mid", nullable = false, insertable = false, updatable = false)
    private Module module;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "pid", nullable = false, insertable = false, updatable = false)
    private Permission permission;
    
    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;
    
    public RoleModulePermission() {}
    
    public RoleModulePermission(Long rid, Long mid, Long pid) {
        this.id = new RoleModulePermissionId(rid, mid, pid);
    }

    public RoleModulePermission(long rid, long mid, long pid) {
        this.id = new RoleModulePermissionId(rid, mid, pid);
    }

    public RoleModulePermission(Role role, Module module, Permission permission) {
        this.role = role;
        this.module = module;
        this.permission = permission;
        this.id = new RoleModulePermissionId(role.getId(), module.getId(), permission.getId());
    }
    
    public RoleModulePermissionId getId() {
        return id;
    }
    
    public void setId(RoleModulePermissionId id) {
        this.id = id;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public Module getModule() {
        return module;
    }

    public void setModule(Module module) {
        this.module = module;
    }

    public Permission getPermission() {
        return permission;
    }

    public void setPermission(Permission permission) {
        this.permission = permission;
    }
    
    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
    
    @PrePersist
    protected void onCreate() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }
    }
}