# Training & Task Management Platform

A production-grade Spring Boot backend for managing trainees, trainers, tasks, and learning topics with JWT-based authentication and role-based access control.

---

## Tech Stack

| Layer | Technology |
|---|---|
| Framework | Spring Boot 3.3.5 |
| Security | Spring Security + JWT (jjwt 0.12.6) |
| Database | PostgreSQL |
| ORM | Spring Data JPA / Hibernate |
| Cache | Caffeine |
| API Docs | SpringDoc OpenAPI (Swagger UI) |
| Monitoring | Spring Boot Actuator |
| Build | Maven |

---

## Setup

### Prerequisites
- Java 17+
- Maven 3.8+
- PostgreSQL running on `localhost:5432`

### Database
```sql
CREATE DATABASE lms;
```

### Environment Variables (optional overrides)
```
DB_USERNAME=postgres
DB_PASSWORD=postgres
JWT_SECRET=<64-char hex string>
```

### Run
```bash
mvn spring-boot:run
```

The app auto-creates schema (`ddl-auto=update`) and seeds:
- Roles: `ADMIN`, `TRAINER`, `TRAINEE`
- Default admin: `admin@lms.com` / `Admin@123`

---

## API Documentation

**Swagger UI:** http://localhost:8080/swagger-ui.html  
**OpenAPI JSON:** http://localhost:8080/api-docs

### Authentication Flow

1. `POST /api/v1/auth/login` → returns JWT token
2. Add `Authorization: Bearer <token>` to all subsequent requests
3. In Swagger UI → click **Authorize** → paste token

---

## API Reference

### Auth
| Method | Endpoint | Access | Description |
|---|---|---|---|
| POST | `/api/v1/auth/login` | Public | Login and get JWT |

### Users
| Method | Endpoint | Access | Description |
|---|---|---|---|
| POST | `/api/v1/users` | ADMIN, TRAINER | Create user |
| GET | `/api/v1/users` | All | Get all users (paginated) |
| GET | `/api/v1/users/{id}` | All | Get user by ID |
| GET | `/api/v1/users/email/{email}` | All | Get user by email |
| PUT | `/api/v1/users/{id}` | ADMIN, TRAINER | Update user |
| DELETE | `/api/v1/users/{id}` | ADMIN | Delete user |
| GET | `/api/v1/users/{userId}/tasks` | All | Get tasks for user |
| GET | `/api/v1/users/filter/pending-tasks` | ADMIN, TRAINER | Users with pending tasks |
| GET | `/api/v1/users/filter/topic/{topicId}` | All | Users enrolled in topic |
| POST | `/api/v1/users/{userId}/topics/{topicId}` | ADMIN, TRAINER | Assign topic to user |
| DELETE | `/api/v1/users/{userId}/topics/{topicId}` | ADMIN, TRAINER | Remove topic from user |
| GET | `/api/v1/users/{userId}/topics` | All | List user's topics |
| POST | `/api/v1/users/{userId}/tasks/{taskId}` | ADMIN, TRAINER | Assign task to user |
| PATCH | `/api/v1/users/{userId}/tasks/{taskId}/progress` | All | Update progress |
| PATCH | `/api/v1/users/{userId}/tasks/{taskId}/complete` | All | Mark task completed |

### Tasks
| Method | Endpoint | Access | Description |
|---|---|---|---|
| POST | `/api/v1/tasks` | ADMIN, TRAINER | Create task |
| GET | `/api/v1/tasks` | All | All tasks (paginated) |
| GET | `/api/v1/tasks/{id}` | All | Get task by ID |
| PUT | `/api/v1/tasks/{id}` | ADMIN, TRAINER | Update task |
| DELETE | `/api/v1/tasks/{id}` | ADMIN, TRAINER | Delete task |
| GET | `/api/v1/tasks/status/{status}` | All | Filter by status |
| GET | `/api/v1/tasks/priority/{priority}` | All | Filter by priority |
| GET | `/api/v1/tasks/overdue` | All | Get overdue tasks |
| GET | `/api/v1/tasks/overdue/user/{userId}` | All | Overdue tasks for user |
| GET | `/api/v1/tasks/user/{userId}` | All | Tasks for specific user |
| GET | `/api/v1/tasks/user/{userId}/status/{status}` | All | Filter user tasks by status |
| GET | `/api/v1/tasks/date-range?from=&to=` | All | Tasks in date range |
| PATCH | `/api/v1/tasks/{taskId}/progress/user/{userId}` | All | Update progress + comments |
| PATCH | `/api/v1/tasks/{taskId}/complete/user/{userId}` | All | Mark completed |
| PATCH | `/api/v1/tasks/{taskId}/comments` | All | Add/update comment |

### Topics
| Method | Endpoint | Access | Description |
|---|---|---|---|
| POST | `/api/v1/topics` | ADMIN, TRAINER | Create topic |
| GET | `/api/v1/topics` | All | List all topics (cached) |
| GET | `/api/v1/topics/{id}` | All | Get topic by ID |
| DELETE | `/api/v1/topics/{id}` | ADMIN | Delete topic |

### Roles
| Method | Endpoint | Access | Description |
|---|---|---|---|
| POST | `/api/v1/roles` | ADMIN | Create role |
| GET | `/api/v1/roles` | All | List all roles |

### Quotes (External API)
| Method | Endpoint | Access | Description |
|---|---|---|---|
| GET | `/api/v1/quotes/daily` | All | Motivational quote from ZenQuotes API |

### Monitoring
| Method | Endpoint | Access | Description |
|---|---|---|---|
| GET | `/actuator/health` | Public | Health status |
| GET | `/actuator/info` | Public | App info |
| GET | `/actuator/metrics` | ADMIN | Metrics |

---

## Roles & Permissions

| Role | Capabilities |
|---|---|
| **ADMIN** | Full access — create/delete users, roles, tasks, topics |
| **TRAINER** | Create/update trainees, create/assign tasks and topics, monitor progress |
| **TRAINEE** | View own tasks, update progress, add comments, mark completed |

---

## Task Status Flow

```
PENDING → IN_PROGRESS → COMPLETED
```
Progress 0 = PENDING, 1-99 = IN_PROGRESS, 100 = COMPLETED (auto-set)

---

## Pagination

Add query params to paginated endpoints:
```
?page=0&size=20&sort=dueDate,asc
```

---

## Database Design

```
roles (id, name)
users (id, first_name, last_name, email, phone, password_hash, joining_date, status, role_id)
tasks (id, title, description, priority, due_date, status, progress, comments, created_at, updated_at, user_id)
topics (id, title)
topic_tasks (id, task_id, topic_id) — unique(task_id, topic_id)
user_topics (id, user_id, topic_id) — unique(user_id, topic_id)
```

---

## Sample Test Data

### Login
```json
POST /api/v1/auth/login
{
  "email": "admin@lms.com",
  "password": "Admin@123"
}
```

### Create Trainer
```json
POST /api/v1/users
{
  "firstName": "John",
  "lastName": "Trainer",
  "email": "trainer@lms.com",
  "phone": "9876543210",
  "password": "Trainer@123",
  "role": "TRAINER"
}
```

### Create Trainee
```json
POST /api/v1/users
{
  "firstName": "Jane",
  "lastName": "Trainee",
  "email": "jane@lms.com",
  "phone": "9123456789",
  "password": "Trainee@123",
  "role": "TRAINEE"
}
```

### Create Topic
```json
POST /api/v1/topics
{
  "title": "Spring Boot"
}
```

### Create Task
```json
POST /api/v1/tasks
{
  "title": "Build CRUD APIs",
  "description": "Implement full CRUD using Spring Data JPA",
  "priority": "HIGH",
  "dueDate": "2026-07-01",
  "email": "jane@lms.com",
  "topicNames": ["Spring Boot"]
}
```

### Update Progress
```json
PATCH /api/v1/tasks/1/progress/user/2
{
  "progress": 50,
  "comments": "Completed GET and POST endpoints"
}
```
