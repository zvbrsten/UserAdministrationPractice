package com.example.learningmanagement.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

import java.util.LinkedHashSet;
import java.util.Set;

@Entity
@Table(name = "topics")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Topic {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Topic title cant be blank")
    @Column(name = "title", nullable = false, unique = true, length = 50)
    private String title;

    // User <-> Topic through UserTopic
    @OneToMany(mappedBy = "topic", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<UserTopic> userTopics = new LinkedHashSet<>();

    // Task <-> Topic through TopicTask
    @OneToMany(mappedBy = "topic", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<TopicTask> topicTasks = new LinkedHashSet<>();
}