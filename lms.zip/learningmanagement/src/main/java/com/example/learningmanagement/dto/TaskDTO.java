package com.example.learningmanagement.dto;

import com.example.learningmanagement.entity.Task;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class TaskDTO {

    private Long taskId;

    @NotBlank(message = "title cant be blank")
    private String title;

    private String description;

    private Long progress;

    private String priority;

    private String status;

    private LocalDate dueDate;

    private String comments;

    private String email;

    private String topicName;

    private LocalDateTime createdAt;

    private LocalDateTime updatedAt;

    private List<String> topicNames;

    public TaskDTO(Task task) {
        this.taskId = task.getId();
        this.title = task.getTitle();
        this.description = task.getDescription();
        this.progress = task.getProgress();
        this.dueDate = task.getDueDate();
        this.priority = task.getPriority();
        this.status = task.getStatus();
        this.comments = task.getComments();
        this.createdAt = task.getCreatedAt();
        this.updatedAt = task.getUpdatedAt();
        if (task.getUser() != null) {
            this.email = task.getUser().getEmail();
        }
        if (task.getTopicTasks() != null) {
            this.topicNames = task.getTopicTasks().stream()
                    .map(tt -> tt.getTopic().getTitle())
                    .toList();
        }
    }
}