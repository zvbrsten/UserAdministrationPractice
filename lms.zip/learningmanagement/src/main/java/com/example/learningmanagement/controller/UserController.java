package com.example.learningmanagement.controller;

import com.example.learningmanagement.dto.TaskDTO;
import com.example.learningmanagement.dto.UserRequestDTO;
import com.example.learningmanagement.dto.UserResponseDTO;
import com.example.learningmanagement.response.ApiResponse;
import com.example.learningmanagement.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/users")
@RequiredArgsConstructor
@Tag(name = "Users", description = "User management, search, topic/task assignment, and progress tracking")
@SecurityRequirement(name = "bearerAuth")
public class UserController {

    private final UserService userService;

    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN','TRAINER')")
    @Operation(summary = "Create a new user (TRAINEE by default)")
    public ResponseEntity<ApiResponse<UserResponseDTO>> createUser(@Valid @RequestBody UserRequestDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("User created successfully", userService.createUser(dto)));
    }

    @GetMapping
    @Operation(summary = "Get all users (paginated)")
    public ResponseEntity<ApiResponse<Page<UserResponseDTO>>> getAllUsers(
            @PageableDefault(size = 20, sort = "id") Pageable pageable) {
        return ResponseEntity.ok(ApiResponse.success("Users retrieved", userService.getAllUsers(pageable)));
    }

    @GetMapping("/search")
    @Operation(summary = "Search and filter trainees by name, status, role",
               description = "All params are optional. Supports partial name match (case-insensitive).")
    public ResponseEntity<ApiResponse<Page<UserResponseDTO>>> searchUsers(
            @Parameter(description = "Partial first or last name") @RequestParam(required = false) String name,
            @Parameter(description = "ACTIVE | INACTIVE | SUSPENDED") @RequestParam(required = false) String status,
            @Parameter(description = "ADMIN | TRAINER | TRAINEE") @RequestParam(required = false) String role,
            @PageableDefault(size = 20, sort = "id") Pageable pageable) {
        return ResponseEntity.ok(ApiResponse.success("Users retrieved",
                userService.searchUsers(name, status, role, pageable)));
    }

    @GetMapping("/filter/status/{status}")
    @Operation(summary = "Filter users by status (ACTIVE, INACTIVE, SUSPENDED)")
    public ResponseEntity<ApiResponse<Page<UserResponseDTO>>> getUsersByStatus(
            @PathVariable String status,
            @PageableDefault(size = 20) Pageable pageable) {
        return ResponseEntity.ok(ApiResponse.success("Users retrieved",
                userService.getUsersByStatus(status, pageable)));
    }

    @GetMapping("/filter/role/{role}")
    @Operation(summary = "Filter users by role (ADMIN, TRAINER, TRAINEE)")
    public ResponseEntity<ApiResponse<Page<UserResponseDTO>>> getUsersByRole(
            @PathVariable String role,
            @PageableDefault(size = 20) Pageable pageable) {
        return ResponseEntity.ok(ApiResponse.success("Users retrieved",
                userService.getUsersByRole(role, pageable)));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get user by ID")
    public ResponseEntity<ApiResponse<UserResponseDTO>> getUserById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success("User retrieved", userService.getUserById(id)));
    }

    @GetMapping("/email/{email}")
    @Operation(summary = "Get user by email")
    public ResponseEntity<ApiResponse<UserResponseDTO>> getUserByEmail(@PathVariable String email) {
        return ResponseEntity.ok(ApiResponse.success("User retrieved", userService.getUserByEmail(email)));
    }

    @GetMapping("/{userId}/tasks")
    @Operation(summary = "Get all tasks assigned to a user")
    public ResponseEntity<ApiResponse<List<TaskDTO>>> getPersonalTasks(@PathVariable Long userId) {
        return ResponseEntity.ok(ApiResponse.success("Tasks retrieved",
                userService.getPersonalTasks(userService.getUserById(userId).getEmail())));
    }

    @GetMapping("/filter/pending-tasks")
    @PreAuthorize("hasAnyRole('ADMIN','TRAINER')")
    @Operation(summary = "Get users grouped by their pending tasks (trainer monitoring view)")
    public ResponseEntity<ApiResponse<Map<String, List<TaskDTO>>>> getUsersByPendingTasks() {
        return ResponseEntity.ok(ApiResponse.success("Retrieved", userService.filterByPendingTask()));
    }

    @GetMapping("/filter/topic/{topicId}")
    @Operation(summary = "Get users enrolled in a specific topic")
    public ResponseEntity<ApiResponse<List<UserResponseDTO>>> getUsersByTopic(@PathVariable Long topicId) {
        return ResponseEntity.ok(ApiResponse.success("Users retrieved", userService.filterByTopic(topicId)));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','TRAINER')")
    @Operation(summary = "Update user profile (name, phone, password)")
    public ResponseEntity<ApiResponse<UserResponseDTO>> updateUser(
            @PathVariable Long id, @Valid @RequestBody UserRequestDTO dto) {
        return ResponseEntity.ok(ApiResponse.success("User updated", userService.updateUser(id, dto)));
    }

    @PatchMapping("/{id}/status")
    @PreAuthorize("hasAnyRole('ADMIN','TRAINER')")
    @Operation(summary = "Update user status (ACTIVE, INACTIVE, SUSPENDED)")
    public ResponseEntity<ApiResponse<UserResponseDTO>> updateStatus(
            @PathVariable Long id,
            @Parameter(description = "ACTIVE | INACTIVE | SUSPENDED") @RequestParam String status) {
        return ResponseEntity.ok(ApiResponse.success("Status updated", userService.updateStatus(id, status)));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Delete a user by ID")
    public ResponseEntity<ApiResponse<Void>> deleteUser(@PathVariable Long id) {
        userService.deleteUser(id);
        return ResponseEntity.ok(ApiResponse.success("User deleted"));
    }

    @PostMapping("/{userId}/topics/{topicId}")
    @PreAuthorize("hasAnyRole('ADMIN','TRAINER')")
    @Operation(summary = "Assign a learning topic to a user")
    public ResponseEntity<ApiResponse<Void>> assignTopic(@PathVariable Long userId, @PathVariable Long topicId) {
        userService.assignTopic(userId, topicId);
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.success("Topic assigned"));
    }

    @DeleteMapping("/{userId}/topics/{topicId}")
    @PreAuthorize("hasAnyRole('ADMIN','TRAINER')")
    @Operation(summary = "Remove a learning topic from a user")
    public ResponseEntity<ApiResponse<Void>> removeTopic(@PathVariable Long userId, @PathVariable Long topicId) {
        userService.removeTopic(userId, topicId);
        return ResponseEntity.ok(ApiResponse.success("Topic removed"));
    }

    @GetMapping("/{userId}/topics")
    @Operation(summary = "List all topics assigned to a user")
    public ResponseEntity<ApiResponse<List<String>>> getUserTopics(@PathVariable Long userId) {
        return ResponseEntity.ok(ApiResponse.success("Topics retrieved", userService.getUserTopics(userId)));
    }

    @PostMapping("/{userId}/tasks/{taskId}")
    @PreAuthorize("hasAnyRole('ADMIN','TRAINER')")
    @Operation(summary = "Assign an existing task to a user")
    public ResponseEntity<ApiResponse<Void>> assignTask(@PathVariable Long userId, @PathVariable Long taskId) {
        userService.assignTask(userId, taskId);
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.success("Task assigned"));
    }

    @PatchMapping("/{userId}/tasks/{taskId}/progress")
    @Operation(summary = "Update task progress percentage (0-100)")
    public ResponseEntity<ApiResponse<Void>> updateTaskProgress(
            @PathVariable Long userId,
            @PathVariable Long taskId,
            @Parameter(description = "Progress value 0–100") @RequestParam Long progress) {
        userService.updateTaskProgress(userId, taskId, progress);
        return ResponseEntity.ok(ApiResponse.success("Progress updated"));
    }

    @PatchMapping("/{userId}/tasks/{taskId}/complete")
    @Operation(summary = "Mark a task as completed")
    public ResponseEntity<ApiResponse<Void>> markTaskCompleted(@PathVariable Long userId, @PathVariable Long taskId) {
        userService.updateTaskAsCompleted(userId, taskId);
        return ResponseEntity.ok(ApiResponse.success("Task marked as completed"));
    }
}