package com.example.learningmanagement.service;

import com.example.learningmanagement.dto.TopicDTO;
import com.example.learningmanagement.entity.Topic;
import com.example.learningmanagement.exception.ConflictException;
import com.example.learningmanagement.exception.ResourceNotFoundException;
import com.example.learningmanagement.repository.TopicRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class TopicService {

    private final TopicRepository topicRepository;

    @CacheEvict(value = "topics", allEntries = true)
    public TopicDTO createTopic(TopicDTO dto) {
        if (topicRepository.existsByTitle(dto.getTitle())) {
            throw new ConflictException("Topic already exists: " + dto.getTitle());
        }
        Topic topic = new Topic();
        topic.setTitle(dto.getTitle());
        log.info("Topic created: {}", dto.getTitle());
        return new TopicDTO(topicRepository.save(topic));
    }

    @Cacheable("topics")
    @Transactional(readOnly = true)
    public List<TopicDTO> getAllTopics() {
        return topicRepository.findAll().stream().map(TopicDTO::new).toList();
    }

    @Transactional(readOnly = true)
    public TopicDTO getTopicById(Long id) {
        return new TopicDTO(topicRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Topic not found: " + id)));
    }

    @CacheEvict(value = "topics", allEntries = true)
    public void deleteTopic(Long id) {
        Topic topic = topicRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Topic not found: " + id));
        topicRepository.delete(topic);
        log.info("Topic deleted: {}", id);
    }
}