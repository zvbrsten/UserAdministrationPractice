package com.example.learningmanagement.service;

import com.example.learningmanagement.dto.TaskDTO;
import com.example.learningmanagement.dto.TaskRequest;
import com.example.learningmanagement.entity.Task;
import com.example.learningmanagement.entity.Topic;
import com.example.learningmanagement.entity.TopicTask;
import com.example.learningmanagement.entity.User;
import com.example.learningmanagement.entity.UserTopic;
import com.example.learningmanagement.exception.BadRequestException;
import com.example.learningmanagement.exception.ConflictException;
import com.example.learningmanagement.exception.ResourceNotFoundException;
import com.example.learningmanagement.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class TaskService {

    private final TaskRepository taskRepository;
    private final UserRepository userRepository;
    private final TopicRepository topicRepository;
    private final TopicTaskRepository topicTaskRepository;
    private final UserTopicRepository userTopicRepository;

    public TaskDTO createTask(TaskRequest req) {
        if (taskRepository.existsByTitle(req.getTitle())) {
            throw new ConflictException("Task already exists with title: " + req.getTitle());
        }

        User user = userRepository.findByEmail(req.getEmail())
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + req.getEmail()));

        Task task = new Task();
        task.setTitle(req.getTitle());
        task.setDescription(req.getDescription());
        task.setPriority(req.getPriority());
        task.setDueDate(req.getDueDate());
        task.setStatus("PENDING");
        task.setProgress(0L);
        task.setUser(user);

        taskRepository.save(task);

        if (req.getTopicNames() != null) {
            for (String topicName : req.getTopicNames()) {
                Topic topic = topicRepository.findByTitle(topicName)
                        .orElseThrow(() -> new ResourceNotFoundException("Topic not found: " + topicName));
                topicTaskRepository.save(new TopicTask(task, topic));
                if (!userTopicRepository.existsByUserIdAndTopicId(user.getId(), topic.getId())) {
                    userTopicRepository.save(new UserTopic(user, topic));
                }
            }
        }

        log.info("Task created: {} assigned to {}", task.getTitle(), req.getEmail());
        return new TaskDTO(taskRepository.findById(task.getId()).orElseThrow());
    }

    public TaskDTO updateTask(Long taskId, TaskRequest req) {
        Task task = findOrThrow(taskId);
        task.setTitle(req.getTitle());
        task.setDescription(req.getDescription());
        task.setPriority(req.getPriority());
        task.setDueDate(req.getDueDate());

        if (req.getEmail() != null) {
            User user = userRepository.findByEmail(req.getEmail())
                    .orElseThrow(() -> new ResourceNotFoundException("User not found: " + req.getEmail()));
            task.setUser(user);
        }

        log.info("Task updated: {}", taskId);
        return new TaskDTO(taskRepository.save(task));
    }

    public void deleteTask(Long taskId) {
        Task task = findOrThrow(taskId);
        taskRepository.delete(task);
        log.info("Task deleted: {}", taskId);
    }

    @Transactional(readOnly = true)
    public TaskDTO getTaskById(Long taskId) {
        return new TaskDTO(findOrThrow(taskId));
    }

    @Transactional(readOnly = true)
    public Page<TaskDTO> getAllTasks(Pageable pageable) {
        return taskRepository.findAll(pageable).map(TaskDTO::new);
    }

    @Transactional(readOnly = true)
    public Page<TaskDTO> getTasksByStatus(String status, Pageable pageable) {
        return taskRepository.findByStatus(status, pageable).map(TaskDTO::new);
    }

    @Transactional(readOnly = true)
    public Page<TaskDTO> getTasksByPriority(String priority, Pageable pageable) {
        return taskRepository.findByPriority(priority, pageable).map(TaskDTO::new);
    }

    @Transactional(readOnly = true)
    public Page<TaskDTO> getTasksByUserId(Long userId, Pageable pageable) {
        return taskRepository.findByUserId(userId, pageable).map(TaskDTO::new);
    }

    @Transactional(readOnly = true)
    public List<TaskDTO> getOverdueTasks() {
        return taskRepository.findOverdueTasks().stream().map(TaskDTO::new).toList();
    }

    @Transactional(readOnly = true)
    public List<TaskDTO> getOverdueTasksByUser(Long userId) {
        return taskRepository.findOverdueTasksByUserId(userId).stream().map(TaskDTO::new).toList();
    }

    @Transactional(readOnly = true)
    public Page<TaskDTO> getTasksByDateRange(LocalDate from, LocalDate to, Pageable pageable) {
        return taskRepository.findByDueDateBetween(from, to, pageable).map(TaskDTO::new);
    }

    @Transactional(readOnly = true)
    public Page<TaskDTO> getTasksByUserAndStatus(Long userId, String status, Pageable pageable) {
        return taskRepository.findByUserIdAndStatus(userId, status, pageable).map(TaskDTO::new);
    }

    public TaskDTO updateProgress(Long taskId, Long userId, Long progress, String comments) {
        if (progress < 0 || progress > 100) {
            throw new BadRequestException("Progress must be between 0 and 100");
        }
        Task task = findOrThrow(taskId);
        if (!task.getUser().getId().equals(userId)) {
            throw new BadRequestException("Task is not assigned to user id: " + userId);
        }
        task.setProgress(progress);
        if (comments != null && !comments.isBlank()) {
            task.setComments(comments);
        }
        if (progress == 100) {
            task.setStatus("COMPLETED");
        } else if (progress > 0) {
            task.setStatus("IN_PROGRESS");
        }
        log.info("Task {} progress updated to {}% by user {}", taskId, progress, userId);
        return new TaskDTO(taskRepository.save(task));
    }

    public TaskDTO markCompleted(Long taskId, Long userId) {
        Task task = findOrThrow(taskId);
        if (!task.getUser().getId().equals(userId)) {
            throw new BadRequestException("Task is not assigned to user id: " + userId);
        }
        task.setProgress(100L);
        task.setStatus("COMPLETED");
        log.info("Task {} marked completed by user {}", taskId, userId);
        return new TaskDTO(taskRepository.save(task));
    }

    public TaskDTO addComment(Long taskId, String comment) {
        Task task = findOrThrow(taskId);
        task.setComments(comment);
        return new TaskDTO(taskRepository.save(task));
    }

    private Task findOrThrow(Long id) {
        return taskRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Task not found with id: " + id));
    }
}