package com.example.learningmanagement.external;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;

import java.util.Map;

@Service
@RequiredArgsConstructor
@Slf4j
public class QuoteService {

    @Value("${quotes.api.url}")
    private String quotesApiUrl;

    private final RestClient.Builder restClientBuilder;

    @Cacheable(value = "quotes", key = "'daily'")
    public Map<String, String> getDailyQuote() {
        try {
            RestClient client = restClientBuilder.build();
            QuoteResponse[] response = client.get()
                    .uri(quotesApiUrl)
                    .retrieve()
                    .body(QuoteResponse[].class);

            if (response != null && response.length > 0) {
                QuoteResponse quote = response[0];
                return Map.of("quote", quote.getQ(), "author", quote.getA());
            }
        } catch (RestClientException e) {
            log.error("Failed to fetch quote from external API: {}", e.getMessage());
        }
        return Map.of("quote", "The secret of getting ahead is getting started.", "author", "Mark Twain");
    }
}
