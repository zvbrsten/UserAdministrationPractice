package com.example.learningmanagement.dto;

import com.example.learningmanagement.entity.Topic;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class TopicDTO {

    private Long topicId;

    @NotBlank(message = "Topic title cant be blank")
    private String title;

    public TopicDTO(Topic topic) {
        this.topicId = topic.getId();
        this.title = topic.getTitle();
    }
}