package com.example.learningmanagement.service;

import com.example.learningmanagement.dto.TaskDTO;
import com.example.learningmanagement.dto.UserRequestDTO;
import com.example.learningmanagement.dto.UserResponseDTO;
import com.example.learningmanagement.entity.*;
import com.example.learningmanagement.exception.BadRequestException;
import com.example.learningmanagement.exception.ConflictException;
import com.example.learningmanagement.exception.ResourceNotFoundException;
import com.example.learningmanagement.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.*;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class UserService {

    private final RoleRepository roleRepository;
    private final TaskRepository taskRepository;
    private final UserRepository userRepository;
    private final TopicRepository topicRepository;
    private final UserTopicRepository userTopicRepository;
    private final PasswordEncoder passwordEncoder;

    public UserResponseDTO createUser(UserRequestDTO dto) {
        if (userRepository.existsByEmail(dto.getEmail())) {
            throw new ConflictException("User already exists with email: " + dto.getEmail());
        }
        if (userRepository.existsByPhone(dto.getPhone())) {
            throw new ConflictException("Phone number already in use: " + dto.getPhone());
        }

        User user = new User();
        user.setFirstName(dto.getFirstName());
        user.setLastName(dto.getLastName());
        user.setEmail(dto.getEmail());
        user.setPhone(dto.getPhone());
        user.setPasswordHash(passwordEncoder.encode(dto.getPassword()));
        user.setJoiningDate(LocalDate.now());
        user.setStatus("ACTIVE");

        String roleName = (dto.getRole() != null && !dto.getRole().isBlank()) ? dto.getRole() : "TRAINEE";
        Role role = roleRepository.findByName(roleName);
        if (role == null) throw new ResourceNotFoundException("Role not found: " + roleName);
        user.setRole(role);

        log.info("Creating user: {}", dto.getEmail());
        return mapToResponse(userRepository.save(user));
    }

    @Transactional(readOnly = true)
    public UserResponseDTO getUserById(Long id) {
        return mapToResponse(findOrThrow(id));
    }

    @Transactional(readOnly = true)
    public UserResponseDTO getUserByEmail(String email) {
        return mapToResponse(userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with email: " + email)));
    }

    @Transactional(readOnly = true)
    public Page<UserResponseDTO> getAllUsers(Pageable pageable) {
        return userRepository.findAll(pageable).map(this::mapToResponse);
    }

    @Transactional(readOnly = true)
    public Page<UserResponseDTO> searchUsers(String name, String status, String role, Pageable pageable) {
        return userRepository.searchUsers(name, status, role, pageable).map(this::mapToResponse);
    }

    @Transactional(readOnly = true)
    public Page<UserResponseDTO> getUsersByStatus(String status, Pageable pageable) {
        return userRepository.findByStatus(status, pageable).map(this::mapToResponse);
    }

    @Transactional(readOnly = true)
    public Page<UserResponseDTO> getUsersByRole(String roleName, Pageable pageable) {
        return userRepository.findByRoleName(roleName, pageable).map(this::mapToResponse);
    }

    public UserResponseDTO updateUser(Long id, UserRequestDTO dto) {
        User user = findOrThrow(id);
        user.setFirstName(dto.getFirstName());
        user.setLastName(dto.getLastName());
        user.setPhone(dto.getPhone());
        if (dto.getPassword() != null && !dto.getPassword().isBlank()) {
            user.setPasswordHash(passwordEncoder.encode(dto.getPassword()));
        }
        log.info("Updated user id={}", id);
        return mapToResponse(userRepository.save(user));
    }

    public UserResponseDTO updateStatus(Long id, String status) {
        List<String> allowed = List.of("ACTIVE", "INACTIVE", "SUSPENDED");
        if (!allowed.contains(status.toUpperCase())) {
            throw new BadRequestException("Status must be one of: " + allowed);
        }
        User user = findOrThrow(id);
        user.setStatus(status.toUpperCase());
        log.info("Updated status of user id={} to {}", id, status);
        return mapToResponse(userRepository.save(user));
    }

    public void deleteUser(Long id) {
        userRepository.delete(findOrThrow(id));
        log.info("Deleted user id={}", id);
    }

    public void assignTopic(Long userId, Long topicId) {
        User user = findOrThrow(userId);
        Topic topic = topicRepository.findById(topicId)
                .orElseThrow(() -> new ResourceNotFoundException("Topic not found: " + topicId));
        if (userTopicRepository.existsByUserIdAndTopicId(userId, topicId)) {
            throw new ConflictException("Topic is already assigned to this user");
        }
        userTopicRepository.save(new UserTopic(user, topic));
        log.info("Assigned topic {} to user {}", topicId, userId);
    }

    public void removeTopic(Long userId, Long topicId) {
        UserTopic ut = userTopicRepository.findByUserIdAndTopicId(userId, topicId)
                .orElseThrow(() -> new ResourceNotFoundException("Topic assignment not found"));
        userTopicRepository.delete(ut);
        log.info("Removed topic {} from user {}", topicId, userId);
    }

    @Transactional(readOnly = true)
    public List<String> getUserTopics(Long userId) {
        if (!userRepository.existsById(userId)) throw new ResourceNotFoundException("User not found: " + userId);
        return userTopicRepository.findAllByUserId(userId).stream().map(ut -> ut.getTopic().getTitle()).toList();
    }

    public void assignTask(Long userId, Long taskId) {
        User user = findOrThrow(userId);
        Task task = taskRepository.findById(taskId)
                .orElseThrow(() -> new ResourceNotFoundException("Task not found: " + taskId));
        if (task.getUser() != null && task.getUser().getId().equals(userId)) {
            throw new ConflictException("Task is already assigned to this user");
        }
        task.setUser(user);
        taskRepository.save(task);
        log.info("Assigned task {} to user {}", taskId, userId);
    }

    public void updateTaskProgress(Long userId, Long taskId, Long progress) {
        if (progress < 0 || progress > 100) throw new BadRequestException("Progress must be 0-100");
        findOrThrow(userId);
        Task task = taskRepository.findById(taskId)
                .orElseThrow(() -> new ResourceNotFoundException("Task not found: " + taskId));
        if (task.getUser() == null || !task.getUser().getId().equals(userId)) {
            throw new BadRequestException("Task not assigned to user: " + userId);
        }
        task.setProgress(progress);
        if (progress == 100) task.setStatus("COMPLETED");
        else if (progress > 0) task.setStatus("IN_PROGRESS");
        taskRepository.save(task);
        log.info("Task {} progress updated to {}% for user {}", taskId, progress, userId);
    }

    public void updateTaskAsCompleted(Long userId, Long taskId) {
        findOrThrow(userId);
        Task task = taskRepository.findById(taskId)
                .orElseThrow(() -> new ResourceNotFoundException("Task not found: " + taskId));
        if (task.getUser() == null || !task.getUser().getId().equals(userId)) {
            throw new BadRequestException("Task not assigned to user: " + userId);
        }
        task.setProgress(100L);
        task.setStatus("COMPLETED");
        taskRepository.save(task);
        log.info("Task {} marked completed for user {}", taskId, userId);
    }

    @Transactional(readOnly = true)
    public List<TaskDTO> getPersonalTasks(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + email))
                .getTasks().stream().map(TaskDTO::new).toList();
    }

    @Transactional(readOnly = true)
    public List<UserResponseDTO> filterByTopic(Long topicId) {
        return userTopicRepository.findAllByTopicId(topicId).stream()
                .map(ut -> mapToResponse(ut.getUser())).toList();
    }

    @Transactional(readOnly = true)
    public Map<String, List<TaskDTO>> filterByPendingTask() {
        Map<String, List<TaskDTO>> map = new HashMap<>();
        taskRepository.findByStatus("PENDING").forEach(task -> {
            String email = task.getUser().getEmail();
            map.computeIfAbsent(email, k -> new ArrayList<>()).add(new TaskDTO(task));
        });
        return map;
    }

    private User findOrThrow(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));
    }

    private UserResponseDTO mapToResponse(User user) {
        return new UserResponseDTO(user);
    }
}