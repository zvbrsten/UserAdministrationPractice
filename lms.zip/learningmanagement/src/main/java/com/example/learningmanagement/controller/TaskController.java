package com.example.learningmanagement.controller;

import com.example.learningmanagement.dto.ProgressUpdateRequest;
import com.example.learningmanagement.dto.TaskDTO;
import com.example.learningmanagement.dto.TaskRequest;
import com.example.learningmanagement.response.ApiResponse;
import com.example.learningmanagement.service.TaskService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/v1/tasks")
@RequiredArgsConstructor
@Tag(name = "Tasks", description = "Task management, assignment, progress tracking, and search")
@SecurityRequirement(name = "bearerAuth")
public class TaskController {

    private final TaskService taskService;

    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN','TRAINER')")
    @Operation(summary = "Create and assign a task to a trainee")
    public ResponseEntity<ApiResponse<TaskDTO>> createTask(@Valid @RequestBody TaskRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Task created successfully", taskService.createTask(req)));
    }

    @GetMapping
    @Operation(summary = "Get all tasks (paginated)")
    public ResponseEntity<ApiResponse<Page<TaskDTO>>> getAllTasks(
            @PageableDefault(size = 20, sort = "id") Pageable pageable) {
        return ResponseEntity.ok(ApiResponse.success("Tasks retrieved", taskService.getAllTasks(pageable)));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get task by ID")
    public ResponseEntity<ApiResponse<TaskDTO>> getTaskById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success("Task retrieved", taskService.getTaskById(id)));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','TRAINER')")
    @Operation(summary = "Update task details")
    public ResponseEntity<ApiResponse<TaskDTO>> updateTask(@PathVariable Long id, @Valid @RequestBody TaskRequest req) {
        return ResponseEntity.ok(ApiResponse.success("Task updated", taskService.updateTask(id, req)));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','TRAINER')")
    @Operation(summary = "Delete a task")
    public ResponseEntity<ApiResponse<Void>> deleteTask(@PathVariable Long id) {
        taskService.deleteTask(id);
        return ResponseEntity.ok(ApiResponse.success("Task deleted"));
    }

    @GetMapping("/status/{status}")
    @Operation(summary = "Search tasks by status (PENDING, IN_PROGRESS, COMPLETED)")
    public ResponseEntity<ApiResponse<Page<TaskDTO>>> getByStatus(
            @PathVariable String status,
            @PageableDefault(size = 20) Pageable pageable) {
        return ResponseEntity.ok(ApiResponse.success("Tasks retrieved", taskService.getTasksByStatus(status, pageable)));
    }

    @GetMapping("/priority/{priority}")
    @Operation(summary = "Search tasks by priority (LOW, MEDIUM, HIGH)")
    public ResponseEntity<ApiResponse<Page<TaskDTO>>> getByPriority(
            @PathVariable String priority,
            @PageableDefault(size = 20) Pageable pageable) {
        return ResponseEntity.ok(ApiResponse.success("Tasks retrieved", taskService.getTasksByPriority(priority, pageable)));
    }

    @GetMapping("/overdue")
    @Operation(summary = "Get all overdue tasks")
    public ResponseEntity<ApiResponse<List<TaskDTO>>> getOverdueTasks() {
        return ResponseEntity.ok(ApiResponse.success("Overdue tasks retrieved", taskService.getOverdueTasks()));
    }

    @GetMapping("/overdue/user/{userId}")
    @Operation(summary = "Get overdue tasks for a specific user")
    public ResponseEntity<ApiResponse<List<TaskDTO>>> getOverdueByUser(@PathVariable Long userId) {
        return ResponseEntity.ok(ApiResponse.success("Overdue tasks retrieved", taskService.getOverdueTasksByUser(userId)));
    }

    @GetMapping("/user/{userId}")
    @Operation(summary = "Find tasks assigned to a specific trainee")
    public ResponseEntity<ApiResponse<Page<TaskDTO>>> getTasksByUser(
            @PathVariable Long userId,
            @PageableDefault(size = 20) Pageable pageable) {
        return ResponseEntity.ok(ApiResponse.success("Tasks retrieved", taskService.getTasksByUserId(userId, pageable)));
    }

    @GetMapping("/user/{userId}/status/{status}")
    @Operation(summary = "Get tasks by user filtered by status")
    public ResponseEntity<ApiResponse<Page<TaskDTO>>> getTasksByUserAndStatus(
            @PathVariable Long userId,
            @PathVariable String status,
            @PageableDefault(size = 20) Pageable pageable) {
        return ResponseEntity.ok(ApiResponse.success("Tasks retrieved",
                taskService.getTasksByUserAndStatus(userId, status, pageable)));
    }

    @GetMapping("/date-range")
    @Operation(summary = "Search tasks by due date range")
    public ResponseEntity<ApiResponse<Page<TaskDTO>>> getByDateRange(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to,
            @PageableDefault(size = 20) Pageable pageable) {
        return ResponseEntity.ok(ApiResponse.success("Tasks retrieved", taskService.getTasksByDateRange(from, to, pageable)));
    }

    @PatchMapping("/{taskId}/progress/user/{userId}")
    @Operation(summary = "Update progress and add remarks for a task (trainee)")
    public ResponseEntity<ApiResponse<TaskDTO>> updateProgress(
            @PathVariable Long taskId,
            @PathVariable Long userId,
            @Valid @RequestBody ProgressUpdateRequest req) {
        TaskDTO result = taskService.updateProgress(taskId, userId, req.getProgress(), req.getComments());
        return ResponseEntity.ok(ApiResponse.success("Progress updated", result));
    }

    @PatchMapping("/{taskId}/complete/user/{userId}")
    @Operation(summary = "Mark a task as completed")
    public ResponseEntity<ApiResponse<TaskDTO>> markCompleted(
            @PathVariable Long taskId,
            @PathVariable Long userId) {
        return ResponseEntity.ok(ApiResponse.success("Task marked as completed", taskService.markCompleted(taskId, userId)));
    }

    @PatchMapping("/{taskId}/comments")
    @Operation(summary = "Add or update comments/remarks on a task")
    public ResponseEntity<ApiResponse<TaskDTO>> addComment(
            @PathVariable Long taskId,
            @RequestParam String comment) {
        return ResponseEntity.ok(ApiResponse.success("Comment added", taskService.addComment(taskId, comment)));
    }
}