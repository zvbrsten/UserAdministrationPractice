package com.example.learningmanagement.controller;

import com.example.learningmanagement.dto.TopicDTO;
import com.example.learningmanagement.response.ApiResponse;
import com.example.learningmanagement.service.TopicService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/topics")
@RequiredArgsConstructor
@Tag(name = "Topics", description = "Learning topic management")
@SecurityRequirement(name = "bearerAuth")
public class TopicController {

    private final TopicService topicService;

    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN','TRAINER')")
    @Operation(summary = "Create a new learning topic")
    public ResponseEntity<ApiResponse<TopicDTO>> createTopic(@Valid @RequestBody TopicDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Topic created successfully", topicService.createTopic(dto)));
    }

    @GetMapping
    @Operation(summary = "Get all learning topics")
    public ResponseEntity<ApiResponse<List<TopicDTO>>> getAllTopics() {
        return ResponseEntity.ok(ApiResponse.success("Topics retrieved", topicService.getAllTopics()));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get topic by ID")
    public ResponseEntity<ApiResponse<TopicDTO>> getTopicById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success("Topic retrieved", topicService.getTopicById(id)));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Delete a topic")
    public ResponseEntity<ApiResponse<Void>> deleteTopic(@PathVariable Long id) {
        topicService.deleteTopic(id);
        return ResponseEntity.ok(ApiResponse.success("Topic deleted"));
    }
}