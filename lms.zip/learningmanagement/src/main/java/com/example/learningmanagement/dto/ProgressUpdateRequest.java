package com.example.learningmanagement.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProgressUpdateRequest {

    @Min(0)
    @Max(100)
    private Long progress;

    private String comments;
}
