package com.example.learningmanagement.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

import java.time.LocalDate;
import java.util.LinkedHashSet;
import java.util.Set;

@Entity
@Table(name = "users")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "firstname cant be blank")
    @Column(name = "firstname", nullable = false, length = 50)
    private String firstName;

    @NotBlank(message = "lastname cant be blank")
    @Column(name = "lastname", nullable = false, length = 50)
    private String lastName;

    @Email(message = "Enter valid emailID")
    @Column(name = "email", unique = true, nullable = false, length = 150)
    private String email;

    @NotBlank
    @Size(min = 10, max = 10)
    @Pattern(regexp = "^[0-9]+$")
    @Column(name = "phone", unique = true, nullable = false, length = 10)
    private String phone;

    @NotNull
    @Size(max = 500)
    @Column(name = "password_hash", nullable = false, length = 500)
    private String passwordHash;

    @PastOrPresent
    @Column(name = "joining_date", updatable = false)
    private LocalDate joiningDate;

    @ManyToOne
    @JoinColumn(name = "role_id")
    private Role role;

    @Column(name = "status")
    private String status;

    // One User -> Many Tasks
    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<Task> tasks = new LinkedHashSet<>();

    // User <-> Topic through UserTopic
    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<UserTopic> userTopics = new LinkedHashSet<>();
}