package com.example.learningmanagement.controller;

import com.example.learningmanagement.external.QuoteService;
import com.example.learningmanagement.response.ApiResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api/v1/quotes")
@RequiredArgsConstructor
@Tag(name = "Quotes", description = "Motivational quotes from ZenQuotes external API")
@SecurityRequirement(name = "bearerAuth")
public class QuoteController {

    private final QuoteService quoteService;

    @GetMapping("/daily")
    @Operation(summary = "Get a daily motivational quote", description = "Fetches a random motivational quote from the ZenQuotes public API (cached for 10 minutes)")
    public ResponseEntity<ApiResponse<Map<String, String>>> getDailyQuote() {
        return ResponseEntity.ok(ApiResponse.success("Quote retrieved", quoteService.getDailyQuote()));
    }
}
