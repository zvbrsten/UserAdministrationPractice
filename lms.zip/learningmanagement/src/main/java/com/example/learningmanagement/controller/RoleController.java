package com.example.learningmanagement.controller;

import com.example.learningmanagement.entity.Role;
import com.example.learningmanagement.exception.ConflictException;
import com.example.learningmanagement.repository.RoleRepository;
import com.example.learningmanagement.response.ApiResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/roles")
@RequiredArgsConstructor
@Tag(name = "Roles", description = "Role management (Admin only)")
@SecurityRequirement(name = "bearerAuth")
public class RoleController {

    private final RoleRepository roleRepository;

    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Create a new role")
    public ResponseEntity<ApiResponse<String>> createRole(@RequestBody Role role) {
        if (roleRepository.findByName(role.getName()) != null) {
            throw new ConflictException("Role already exists: " + role.getName());
        }
        roleRepository.save(role);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Role created", role.getName()));
    }

    @GetMapping
    @Operation(summary = "List all roles")
    public ResponseEntity<ApiResponse<List<Role>>> getAllRoles() {
        return ResponseEntity.ok(ApiResponse.success("Roles retrieved", roleRepository.findAll()));
    }
}