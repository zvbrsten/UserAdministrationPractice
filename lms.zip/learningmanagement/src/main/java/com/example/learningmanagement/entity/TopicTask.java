package com.example.learningmanagement.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

@Entity
@Table(
        name = "topic_tasks",
        uniqueConstraints = {
                @UniqueConstraint(columnNames = {"task_id", "topic_id"})
        }
)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class TopicTask {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Many TopicTask rows belong to one Task
    @NotNull
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "task_id", nullable = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    private Task task;

    // Many TopicTask rows belong to one Topic
    @NotNull
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "topic_id", nullable = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    private Topic topic;

    public TopicTask(Task task, Topic topic) {
        this.task=task;
        this.topic=topic;
    }
}