package com.example.learningmanagement.repository;


import com.example.learningmanagement.entity.Topic;


import jakarta.validation.constraints.NotBlank;
import org.springframework.cache.annotation.Cacheable;

import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;

import java.util.Optional;


public interface TopicRepository extends JpaRepository<Topic,Long> {


    boolean existsByTitle(@NotBlank(message = "title cant be blank") String title);
    Optional<Topic> findByTitle(String title);
}
