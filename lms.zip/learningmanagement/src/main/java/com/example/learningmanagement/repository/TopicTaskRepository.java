package com.example.learningmanagement.repository;

import com.example.learningmanagement.entity.TopicTask;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TopicTaskRepository extends JpaRepository<TopicTask,Long> {
}
