package com.example.learningmanagement.config;

import com.example.learningmanagement.entity.Role;
import com.example.learningmanagement.entity.User;
import com.example.learningmanagement.repository.RoleRepository;
import com.example.learningmanagement.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.time.LocalDate;
import java.util.List;

@Configuration
@RequiredArgsConstructor
@Slf4j
public class DataInitializer {

    private final RoleRepository roleRepository;
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Bean
    public CommandLineRunner seedData() {
        return args -> {
            seedRoles();
            seedAdminUser();
        };
    }

    private void seedRoles() {
        List<String> roles = List.of("ADMIN", "TRAINER", "TRAINEE");
        for (String name : roles) {
            if (roleRepository.findByName(name) == null) {
                roleRepository.save(new Role(name));
                log.info("Seeded role: {}", name);
            }
        }
    }

    private void seedAdminUser() {
        if (userRepository.existsByEmail("admin@lms.com")) return;

        Role adminRole = roleRepository.findByName("ADMIN");
        User admin = new User();
        admin.setFirstName("System");
        admin.setLastName("Admin");
        admin.setEmail("admin@lms.com");
        admin.setPhone("9999999999");
        admin.setPasswordHash(passwordEncoder.encode("Admin@123"));
        admin.setJoiningDate(LocalDate.now());
        admin.setStatus("ACTIVE");
        admin.setRole(adminRole);
        userRepository.save(admin);
        log.info("Seeded admin user: admin@lms.com / Admin@123");
    }
}
