package com.example.learningmanagement.service;

import com.example.learningmanagement.repository.TaskRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;

@Service
@RequiredArgsConstructor
@Slf4j
public class OverdueTaskScheduler {

    private final TaskRepository taskRepository;

    @Scheduled(cron = "0 0 1 * * *")
    @Transactional
    public void flagOverdueTasks() {
        int updated = taskRepository.markTasksAsOverdue(LocalDate.now());
        log.info("Overdue task check: flagged {} tasks as OVERDUE", updated);
    }
}
