package com.example.learningmanagement.controller;

import com.example.learningmanagement.dto.LoginRequest;
import com.example.learningmanagement.dto.LoginResponse;
import com.example.learningmanagement.entity.User;
import com.example.learningmanagement.repository.UserRepository;
import com.example.learningmanagement.response.ApiResponse;
import com.example.learningmanagement.security.JwtService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/auth")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Authentication", description = "Login and token management")
public class AuthController {

    private final AuthenticationManager authenticationManager;
    private final JwtService jwtService;
    private final UserRepository userRepository;

    @PostMapping("/login")
    @Operation(summary = "Login", description = "Authenticate with email/password and receive a JWT token")
    public ResponseEntity<ApiResponse<LoginResponse>> login(@Valid @RequestBody LoginRequest request) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword())
        );

        UserDetails userDetails = (UserDetails) authentication.getPrincipal();
        String token = jwtService.generateToken(userDetails);

        User user = userRepository.findByEmail(request.getEmail()).orElseThrow();
        String role = user.getRole() != null ? user.getRole().getName() : "TRAINEE";

        LoginResponse response = new LoginResponse(token, user.getEmail(), role, user.getFirstName(), user.getLastName());
        log.info("User logged in: {}", request.getEmail());
        return ResponseEntity.ok(ApiResponse.success("Login successful", response));
    }
}
