package com.example.learningmanagement.repository;

import com.example.learningmanagement.entity.Task;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;

public interface TaskRepository extends JpaRepository<Task, Long> {

    boolean existsByTitle(String title);

    List<Task> findByStatus(String status);

    Page<Task> findByStatus(String status, Pageable pageable);

    Page<Task> findByPriority(String priority, Pageable pageable);

    Page<Task> findByUserId(Long userId, Pageable pageable);

    List<Task> findByUserId(Long userId);

    @Query("SELECT t FROM Task t WHERE t.dueDate < :today AND t.status NOT IN ('COMPLETED','OVERDUE')")
    List<Task> findOverdueTasks(@Param("today") LocalDate today);

    @Query("SELECT t FROM Task t WHERE t.dueDate < CURRENT_DATE AND t.status NOT IN ('COMPLETED','OVERDUE')")
    List<Task> findOverdueTasks();

    @Query("SELECT t FROM Task t WHERE t.dueDate < CURRENT_DATE AND t.status NOT IN ('COMPLETED','OVERDUE')")
    Page<Task> findOverdueTasks(Pageable pageable);

    @Query("SELECT t FROM Task t WHERE t.user.id = :userId AND t.dueDate < CURRENT_DATE AND t.status NOT IN ('COMPLETED','OVERDUE')")
    List<Task> findOverdueTasksByUserId(@Param("userId") Long userId);

    Page<Task> findByDueDateBetween(LocalDate from, LocalDate to, Pageable pageable);

    @Query("SELECT t FROM Task t WHERE t.user.id = :userId AND (:status IS NULL OR t.status = :status)")
    Page<Task> findByUserIdAndStatus(@Param("userId") Long userId, @Param("status") String status, Pageable pageable);

    @Modifying
    @Query("UPDATE Task t SET t.status = 'OVERDUE' WHERE t.dueDate < :today AND t.status NOT IN ('COMPLETED','OVERDUE')")
    int markTasksAsOverdue(@Param("today") LocalDate today);
}
