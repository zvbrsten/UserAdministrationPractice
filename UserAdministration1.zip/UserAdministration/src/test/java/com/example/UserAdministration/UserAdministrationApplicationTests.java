package com.example.UserAdministration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserAdministrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
