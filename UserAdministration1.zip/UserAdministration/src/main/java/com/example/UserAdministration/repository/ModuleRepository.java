package com.example.UserAdministration.repository;

import com.example.UserAdministration.entity.Module;
import com.example.UserAdministration.entity.Role;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ModuleRepository extends JpaRepository<Module, Long> {
    List<Module> findBymoduleName(String moduleName);
}