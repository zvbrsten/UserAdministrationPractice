package com.example.UserAdministration.repository;

import com.example.UserAdministration.entity.Role;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface RoleRepository extends JpaRepository<Role, Long> {
    List<Role> findByroleName(String roleName);
}
