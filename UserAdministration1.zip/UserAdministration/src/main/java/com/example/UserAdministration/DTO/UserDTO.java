package com.example.UserAdministration.DTO;


import com.example.UserAdministration.entity.User;
import com.example.UserAdministration.repository.*;
import com.example.UserAdministration.DTO.RoleDTO;
import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserDTO {

    @NotBlank(message = "Username cannot be empty")
    @Size(min=2,max=30,message = "Username must be less than 30 characters")
    private String userName;

    @NotBlank(message = "Username cannot be empty")
    @Size(max=30,message = "Username must be less than 30 characters")
    private String firstName;

    @NotBlank(message = "Username cannot be empty")
    @Size(max=30,message = "Username must be less than 30 characters")
    private String lastName;

    @NotBlank(message = "Username cannot be empty")
    @Email(message="Invalid email address")
    private String email;

    @NotBlank(message = "Phone Number cant be empty")
    @Size(min=10, max =13,message = "Enter valid phone number")
    private String phone;


    private String password;

    @Pattern(regexp="^(19|20)\\d\\d[\\/\\-.](?:(?:(0[13578]|1[02])[\\/\\-.](0[1-9]|[12]\\d|3[01]))|(?:(0[469]|11)[\\/\\-.](0[1-9]|[12]\\d|30))|(?:02[\\/\\-.](0[1-9]|[12]\\d)))$")
    private String dob;
    private Long roleId;
    private String roleName;

    public UserDTO(String userName, String firstName, String lastName, String email, String phone, String password, String dob, Long roleId) {
        this.userName = userName;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.phone = phone;
        this.password = password;
        this.dob = dob;
        this.roleId = roleId;
    }

    public UserDTO(){}

    public UserDTO(User user) {
        this.userName = user.getUserName();
        this.firstName = user.getFirstName();
        this.lastName = user.getLastName();
        this.email = user.getEmail();
        this.phone = user.getPhone();
        this.dob = user.getDob();


        this.roleName = user.getRole().getRoleName();
    }

    public String getPassword() {
        return password;
    }
}
