package com.example.UserAdministration.rest;

public class NotFound extends RuntimeException {
    public NotFound(String message) {
        super(message);
    }
}
