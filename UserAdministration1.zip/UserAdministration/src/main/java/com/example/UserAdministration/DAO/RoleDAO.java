package com.example.UserAdministration.DAO;


import com.example.UserAdministration.entity.Role;

public interface RoleDAO {



    
    
    void save(Role theRole);

}
