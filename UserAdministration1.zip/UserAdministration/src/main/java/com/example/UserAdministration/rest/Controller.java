package com.example.UserAdministration.rest;

import com.example.UserAdministration.DAO.PermissionDAO;
import com.example.UserAdministration.DAO.UserDAO;
import com.example.UserAdministration.DTO.*;
import com.example.UserAdministration.entity.Module;
import com.example.UserAdministration.entity.*;
import com.example.UserAdministration.repository.*;
import com.example.UserAdministration.service.EmailService;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api")
public class Controller {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private ModuleRepository moduleRepository;

    @Autowired
    private PermissionRepository permissionRepository;

    @Autowired
    private RoleModulePermissionRepository roleModulePermissionRepository;

    private final PasswordEncoder passwordEncoder;

    @Autowired
    private EmailService emailService;

    @ExceptionHandler
    public ResponseEntity<NotFoundErrorResponse> handleException(NotFound exc) {
        NotFoundErrorResponse error = new NotFoundErrorResponse();
        error.setStatus(HttpStatus.NOT_FOUND.value());
        error.setMsg("Object Not Found");
        error.setTimeStamp(System.currentTimeMillis());
        return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
    }

    @PersistenceContext
    private EntityManager entityManager;
    

    private final UserDAO userDAO;
    private final PermissionDAO permissionDAO;
    public Controller(UserDAO userDAO,PermissionDAO permissionDAO,PasswordEncoder passwordEncoder){
        this.userDAO=userDAO;
        this.permissionDAO=permissionDAO;
        this.passwordEncoder=passwordEncoder;
    }

    






    public List<User> getUsers() {
//        System.out.println("Getting Users");
//        TypedQuery<User> theQuery = entityManager.createQuery("select u from User u", User.class);
//        List<User> users = theQuery.getResultList();
//        return users;
        List<User> userOptional= this.userRepository.findAll();
        return userOptional;

    }

    public List<Role> getRoles(){
        List<Role> roleOptional=this.roleRepository.findAll();
        return roleOptional;
    }
    public List<Module> getModules(){
        List<Module> moduleOptional=this.moduleRepository.findAll();
        return moduleOptional;
    }
    public List<Permission> getPermissions(){
        List<Permission> permissionOptional=this.permissionRepository.findAll();
        return permissionOptional;
    }

    public List<RoleModulePermission> getRoleModulePermission(){

        List<RoleModulePermission> roleModulePermissionList=this.roleModulePermissionRepository.findAll();
        return roleModulePermissionList;
    }


    @GetMapping("/users")
    public List<UserDTO> userDetails() {

        List<User> users = getUsers();
        return users.stream().map(user -> new UserDTO(user)).toList();

    }
    @GetMapping("/SpecificUserName/{userName}")
    public List<UserDTO> specificUserNameDetails(@PathVariable String userName) {

        List<User> users = getUsers();
        List<UserDTO> list= users.stream().filter(user->user.getUserName().equals(userName)).map(user -> new UserDTO(user)).toList();
        System.out.println(list.size());
        return list;

    }
    @GetMapping("/SpecificFirstName/{firstName}")
    public List<UserDTO> specificFirstNameDetails(@PathVariable String firstName) {

        List<User> users = getUsers();
        List<UserDTO> list= users.stream().filter(user->user.getFirstName().equals(firstName)).map(user -> new UserDTO(user)).toList();
        System.out.println(list.size());
        return list;

    }

    @GetMapping("/Roles")
    public List<RoleDTO> roleDetails() {

        List<Role> roles = getRoles();
        return roles.stream().map(role -> new RoleDTO(role)).toList();

    }
    @GetMapping("/UsersUnderRoles/{roleName}")
    public List<UserDTO> userUnderRoleDetails(@PathVariable String roleName) {

        List<User> users = getUsers();
        List<UserDTO> userdtos=new ArrayList<>();
        users.forEach(user -> userdtos.add(new UserDTO(user)));
        return userdtos.stream().filter(user->user.getRoleName().equals(roleName)).toList();


    }

    @GetMapping("/RMPs")
    public List<RoleModulePermissionDTO> rmp(){

        List<RoleModulePermission> roleModulePermissionsList=getRoleModulePermission();
        List<RoleModulePermissionDTO> rmpDTOs=new ArrayList<>();
        roleModulePermissionsList.forEach(rmp->rmpDTOs.add(new RoleModulePermissionDTO(rmp)));

        return rmpDTOs.stream().toList();
    }

    @GetMapping("/Modules")
    public List<ModuleDTO> moduleDetails() {

        List<Module> modules = getModules();
        return modules.stream().map(module -> new ModuleDTO(module)).toList();

    }
    @GetMapping("/Permissions")
    public List<PermissionDTO> permissionDetails() {

        List<Permission> permissions = getPermissions();
        return permissions.stream().map(permission -> new PermissionDTO(permission)).toList();

    }

    @GetMapping("/UserRoles/{userName}")

    public ResponseEntity<List<String>> userRoleDetails(@PathVariable String userName) {

        List<User> users = getUsers();
        List<UserDTO> userDTOs= new ArrayList<>();
        users.forEach(user->{userDTOs.add(new UserDTO(user));});
        List<String> tempusers=userDTOs.stream().filter(user->user.getUserName().equals(userName)).
                map(user->user.getRoleName()).toList();

            if (tempusers.size() == 0) {
                throw new RuntimeException("Not fouddnd");
            }


        return ResponseEntity.ok(tempusers);

    }

//    @GetMapping("/SpecificUser/{userName}")
//    public String getSpecificUser(@PathVariable String userName) {
//
//        // try {
//        //
//        // User temp = entityManager.find(User.class, );
//        // return temp.getDob();
//        // }
//        // catch (Exception NotFound){
//        // throw new NotFound("not found");
//        // }
//
//    }



//    @GetMapping("RMP")
//    public List<RoleModulePermission> getRMP() {
//        TypedQuery<RoleModulePermission> theQuery = entityManager
//                .createQuery("select rmp from RoleModulePermission rmp", RoleModulePermission.class);
//        List<RoleModulePermission> rmp = theQuery.getResultList();
//        return rmp;
//    }

    @PostMapping("User")
    public ResponseEntity<String> addUser(@RequestBody @Valid UserDTO userDTO) {
        User user= new User();
        user.setFirstName(userDTO.getFirstName());
        user.setDob(userDTO.getDob());
        user.setUserName(userDTO.getUserName());
        user.setDob(userDTO.getDob());
        user.setCreatedAt(LocalDateTime.now());
        user.setUpdatedAt(LocalDateTime.now());
        user.setLastName(userDTO.getLastName());
        user.setPassword(passwordEncoder.encode(userDTO.getPassword()));
        user.setIsActive(true);
        user.setIsDeleted(false);
        user.setPhone(userDTO.getPhone());
        user.setEmail(userDTO.getEmail());
        Optional<Role> roleOptional= this.roleRepository.findById(userDTO.getRoleId());
        if(!roleOptional.isPresent()){
            throw new RuntimeException("Invalid role id");
        }
        user.setRole(roleOptional.get());
        this.userRepository.save(user);
//        userDAO.save(user);
        return ResponseEntity.status(HttpStatus.CREATED).body("User created successfully");
    }

    @PostMapping("Permission")
    public ResponseEntity<String> addPermission(@RequestBody PermissionDTO permissionDTO) {

        Permission permission= new Permission();
        permission.setPermissionName(permissionDTO.getPermissionName());
        permission.setCreatedAt(LocalDateTime.now());
        permission.setUpdatedAt(LocalDateTime.now());


        this.permissionRepository.save(permission);
        return ResponseEntity.status(HttpStatus.CREATED).body("Permission created successfully");
    }

    @PostMapping("Module")
    public ResponseEntity<String> addModule(@RequestBody ModuleDTO moduleDTO){

        Module module = new Module();
        module.setModulesName(moduleDTO.getModuleName());
        module.setCreatedAt(LocalDateTime.now());
        module.setUpdatedAt(LocalDateTime.now());

        this.moduleRepository.save(module);
        return ResponseEntity.status(HttpStatus.CREATED).body("Module created Successfully");
    }

    @PostMapping("Role")
    public ResponseEntity<String> addRole(@RequestBody RoleDTO roleDTO){

        Role role=new Role();
        role.setRoleName(roleDTO.getRoleName());

        this.roleRepository.save(role);
        return ResponseEntity.status(HttpStatus.CREATED).body("Role created successfully");
    }

    @PostMapping("/sendMail")
    public String sendMail(@RequestBody EmailDetails emailDetails) {

        return emailService.sendSimpleEmail(emailDetails);
    }

    @PutMapping("Role/{roleName}")
    public Role updateRole(@RequestBody RoleDTO roleDTO,@PathVariable String roleName){
        List<Role> roles = getRoles();
        System.out.println(roleDTO.getRoleName());


            Role role = roles.stream()
                    .filter(x -> x.getRoleName().equals(roleName))
                    .findFirst()
                    .orElseThrow(() -> new RuntimeException("Role not found |||| Cant update"));

            // Update the existing role (not a new one)
            role.setRoleName(roleDTO.getRoleName());
            this.roleRepository.save(role);

            return role;


    }

    @PutMapping("User/{userName}")
    public User updateUserName(@RequestBody UserDTO userDTO,@PathVariable String userName){
        List<User> users = getUsers();
        System.out.println(userDTO.getUserName());

        User user = users.stream()
                .filter(x -> x.getUserName().equals(userName))
                .findFirst()
                .orElseThrow(() -> new RuntimeException("User not found |||| Cant update"));

        // Update the existing role (not a new one)
        user.setUserName(userDTO.getUserName());
        this.userRepository.save(user);

        return user;
    }
    @PatchMapping("/User/reset-password/{userName}")
    public User resetPassword(@PathVariable String userName, @RequestBody ResetPasswordDTO resetPasswordDTO) {

        List<User> users = getUsers();

        User user = users.stream()
                .filter(x -> x.getUserName().equals(userName))
                .findFirst()
                .orElseThrow(() -> new RuntimeException("User not found"));

        // Validate new password (add your validation rules)
        if (resetPasswordDTO.getNewPassword() == null || resetPasswordDTO.getNewPassword().isEmpty()) {
            throw new RuntimeException("Password cannot be empty");
        }

        // Update password
        user.setPassword(passwordEncoder.encode(resetPasswordDTO.getNewPassword()));
        userRepository.save(user);

        return user;
    }
    @PostMapping("RMP")
    public RoleModulePermission createRoleModulePermission(@RequestBody RoleModulePermissionDTO roleModulePermissionDTO) {
        RoleModulePermission roleModulePermission=new RoleModulePermission(roleRepository.findByroleName(roleModulePermissionDTO.getRoleName()).get(0),moduleRepository.findBymoduleName(roleModulePermissionDTO.getModulesName()).get(0),permissionRepository.findBypermissionName(roleModulePermissionDTO.getPermissionName()).get(0));
        this.roleModulePermissionRepository.save(roleModulePermission);
        return roleModulePermission;


    }

    @DeleteMapping ("Role/{roleName}")
    public Role deleteRole(@RequestBody RoleDTO roleDTO,@PathVariable String roleName){
        List<Role> roles = getRoles();
        System.out.println(roleDTO.getRoleName());

        Role role = roles.stream()
                .filter(x -> x.getRoleName().equals(roleName))
                .findFirst()
                .orElseThrow(() -> new RuntimeException("Role not found |||| Cant delete"));


        this.roleRepository.delete(role);

        return role;
    }

    @DeleteMapping("User/{userName}")
    public User deleteUser(@RequestBody UserDTO userDTO,@PathVariable String userName){
        List<User> users=getUsers();

        User user= users.stream()
                .filter(x->x.getUserName().equals(userName))
                .findFirst()
                .orElseThrow(()->new RuntimeException("User not found || Cant delete"));

        this.userRepository.delete(user);
        return user;
    }








}