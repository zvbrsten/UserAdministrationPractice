package com.example.UserAdministration.DAO;

//import org.springframework.beans.factory.annotation.Autowired;
import com.example.UserAdministration.entity.Module;
import org.springframework.stereotype.Service;

import jakarta.persistence.*;
import jakarta.transaction.Transactional;


@Service
public class ModuleDAOImplementation implements ModuleDAO {

    @PersistenceContext
    private EntityManager entityManager;


    
    public ModuleDAOImplementation(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    @Override
    @Transactional
    public void save(Module theModule) {
        entityManager.persist(theModule);
    }

}
