package com.example.UserAdministration.service;

import com.example.UserAdministration.entity.EmailDetails;

public interface EmailService {

    String sendSimpleEmail(EmailDetails emailDetails);
}
