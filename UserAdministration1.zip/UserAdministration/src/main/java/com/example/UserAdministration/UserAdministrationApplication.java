package com.example.UserAdministration;

import com.example.UserAdministration.DAO.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.example.UserAdministration.entity.*;
import com.example.UserAdministration.entity.Module;

import java.util.*;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;



@SpringBootApplication
public class UserAdministrationApplication {

    @PersistenceContext
	private EntityManager entityManager;

	public static void main(String[] args) {
		SpringApplication.run(UserAdministrationApplication.class, args);
	}

	

	@Bean
	public CommandLineRunner commandLineRunner(UserDAO userDAO, RoleDAO roleDAO, ModuleDAO moduleDAO, PermissionDAO permissionDAO, RoleModulePermissionDAO roleModulePermissionDAO) {
		return runner -> {
//			  createInitialRole(roleDAO);
//			  createInitialUser(userDAO);
//			  createInitialModules(moduleDAO);
//			  createInitialPermissions(permissionDAO);
//			  createInitialRoleModulePermission(roleModulePermissionDAO);
			getUsers();


	};

		

	}
	public void createInitialUser(UserDAO userDAO) {


			System.out.println("Creating Super User");
			User theUser = new User("Superadmin", "Yash", "Sharma","superadmin@example.com","+919140742404","2004-01-26","$2a$12$8UmEe376JZWE/6IVf3If1efUqOeX7ztavvOgsejaURfbZ0Hg1xcRu",(long)1);

			if(getUsers()==null || getUsers().size()==0) {
				System.out.println("Saving Super User ::: No existing user found");
				userDAO.save(theUser);
			}
			else{
				System.out.println("Saving Super User ::: Existing user found");
			}
			
	}
	public void createInitialRole(RoleDAO roleDAO) {

		// INSERT INTO roles (rolename) VALUES
		// ('Super Admin'),
		// ('Admin'),
		// ('Manager'),
		// ('Employee'),
		// ('Viewer');
		System.out.println("Creating Roles");
		Role superRole = new Role("SUPERADMIN");
		Role adminRole = new Role("ADMIN");
		Role managerRole = new Role("MANAGER");
		Role employeeRole = new Role("EMPLOYEE");
		Role viewerRole = new Role("VIEWER");


		if(!getRoles().contains(superRole))
			roleDAO.save(superRole);
			System.out.println("Created Super Admin Role");
		if(!getRoles().contains(adminRole))
			roleDAO.save(adminRole);
			System.out.println("Created Admin Role");
		if(!getRoles().contains(managerRole))
			roleDAO.save(managerRole);
			System.out.println("Created Manager Role");
		if(!getRoles().contains(employeeRole))
			roleDAO.save(employeeRole);
			System.out.println("Created Employee Role");
		if(!getRoles().contains(viewerRole))
			roleDAO.save(viewerRole);
			System.out.println("Created Viewer Role");

	}

	public void createInitialModules(ModuleDAO moduleDAO) {
		// INSERT INTO modules (modulename) VALUES
		// ('User Management'),
		// ('Leads'),
		// ('Customers'),
		// ('Reports'),
		// ('Settings'),
		// ('Billing');
		
		Module userManagement = new Module("USER MANAGEMENT");
		Module leads = new Module("LEADS");
		Module customers = new Module("CUSTOMERS");
		Module reports = new Module("REPORTS");
		Module settings = new Module("SETTINGS");
		Module billing = new Module("BILLING");

		if(!getModules().contains(userManagement))
			moduleDAO.save(userManagement);
			System.out.println("Created User Management Module");
		if(!getModules().contains(leads))
			moduleDAO.save(leads);
			System.out.println("Created Leads Module");
		if(!getModules().contains(customers))
			moduleDAO.save(customers);
			System.out.println("Created Customers Module");
		if(!getModules().contains(reports))
			moduleDAO.save(reports);
			System.out.println("Created Reports Module"+reports.getId());
		if(!getModules().contains(settings))
			moduleDAO.save(settings);
			System.out.println("Created Settings Module");
		if(!getModules().contains(billing))
			moduleDAO.save(billing);
			System.out.println("Created Billing Module");
	}



	public void createInitialPermissions(PermissionDAO permissionDAO) {
		// INSERT INTO permissions (permissionname) VALUES
		// ('CREATE'),
		// ('READ'),
		// ('UPDATE'),
		// ('DELETE');
		
		Permission create = new Permission("CREATE");
		Permission read = new Permission("READ");
		Permission update = new Permission("UPDATE");
		Permission delete = new Permission("DELETE");

		if(!getPermissions().contains(create))
			permissionDAO.save(create);
			System.out.println("Created Create Permission");
		if(!getPermissions().contains(read))
			permissionDAO.save(read);
			System.out.println("Created Read Permission");
		if(!getPermissions().contains(update))
			permissionDAO.save(update);
			System.out.println("Created Update Permission");
		if(!getPermissions().contains(delete))
			permissionDAO.save(delete);
			System.out.println("Created Delete Permission");

	}

	public void createInitialRoleModulePermission(RoleModulePermissionDAO roleModulePermissionDAO) {

		//INSERT INTO roles_modules_permissions (rid, mid, pid) VALUES
		// (1, 1, 1), (1, 1, 2), (1, 1, 3), (1, 1, 4),
		// (1, 2, 1), (1, 2, 2), (1, 2, 3), (1, 2, 4),
		// (1, 3, 1), (1, 3, 2), (1, 3, 3), (1, 3, 4),
		// (1, 4, 1), (1, 4, 2), (1, 4, 3), (1, 4, 4),
		// (1, 5, 1), (1, 5, 2), (1, 5, 3), (1, 5, 4),
		// (1, 6, 1), (1, 6, 2), (1, 6, 3), (1, 6, 4);



		// Admin: V, C, E, D on most modules except Settings
		// INSERT INTO roles_modules_permissions (rid, mid, pid) VALUES
		// (2, 1, 1), (2, 1, 2), (2, 1, 3), (2, 1, 4),
		// (2, 2, 1), (2, 2, 2), (2, 2, 3), (2, 2, 4),
		// (2, 3, 1), (2, 3, 2), (2, 3, 3), (2, 3, 4),
		// (2, 4, 1),
		// (2, 6, 1), (2, 6, 2);


		// Manager: V, C, E on Leads and Customers; V on Reports and Billing
		// INSERT INTO roles_modules_permissions (rid, mid, pid) VALUES
		// (3, 2, 1), (3, 2, 2), (3, 2, 3),
		// (3, 3, 1), (3, 3, 2), (3, 3, 3),
		// (3, 4, 1),
		// (3, 6, 1);


		// Employee: V, C on Leads; V on Customers and Reports
		// INSERT INTO roles_modules_permissions (rid, mid, pid) VALUES
		// (4, 2, 1), (4, 2, 2),
		// (4, 3, 1),
		// (4, 4, 1);


		// Viewer: V only on Leads, Customers, Reports
		// INSERT INTO roles_modules_permissions (rid, mid, pid) VALUES
		// (5, 2, 1),
		// (5, 3, 1),
		// (5, 4, 1);

		
		RoleModulePermission rmp1 = new RoleModulePermission((long)1, (long)1, (long)1);
		RoleModulePermission rmp2 = new RoleModulePermission((long)1, (long)1, (long)2);
		RoleModulePermission rmp3 = new RoleModulePermission((long)1, (long)1, (long)3);
		RoleModulePermission rmp4 = new RoleModulePermission((long)1, (long)1, (long)4);
		RoleModulePermission rmp5 = new RoleModulePermission((long)1, (long)2, (long)1);
		RoleModulePermission rmp6 = new	RoleModulePermission((long)1, (long)2, (long)2);
		RoleModulePermission rmp7 = new RoleModulePermission((long)1, (long)2, (long)3);
		RoleModulePermission rmp8 = new RoleModulePermission((long)1, (long)2, (long)4);
		RoleModulePermission rmp9 = new RoleModulePermission((long)1, (long)3, (long)1);
		RoleModulePermission rmp10 = new RoleModulePermission((long)1, (long)3, (long)2);
		RoleModulePermission rmp11 = new RoleModulePermission((long)1, (long)3, (long)3);
		RoleModulePermission rmp12 = new RoleModulePermission((long)1, (long)3, (long)4);
		RoleModulePermission rmp13 = new RoleModulePermission((long)1, (long)4, (long)1);
		RoleModulePermission rmp14 = new RoleModulePermission((long)1, (long)4, (long)2);
		RoleModulePermission rmp15 = new RoleModulePermission((long)1, (long)4, (long)3);
		RoleModulePermission rmp16 = new RoleModulePermission((long)1, (long)4, (long)4);
		RoleModulePermission rmp17 = new RoleModulePermission((long)1, (long)5, (long)1);
		RoleModulePermission rmp18 = new RoleModulePermission((long)1, (long)5, (long)2);
		RoleModulePermission rmp19 = new RoleModulePermission((long)1, (long)5, (long)3);
		RoleModulePermission rmp20 = new RoleModulePermission((long)1, (long)5, (long)4);
		RoleModulePermission rmp21 = new RoleModulePermission((long)1, (long)6, (long)1);
		RoleModulePermission rmp22 = new RoleModulePermission((long)1, (long)6, (long)2);
		RoleModulePermission rmp23 = new RoleModulePermission((long)1, (long)6, (long)3);
		RoleModulePermission rmp24 = new RoleModulePermission((long)1, (long)6, (long)4);
		RoleModulePermission rmp25 = new RoleModulePermission((long)2, (long)1, (long)1);
		RoleModulePermission rmp26 = new RoleModulePermission((long)2, (long)1, (long)2);
		RoleModulePermission rmp27 = new RoleModulePermission((long)2, (long)1, (long)3);
		RoleModulePermission rmp28 = new RoleModulePermission((long)2, (long)1, (long)4);
		RoleModulePermission rmp29 = new RoleModulePermission((long)2, (long)2, (long)1);
		RoleModulePermission rmp30 = new RoleModulePermission((long)2, (long)2, (long)2);
		RoleModulePermission rmp31 = new RoleModulePermission((long)2, (long)2, (long)3);
		RoleModulePermission rmp32 = new RoleModulePermission((long)2, (long)2, (long)4);
		RoleModulePermission rmp33 = new RoleModulePermission((long)2, (long)3, (long)1);
		RoleModulePermission rmp34 = new RoleModulePermission((long)2, (long)3, (long)2);
		RoleModulePermission rmp35 = new RoleModulePermission((long)2, (long)3, (long)3);
		RoleModulePermission rmp36 = new RoleModulePermission((long)2, (long)4, (long)1);
		RoleModulePermission rmp37 = new RoleModulePermission((long)2, (long)6, (long)1);
		RoleModulePermission rmp38 = new RoleModulePermission((long)2, (long)6, (long)2);
		RoleModulePermission rmp39 = new RoleModulePermission((long)3, (long)2, (long)1);
		RoleModulePermission rmp40 = new RoleModulePermission((long)3, (long)2, (long)2);
		RoleModulePermission rmp41 = new RoleModulePermission((long)3, (long)2, (long)3);
		RoleModulePermission rmp42 = new RoleModulePermission((long)3, (long)3, (long)1);
		RoleModulePermission rmp43 = new RoleModulePermission((long)3, (long)3, (long)2);
		RoleModulePermission rmp44 = new RoleModulePermission((long)3, (long)3, (long)3);
		RoleModulePermission rmp45 = new RoleModulePermission((long)3, (long)4, (long)1);
		RoleModulePermission rmp46 = new RoleModulePermission((long)3, (long)6, (long)1);
		RoleModulePermission rmp47 = new RoleModulePermission((long)4, (long)2, (long)1);
		RoleModulePermission rmp48 = new RoleModulePermission((long)4, (long)2, (long)2);
		RoleModulePermission rmp49 = new RoleModulePermission((long)4, (long)3, (long)1);
		RoleModulePermission rmp50 = new RoleModulePermission((long)4, (long)4, (long)1);
		RoleModulePermission rmp51 = new RoleModulePermission((long)5, (long)2, (long)1);
		RoleModulePermission rmp52 = new RoleModulePermission((long)5, (long)3, (long)1);
		RoleModulePermission rmp53 = new RoleModulePermission((long)5, (long)4, (long)1);


		RoleModulePermission[] roleModulePermissions = {rmp1, rmp2, rmp3, rmp4, rmp5, rmp6, rmp7, rmp8, rmp9, rmp10, rmp11, rmp12, rmp13, rmp14, rmp15, rmp16, rmp17, rmp18, rmp19, rmp20, rmp21, rmp22, rmp23, rmp24, rmp25, rmp26, rmp27, rmp28, rmp29, rmp30, rmp31, rmp32, rmp33, rmp34, rmp35, rmp36, rmp37, rmp38, rmp39, rmp40, rmp41, rmp42, rmp43, rmp44, rmp45, rmp46,rmp47,rmp48,rmp49,rmp50,rmp51,rmp52,rmp53};
		for(RoleModulePermission rmp : roleModulePermissions) {
			
			roleModulePermissionDAO.save(rmp);
			System.out.println("Created RoleModulePermission: " + rmp.getId().getRid() + ", " + rmp.getId().getMid() + ", " + rmp.getId().getPid());
		}




	}
	public List<User> getUsers() {

		TypedQuery<User> theQuery = entityManager.createQuery("select u from User u", User.class);
		List<User> users = theQuery.getResultList();
		return users;
	}
	public List<Role> getRoles() {

		TypedQuery<Role> theQuery = entityManager.createQuery("select r from Role r", Role.class);
		List<Role> roles = theQuery.getResultList();
		return roles;
	}
	public List<Module> getModules() {

		TypedQuery<Module> theQuery = entityManager.createQuery("select m from Module m", Module.class);
		List<Module> modules = theQuery.getResultList();
		return modules;
	}

	public List<Permission> getPermissions() {

		TypedQuery<Permission> theQuery = entityManager.createQuery("select p from Permission p", Permission.class);
		List<Permission> permissions = theQuery.getResultList();
		return permissions;
	}

	public List<RoleModulePermission> getRoleModulePermissions(){

		TypedQuery<RoleModulePermission> theQuery = entityManager.createQuery("select rmp from RoleModulePermission rmp", RoleModulePermission.class);
		List<RoleModulePermission> rmp = theQuery.getResultList();
		return rmp;
		

	}

		
}
