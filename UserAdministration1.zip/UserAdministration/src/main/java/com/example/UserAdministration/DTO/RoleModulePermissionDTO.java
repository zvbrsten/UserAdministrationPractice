package com.example.UserAdministration.DTO;


import com.example.UserAdministration.entity.RoleModulePermission;
import com.example.UserAdministration.entity.User;
import com.example.UserAdministration.repository.ModuleRepository;
import com.example.UserAdministration.repository.PermissionRepository;
import com.example.UserAdministration.repository.RoleModulePermissionRepository;
import com.example.UserAdministration.repository.RoleRepository;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Setter
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RoleModulePermissionDTO {

    private String roleName;
    private String permissionName;
    private String modulesName;

    private RoleRepository roleRepository;
    private ModuleRepository moduleRepository;
    private PermissionRepository permissionRepository;
    private RoleModulePermissionRepository roleModulePermissionRepository;


    public RoleModulePermissionDTO(){}
    public RoleModulePermissionDTO(RoleModulePermission roleModulePermission) {

        this.roleName = roleModulePermission.getRole().getRoleName();
        this.modulesName=roleModulePermission.getModule().getModulesName();
        this.permissionName=roleModulePermission.getPermission().getPermissionName();
    }
}
