package com.example.UserAdministration.DAO;

//import org.springframework.beans.factory.annotation.Autowired;
import com.example.UserAdministration.entity.Role;
import org.springframework.stereotype.Service;

import jakarta.persistence.*;
import jakarta.transaction.Transactional;


@Service
public class RoleDAOImplementation implements RoleDAO {

    @PersistenceContext
    private EntityManager entityManager;


    
    public RoleDAOImplementation(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    @Override
    @Transactional
    public void save(Role theRole) {
        entityManager.persist(theRole);
    }

}
