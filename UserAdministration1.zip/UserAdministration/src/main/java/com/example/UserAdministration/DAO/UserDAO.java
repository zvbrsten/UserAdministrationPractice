package com.example.UserAdministration.DAO;


import com.example.UserAdministration.entity.User;

public interface UserDAO {



    
    
    void save(User theUser);

}
