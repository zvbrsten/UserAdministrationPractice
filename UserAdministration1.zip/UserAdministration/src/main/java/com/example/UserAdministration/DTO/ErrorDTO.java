package com.example.UserAdministration.DTO;

import org.springframework.http.HttpStatus;

import java.time.LocalDateTime;

public class ErrorDTO {


    public record ErrorResponseDTO(String apiPath, HttpStatus errorCode, String errorMessage, LocalDateTime errorTime){

    }
}
