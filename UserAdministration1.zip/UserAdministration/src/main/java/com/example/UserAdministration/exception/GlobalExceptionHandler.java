package com.example.UserAdministration.exception;

import com.example.UserAdministration.rest.NotFound;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

//@RestControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

    @ExceptionHandler(NotFound.class)
    public ResponseEntity<String> handleCustomException(
            NotFound ex,
            HttpServletRequest request) {

        String endpoint = request.getMethod() + " " + request.getRequestURI();
        String errorMessage = ex.getMessage();
                return ResponseEntity
                .status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(errorMessage
                );
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<String> handleException(
            Exception ex,
            HttpServletRequest request)throws Exception {
        String endpoint = request.getMethod() + " " + request.getRequestURI();
        String errorMessage = ex.getMessage();
        return ResponseEntity
                .status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body("from global exception handler ----  "+errorMessage
                );
    }


}
