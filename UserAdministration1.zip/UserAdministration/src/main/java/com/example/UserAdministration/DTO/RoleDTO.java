package com.example.UserAdministration.DTO;


import com.example.UserAdministration.entity.Role;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RoleDTO {

    private String roleName;

    public RoleDTO(){}

    public RoleDTO(Role role) {
        this.roleName = role.getRoleName();
    }


}
