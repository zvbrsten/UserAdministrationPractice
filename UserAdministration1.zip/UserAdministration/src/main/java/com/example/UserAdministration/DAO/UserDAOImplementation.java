package com.example.UserAdministration.DAO;


import java.util.List;

import com.example.UserAdministration.entity.User;
import org.springframework.stereotype.Repository;

import jakarta.persistence.*;
import jakarta.transaction.Transactional;


@Repository
public class UserDAOImplementation implements UserDAO {

    @PersistenceContext
    private EntityManager entityManager;


    
    public UserDAOImplementation(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    @Override
    @Transactional
    public void save(User theUser) {
        entityManager.persist(theUser);
    }
    // Method to save a User entity to the database
    public void saveUser(User user) {
        
        EntityTransaction transaction = entityManager.getTransaction();
        transaction.begin();
        entityManager.persist(user);
        transaction.commit();
        entityManager.close();
    }

    // Method to find users by their name
    public List<User> findUserByName(String name) {
        
        try {
            TypedQuery<User> query = entityManager.createQuery("SELECT s FROM User s WHERE s.name = :name", User.class);
            query.setParameter("name", name);
            return query.getResultList();
        } finally {
            entityManager.close();
        }
    }

    // Method to update a User entity in the database
    public void updateUser(User user) {
        // EntityManager entityManager = entityManager.createEntityManager();
        EntityTransaction transaction = entityManager.getTransaction();
        transaction.begin();
        entityManager.merge(user);
        transaction.commit();
        entityManager.close();
    }

    // Method to delete a User entity from the database
    public void deleteUser(User user) {
        // EntityManager entityManager = entityManager.createEntityManager();
        EntityTransaction transaction = entityManager.getTransaction();
        transaction.begin();
        // Check if the entity is managed by the EntityManager, and if not, merge it before removal
        entityManager.remove(entityManager.contains(user) ? user : entityManager.merge(user));
        transaction.commit();
        entityManager.close();
    }
}


