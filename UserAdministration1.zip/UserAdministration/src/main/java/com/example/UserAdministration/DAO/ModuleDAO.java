package com.example.UserAdministration.DAO;


import com.example.UserAdministration.entity.Module;

public interface ModuleDAO {



    
    
    void save(Module theModule);

}
