package com.example.UserAdministration.DTO;


import com.example.UserAdministration.entity.Module;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Setter
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ModuleDTO {

    private String moduleName;

    public ModuleDTO(){}

    public ModuleDTO(Module module) {
        this.moduleName = module.getModulesName();
    }
}
