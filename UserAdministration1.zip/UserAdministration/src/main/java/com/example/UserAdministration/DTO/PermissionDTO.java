package com.example.UserAdministration.DTO;


import com.example.UserAdministration.entity.Permission;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Setter
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PermissionDTO {

    private String permissionName;

    public PermissionDTO(){}
    public PermissionDTO(Permission permission) {
        this.permissionName = permission.getPermissionName();
    }
}
