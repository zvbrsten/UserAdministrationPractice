package com.example.UserAdministration.repository;

import com.example.UserAdministration.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User,Long> {
}
