package com.example.UserAdministration.DAO;


import com.example.UserAdministration.entity.Permission;

public interface PermissionDAO {



    
    
    void save(Permission thePermission);

}
