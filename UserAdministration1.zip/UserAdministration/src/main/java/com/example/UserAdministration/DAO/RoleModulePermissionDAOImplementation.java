
package com.example.UserAdministration.DAO;

//import org.springframework.beans.factory.annotation.Autowired;
import com.example.UserAdministration.entity.RoleModulePermission;
import org.springframework.stereotype.Service;

import jakarta.persistence.*;
import jakarta.transaction.Transactional;


@Service
public class RoleModulePermissionDAOImplementation implements RoleModulePermissionDAO {

    @PersistenceContext
    private EntityManager entityManager;


    
    public RoleModulePermissionDAOImplementation(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    @Override
    @Transactional
    public void save(RoleModulePermission theRoleModulePermission) {
        entityManager.persist(theRoleModulePermission);
    }

}
