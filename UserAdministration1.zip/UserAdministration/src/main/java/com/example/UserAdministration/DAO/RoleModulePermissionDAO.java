package com.example.UserAdministration.DAO;

import com.example.UserAdministration.entity.RoleModulePermission;

public interface RoleModulePermissionDAO {
    
    public void save(RoleModulePermission theRoleModulePermission);
}
