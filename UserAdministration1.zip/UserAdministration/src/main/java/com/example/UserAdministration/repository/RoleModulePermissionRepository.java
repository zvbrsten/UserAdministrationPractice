package com.example.UserAdministration.repository;

import com.example.UserAdministration.entity.RoleModulePermission;
import com.example.UserAdministration.entity.RoleModulePermissionId;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleModulePermissionRepository extends JpaRepository<RoleModulePermission, RoleModulePermissionId> {
}
