package com.example.UserAdministration.entity;

import jakarta.persistence.Embeddable;
import java.io.Serializable;
import java.util.Objects;

@Embeddable
public class RoleModulePermissionId implements Serializable {
    
    private Long rid;
    private Long mid;
    private Long pid;
    
    public RoleModulePermissionId() {}
    
    public RoleModulePermissionId(Long rid, Long mid, Long pid) {
        this.rid = rid;
        this.mid = mid;
        this.pid = pid;
    }
    
    public Long getRid() {
        return rid;
    }

    
    public void setRid(Long rid) {
        this.rid = rid;
    }
    
    public Long getMid() {
        return mid;
    }
    
    public void setMid(Long mid) {
        this.mid = mid;
    }
    
    public Long getPid() {
        return pid;
    }
    
    public void setPid(Long pid) {
        this.pid = pid;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        RoleModulePermissionId that = (RoleModulePermissionId) o;
        return Objects.equals(rid, that.rid) && Objects.equals(mid, that.mid) && Objects.equals(pid, that.pid);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(rid, mid, pid);
    }
}