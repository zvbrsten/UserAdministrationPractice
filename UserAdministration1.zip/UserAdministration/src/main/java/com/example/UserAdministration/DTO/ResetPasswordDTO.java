package com.example.UserAdministration.DTO;

public class ResetPasswordDTO {




    private String newPassword;
    public String getNewPassword() {
        return newPassword;
    }
    public void setNewPassword(String newPassword){
        this.newPassword=newPassword;

    }
}
