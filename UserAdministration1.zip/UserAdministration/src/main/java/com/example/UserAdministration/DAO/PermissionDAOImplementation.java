package com.example.UserAdministration.DAO;

//import org.springframework.beans.factory.annotation.Autowired;
import com.example.UserAdministration.entity.Permission;
import org.springframework.stereotype.Service;

import jakarta.persistence.*;
import jakarta.transaction.Transactional;


@Service
public class PermissionDAOImplementation implements PermissionDAO {

    @PersistenceContext
    private EntityManager entityManager;


    
    public PermissionDAOImplementation(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    @Override
    @Transactional
    public void save(Permission thePermission) {
        entityManager.persist(thePermission);
    }

}
